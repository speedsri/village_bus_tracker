<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Start session at the very beginning
session_start();

require_once '../includes/config.php';
require_once '../includes/auth.php';

// Check admin auth
if (!isset($_SESSION['admin_id']) || !isset($_SESSION['admin_session_token'])) {
    header('Location: index.php');
    exit;
}

$admin_id = $_SESSION['admin_id'];
$admin_name = isset($_SESSION['admin_name']) ? $_SESSION['admin_name'] : 'Administrator';

// Verify admin session
try {
    $stmt = $pdo->prepare("
        SELECT us.*, u.user_type, u.full_name 
        FROM user_sessions us 
        JOIN users u ON us.user_id = u.user_id 
        WHERE us.user_id = ? AND us.session_token = ? AND us.is_active = 1
        AND u.user_type = 'admin' AND u.is_active = 1
    ");
    $stmt->execute([$admin_id, $_SESSION['admin_session_token']]);
    $session = $stmt->fetch();

    if (!$session) {
        session_destroy();
        header('Location: index.php?session=expired');
        exit;
    }
} catch (PDOException $e) {
    error_log("Session verification error: " . $e->getMessage());
}

// Handle form submissions
$message = '';
$message_type = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_assignment'])) {
        // Add new driver assignment
        $driver_id = intval($_POST['driver_id']);
        $bus_id = intval($_POST['bus_id']);
        $route_id = intval($_POST['route_id']);
        $assigned_date = $_POST['assigned_date'];
        $shift_start = $_POST['shift_start'];
        $shift_end = $_POST['shift_end'];
        
        try {
            // Check if driver already has assignment for this date
            $stmt = $pdo->prepare("
                SELECT assignment_id FROM driver_assignments 
                WHERE driver_id = ? AND assigned_date = ? AND status IN ('scheduled', 'active')
            ");
            $stmt->execute([$driver_id, $assigned_date]);
            
            if ($stmt->fetch()) {
                $message = 'Driver already has an assignment for this date!';
                $message_type = 'error';
            } else {
                $stmt = $pdo->prepare("
                    INSERT INTO driver_assignments (driver_id, bus_id, route_id, shift_start, shift_end, assigned_date, status)
                    VALUES (?, ?, ?, ?, ?, ?, 'scheduled')
                ");
                
                if ($stmt->execute([$driver_id, $bus_id, $route_id, $shift_start, $shift_end, $assigned_date])) {
                    $message = 'Driver assignment created successfully!';
                    $message_type = 'success';
                    
                    // Log the activity
                    $stmt = $pdo->prepare("
                        INSERT INTO activity_logs (user_id, action_type, table_affected, record_id, new_values, ip_address)
                        VALUES (?, 'create_assignment', 'driver_assignments', ?, ?, ?)
                    ");
                    $stmt->execute([
                        $admin_id,
                        $pdo->lastInsertId(),
                        json_encode(['driver_id' => $driver_id, 'bus_id' => $bus_id, 'route_id' => $route_id, 'date' => $assigned_date]),
                        $_SERVER['REMOTE_ADDR']
                    ]);
                } else {
                    $message = 'Failed to create assignment!';
                    $message_type = 'error';
                }
            }
        } catch (PDOException $e) {
            error_log("Assignment creation error: " . $e->getMessage());
            $message = 'Database error: ' . $e->getMessage();
            $message_type = 'error';
        }
    } elseif (isset($_POST['update_assignment'])) {
        // Update existing assignment
        $assignment_id = intval($_POST['assignment_id']);
        $bus_id = intval($_POST['bus_id']);
        $route_id = intval($_POST['route_id']);
        $assigned_date = $_POST['assigned_date'];
        $shift_start = $_POST['shift_start'];
        $shift_end = $_POST['shift_end'];
        $status = $_POST['status'];
        
        try {
            $stmt = $pdo->prepare("
                UPDATE driver_assignments 
                SET bus_id = ?, route_id = ?, shift_start = ?, shift_end = ?, assigned_date = ?, status = ?
                WHERE assignment_id = ?
            ");
            
            if ($stmt->execute([$bus_id, $route_id, $shift_start, $shift_end, $assigned_date, $status, $assignment_id])) {
                $message = 'Assignment updated successfully!';
                $message_type = 'success';
                
                // Log the activity
                $stmt = $pdo->prepare("
                    INSERT INTO activity_logs (user_id, action_type, table_affected, record_id, new_values, ip_address)
                    VALUES (?, 'update_assignment', 'driver_assignments', ?, ?, ?)
                ");
                $stmt->execute([
                    $admin_id,
                    $assignment_id,
                    json_encode(['bus_id' => $bus_id, 'route_id' => $route_id, 'status' => $status]),
                    $_SERVER['REMOTE_ADDR']
                ]);
            } else {
                $message = 'Failed to update assignment!';
                $message_type = 'error';
            }
        } catch (PDOException $e) {
            error_log("Assignment update error: " . $e->getMessage());
            $message = 'Database error: ' . $e->getMessage();
            $message_type = 'error';
        }
    } elseif (isset($_POST['delete_assignment'])) {
        // Delete assignment
        $assignment_id = intval($_POST['assignment_id']);
        
        try {
            $stmt = $pdo->prepare("DELETE FROM driver_assignments WHERE assignment_id = ?");
            
            if ($stmt->execute([$assignment_id])) {
                $message = 'Assignment deleted successfully!';
                $message_type = 'success';
                
                // Log the activity
                $stmt = $pdo->prepare("
                    INSERT INTO activity_logs (user_id, action_type, table_affected, record_id, ip_address)
                    VALUES (?, 'delete_assignment', 'driver_assignments', ?, ?)
                ");
                $stmt->execute([$admin_id, $assignment_id, $_SERVER['REMOTE_ADDR']]);
            } else {
                $message = 'Failed to delete assignment!';
                $message_type = 'error';
            }
        } catch (PDOException $e) {
            error_log("Assignment deletion error: " . $e->getMessage());
            $message = 'Database error: ' . $e->getMessage();
            $message_type = 'error';
        }
    }
}

// Get data for forms
$drivers = [];
$buses = [];
$routes = [];
$assignments = [];

try {
    // Get active drivers
    $stmt = $pdo->query("
        SELECT user_id, full_name, username 
        FROM users 
        WHERE user_type = 'driver' AND is_active = 1 
        ORDER BY full_name
    ");
    $drivers = $stmt->fetchAll();

    // Get active buses
    $stmt = $pdo->query("
        SELECT bus_id, bus_number, registration_number, model 
        FROM buses 
        WHERE is_active = 1 
        ORDER BY bus_number
    ");
    $buses = $stmt->fetchAll();

    // Get active routes
    $stmt = $pdo->query("
        SELECT route_id, route_name, route_code 
        FROM routes 
        WHERE is_active = 1 
        ORDER BY route_name
    ");
    $routes = $stmt->fetchAll();

    // Get assignments with details
    $stmt = $pdo->query("
        SELECT 
            da.*,
            u.full_name as driver_name,
            b.bus_number,
            r.route_name,
            r.start_location,
            r.end_location
        FROM driver_assignments da
        JOIN users u ON da.driver_id = u.user_id
        JOIN buses b ON da.bus_id = b.bus_id
        JOIN routes r ON da.route_id = r.route_id
        ORDER BY da.assigned_date DESC, da.shift_start
    ");
    $assignments = $stmt->fetchAll();
} catch (PDOException $e) {
    error_log("Data fetch error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Driver Assignments - Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .sidebar {
            background: #2c3e50;
            color: white;
            min-height: 100vh;
        }
        .sidebar .nav-link {
            color: #bdc3c7;
            padding: 12px 20px;
            border-radius: 5px;
            margin: 2px 0;
        }
        .sidebar .nav-link:hover, .sidebar .nav-link.active {
            background: #34495e;
            color: white;
        }
        .main-content {
            background: #f8f9fa;
            min-height: 100vh;
        }
        .card {
            box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
            border: 1px solid rgba(0, 0, 0, 0.125);
        }
        .status-scheduled { background-color: #fff3cd; color: #856404; }
        .status-active { background-color: #d1ecf1; color: #0c5460; }
        .status-completed { background-color: #d4edda; color: #155724; }
        .status-cancelled { background-color: #f8d7da; color: #721c24; }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 sidebar p-0">
                <div class="p-3 border-bottom">
                    <h4 class="text-white mb-0">
                        <i class="fas fa-bus me-2"></i>Bus Tracker
                    </h4>
                    <small class="text-muted">Admin Panel</small>
                </div>
                <nav class="nav flex-column p-3">
                    <a class="nav-link" href="dashboard.php">
                        <i class="fas fa-tachometer-alt me-2"></i>Dashboard
                    </a>
                    <a class="nav-link" href="buses.php">
                        <i class="fas fa-bus me-2"></i>Buses
                    </a>

                    <a class="nav-link" href="routes.php">
                        <i class="fas fa-route me-2"></i>Routes
                    </a>
                    <a class="nav-link active" href="assign_drivers.php">
                        <i class="fas fa-calendar-check me-2"></i>Driver Assignments
                    </a>
                    <a class="nav-link" href="trips.php">
                        <i class="fas fa-shipping-fast me-2"></i>Trips
                    </a>
                    <a class="nav-link" href="passengers.php">
                        <i class="fas fa-user-friends me-2"></i>Passengers
                    </a>
                    <a class="nav-link" href="reports.php">
                        <i class="fas fa-chart-bar me-2"></i>Reports
                    </a>
                    <a class="nav-link" href="system_alerts.php">
                        <i class="fas fa-bell me-2"></i>Alerts
                    </a>
                    <div class="mt-4 pt-3 border-top">
                        <a class="nav-link" href="logout.php">
                            <i class="fas fa-sign-out-alt me-2"></i>Logout
                        </a>
                    </div>
                </nav>
            </div>

            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 main-content p-0">
                <!-- Top Bar -->
                <nav class="navbar navbar-light bg-white border-bottom">
                    <div class="container-fluid">
                        <span class="navbar-text">
                            <i class="fas fa-user-shield me-2"></i>Welcome, <strong><?php echo htmlspecialchars($admin_name); ?></strong>
                        </span>
                        <div class="d-flex">
                            <span class="navbar-text me-3">
                                <i class="fas fa-clock me-1"></i><?php echo date('l, F j, Y'); ?>
                            </span>
                        </div>
                    </div>
                </nav>

                <div class="container-fluid p-4">
                    <!-- Page Header -->
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h2 class="h3 mb-0">
                            <i class="fas fa-calendar-check me-2"></i>Driver Assignments
                        </h2>
                    </div>

                    <!-- Status Message -->
                    <?php if ($message): ?>
                        <div class="alert alert-<?php echo $message_type === 'success' ? 'success' : 'danger'; ?> alert-dismissible fade show" role="alert">
                            <?php echo htmlspecialchars($message); ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <!-- Add Assignment Form -->
                    <div class="card mb-4">
                        <div class="card-header bg-primary text-white">
                            <h5 class="card-title mb-0">
                                <i class="fas fa-plus-circle me-2"></i>Add New Assignment
                            </h5>
                        </div>
                        <div class="card-body">
                            <form method="POST" id="assignmentForm">
                                <div class="row">
                                    <div class="col-md-3 mb-3">
                                        <label for="driver_id" class="form-label">Driver</label>
                                        <select class="form-select" id="driver_id" name="driver_id" required>
                                            <option value="">Select Driver</option>
                                            <?php foreach ($drivers as $driver): ?>
                                                <option value="<?php echo $driver['user_id']; ?>">
                                                    <?php echo htmlspecialchars($driver['full_name']); ?> (<?php echo htmlspecialchars($driver['username']); ?>)
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div class="col-md-2 mb-3">
                                        <label for="bus_id" class="form-label">Bus</label>
                                        <select class="form-select" id="bus_id" name="bus_id" required>
                                            <option value="">Select Bus</option>
                                            <?php foreach ($buses as $bus): ?>
                                                <option value="<?php echo $bus['bus_id']; ?>">
                                                    <?php echo htmlspecialchars($bus['bus_number']); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div class="col-md-3 mb-3">
                                        <label for="route_id" class="form-label">Route</label>
                                        <select class="form-select" id="route_id" name="route_id" required>
                                            <option value="">Select Route</option>
                                            <?php foreach ($routes as $route): ?>
                                                <option value="<?php echo $route['route_id']; ?>">
                                                    <?php echo htmlspecialchars($route['route_name']); ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div class="col-md-2 mb-3">
                                        <label for="assigned_date" class="form-label">Date</label>
                                        <input type="date" class="form-control" id="assigned_date" name="assigned_date" 
                                               value="<?php echo date('Y-m-d'); ?>" required>
                                    </div>
                                    <div class="col-md-2 mb-3">
                                        <label for="shift_start" class="form-label">Shift Start</label>
                                        <input type="time" class="form-control" id="shift_start" name="shift_start" value="08:00" required>
                                    </div>
                                    <div class="col-md-2 mb-3">
                                        <label for="shift_end" class="form-label">Shift End</label>
                                        <input type="time" class="form-control" id="shift_end" name="shift_end" value="17:00" required>
                                    </div>
                                </div>
                                <div class="text-end">
                                    <button type="submit" name="add_assignment" class="btn btn-primary">
                                        <i class="fas fa-save me-1"></i>Create Assignment
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>

                    <!-- Assignments Table -->
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title mb-0">
                                <i class="fas fa-list me-2"></i>Current Assignments
                            </h5>
                        </div>
                        <div class="card-body">
                            <?php if (!empty($assignments)): ?>
                                <div class="table-responsive">
                                    <table class="table table-striped table-hover">
                                        <thead>
                                            <tr>
                                                <th>Driver</th>
                                                <th>Bus</th>
                                                <th>Route</th>
                                                <th>Date</th>
                                                <th>Shift</th>
                                                <th>Status</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($assignments as $assignment): ?>
                                                <tr>
                                                    <td>
                                                        <strong><?php echo htmlspecialchars($assignment['driver_name']); ?></strong>
                                                    </td>
                                                    <td><?php echo htmlspecialchars($assignment['bus_number']); ?></td>
                                                    <td>
                                                        <?php echo htmlspecialchars($assignment['route_name']); ?><br>
                                                        <small class="text-muted">
                                                            <?php echo htmlspecialchars($assignment['start_location']); ?> → 
                                                            <?php echo htmlspecialchars($assignment['end_location']); ?>
                                                        </small>
                                                    </td>
                                                    <td>
                                                        <?php echo date('M j, Y', strtotime($assignment['assigned_date'])); ?>
                                                    </td>
                                                    <td>
                                                        <?php echo date('g:i A', strtotime($assignment['shift_start'])); ?> - 
                                                        <?php echo date('g:i A', strtotime($assignment['shift_end'])); ?>
                                                    </td>
                                                    <td>
                                                        <span class="badge status-<?php echo $assignment['status']; ?>">
                                                            <?php echo ucfirst($assignment['status']); ?>
                                                        </span>
                                                    </td>
                                                    <td>
                                                        <div class="btn-group btn-group-sm">
                                                            <button type="button" class="btn btn-outline-primary" 
                                                                    data-bs-toggle="modal" data-bs-target="#editAssignmentModal"
                                                                    onclick="editAssignment(<?php echo htmlspecialchars(json_encode($assignment)); ?>)">
                                                                <i class="fas fa-edit"></i>
                                                            </button>
                                                            <form method="POST" class="d-inline" onsubmit="return confirm('Are you sure you want to delete this assignment?');">
                                                                <input type="hidden" name="assignment_id" value="<?php echo $assignment['assignment_id']; ?>">
                                                                <button type="submit" name="delete_assignment" class="btn btn-outline-danger">
                                                                    <i class="fas fa-trash"></i>
                                                                </button>
                                                            </form>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php else: ?>
                                <div class="text-center py-4">
                                    <i class="fas fa-calendar-times fa-3x text-muted mb-3"></i>
                                    <p class="text-muted">No driver assignments found.</p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Edit Assignment Modal -->
    <div class="modal fade" id="editAssignmentModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Assignment</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form method="POST" id="editAssignmentForm">
                    <div class="modal-body">
                        <input type="hidden" name="assignment_id" id="edit_assignment_id">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="edit_bus_id" class="form-label">Bus</label>
                                <select class="form-select" id="edit_bus_id" name="bus_id" required>
                                    <?php foreach ($buses as $bus): ?>
                                        <option value="<?php echo $bus['bus_id']; ?>">
                                            <?php echo htmlspecialchars($bus['bus_number']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="edit_route_id" class="form-label">Route</label>
                                <select class="form-select" id="edit_route_id" name="route_id" required>
                                    <?php foreach ($routes as $route): ?>
                                        <option value="<?php echo $route['route_id']; ?>">
                                            <?php echo htmlspecialchars($route['route_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="edit_assigned_date" class="form-label">Date</label>
                                <input type="date" class="form-control" id="edit_assigned_date" name="assigned_date" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="edit_shift_start" class="form-label">Shift Start</label>
                                <input type="time" class="form-control" id="edit_shift_start" name="shift_start" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="edit_shift_end" class="form-label">Shift End</label>
                                <input type="time" class="form-control" id="edit_shift_end" name="shift_end" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="edit_status" class="form-label">Status</label>
                                <select class="form-select" id="edit_status" name="status" required>
                                    <option value="scheduled">Scheduled</option>
                                    <option value="active">Active</option>
                                    <option value="completed">Completed</option>
                                    <option value="cancelled">Cancelled</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="update_assignment" class="btn btn-primary">Update Assignment</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function editAssignment(assignment) {
            document.getElementById('edit_assignment_id').value = assignment.assignment_id;
            document.getElementById('edit_bus_id').value = assignment.bus_id;
            document.getElementById('edit_route_id').value = assignment.route_id;
            document.getElementById('edit_assigned_date').value = assignment.assigned_date;
            document.getElementById('edit_shift_start').value = assignment.shift_start;
            document.getElementById('edit_shift_end').value = assignment.shift_end;
            document.getElementById('edit_status').value = assignment.status;
        }

        // Set minimum date to today
        document.getElementById('assigned_date').min = new Date().toISOString().split('T')[0];
        document.getElementById('edit_assigned_date').min = new Date().toISOString().split('T')[0];

        // Form validation
        document.getElementById('assignmentForm').addEventListener('submit', function(e) {
            const shiftStart = document.getElementById('shift_start').value;
            const shiftEnd = document.getElementById('shift_end').value;
            
            if (shiftStart >= shiftEnd) {
                e.preventDefault();
                alert('Shift end time must be after shift start time!');
                return false;
            }
        });
    </script>
</body>
</html>
<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Start session at the very beginning
session_start();

require_once '../../includes/config.php';
require_once '../../includes/auth.php';

// Check admin auth
if (!isset($_SESSION['admin_id']) || !isset($_SESSION['admin_session_token'])) {
    header('Location: index.php');
    exit;
}

$admin_id = $_SESSION['admin_id'];
$admin_name = isset($_SESSION['admin_name']) ? $_SESSION['admin_name'] : 'Administrator';

// Verify admin session
try {
    $stmt = $pdo->prepare("
        SELECT us.*, u.user_type, u.full_name 
        FROM user_sessions us 
        JOIN users u ON us.user_id = u.user_id 
        WHERE us.user_id = ? AND us.session_token = ? AND us.is_active = 1
        AND u.user_type = 'admin' AND u.is_active = 1
    ");
    $stmt->execute([$admin_id, $_SESSION['admin_session_token']]);
    $session = $stmt->fetch();

    if (!$session) {
        session_destroy();
        header('Location: index.php?session=expired');
        exit;
    }
} catch (PDOException $e) {
    error_log("Session verification error: " . $e->getMessage());
}

// Get routes for dropdown
try {
    $stmt = $pdo->prepare("SELECT route_id, route_name FROM routes WHERE is_active = 1 ORDER BY route_name");
    $stmt->execute();
    $routes = $stmt->fetchAll();
    
    // Get default route ID (first active route)
    $default_route_id = $routes[0]['route_id'] ?? 1;
    
} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
    $routes = [];
    $default_route_id = 1;
}

// Handle form submissions via AJAX - we'll process these in the same file
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    
    try {
        if ($_POST['action'] === 'add_stop') {
            // Add new bus stop from map
            $stmt = $pdo->prepare("
                INSERT INTO bus_stops (route_id, stop_name, stop_order, latitude, longitude, landmark, estimated_time_from_start, is_active)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ");
            
            $stmt->execute([
                $_POST['route_id'],
                $_POST['stop_name'],
                $_POST['stop_order'],
                $_POST['latitude'],
                $_POST['longitude'],
                $_POST['landmark'] ?? '',
                $_POST['estimated_time'] ?? 0,
                1
            ]);
            
            $stop_id = $pdo->lastInsertId();
            
            // Log the activity
            $stmt = $pdo->prepare("
                INSERT INTO activity_logs (user_id, action_type, table_affected, record_id, ip_address)
                VALUES (?, 'create', 'bus_stops', ?, ?)
            ");
            $stmt->execute([$admin_id, $stop_id, get_client_ip()]);
            
            echo json_encode([
                'success' => true,
                'message' => 'Bus stop added successfully!',
                'stop_id' => $stop_id
            ]);
            
        } elseif ($_POST['action'] === 'update_stop') {
            // Update existing bus stop
            $stmt = $pdo->prepare("
                UPDATE bus_stops 
                SET route_id = ?, stop_name = ?, stop_order = ?, latitude = ?, longitude = ?, 
                    landmark = ?, estimated_time_from_start = ?, is_active = ?
                WHERE stop_id = ?
            ");
            
            $stmt->execute([
                $_POST['route_id'],
                $_POST['stop_name'],
                $_POST['stop_order'],
                $_POST['latitude'],
                $_POST['longitude'],
                $_POST['landmark'] ?? '',
                $_POST['estimated_time'] ?? 0,
                $_POST['is_active'],
                $_POST['stop_id']
            ]);
            
            // Log the activity
            $stmt = $pdo->prepare("
                INSERT INTO activity_logs (user_id, action_type, table_affected, record_id, ip_address)
                VALUES (?, 'update', 'bus_stops', ?, ?)
            ");
            $stmt->execute([$admin_id, $_POST['stop_id'], get_client_ip()]);
            
            echo json_encode([
                'success' => true,
                'message' => 'Bus stop updated successfully!'
            ]);
            
        } elseif ($_POST['action'] === 'delete_stop') {
            // Soft delete bus stop
            $stmt = $pdo->prepare("UPDATE bus_stops SET is_active = 0 WHERE stop_id = ?");
            $stmt->execute([$_POST['stop_id']]);
            
            // Log the activity
            $stmt = $pdo->prepare("
                INSERT INTO activity_logs (user_id, action_type, table_affected, record_id, ip_address)
                VALUES (?, 'delete', 'bus_stops', ?, ?)
            ");
            $stmt->execute([$admin_id, $_POST['stop_id'], get_client_ip()]);
            
            echo json_encode([
                'success' => true,
                'message' => 'Bus stop deleted successfully!'
            ]);
            
        } elseif ($_POST['action'] === 'get_stops') {
            // Get bus stops for a specific route
            $stmt = $pdo->prepare("
                SELECT bs.*, r.route_name 
                FROM bus_stops bs
                JOIN routes r ON bs.route_id = r.route_id
                WHERE bs.route_id = ? AND bs.is_active = 1
                ORDER BY bs.stop_order
            ");
            $stmt->execute([$_POST['route_id']]);
            $stops = $stmt->fetchAll();
            
            echo json_encode([
                'success' => true,
                'stops' => $stops
            ]);
        }
    } catch (PDOException $e) {
        echo json_encode([
            'success' => false,
            'message' => 'Database error: ' . $e->getMessage()
        ]);
    }
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Map-Based Bus Stop Management - Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .stat-card {
            border-radius: 10px;
            border: none;
            transition: transform 0.2s;
            border-left: 4px solid #007bff;
        }
        .stat-card:hover {
            transform: translateY(-5px);
        }
        .sidebar {
            background: #2c3e50;
            color: white;
            min-height: 100vh;
        }
        .sidebar .nav-link {
            color: #bdc3c7;
            padding: 12px 20px;
            border-radius: 5px;
            margin: 2px 0;
        }
        .sidebar .nav-link:hover, .sidebar .nav-link.active {
            background: #34495e;
            color: white;
        }
        .main-content {
            background: #f8f9fa;
            min-height: 100vh;
        }
        #map {
            height: 500px;
            width: 100%;
            border-radius: 8px;
            z-index: 1;
        }
        .map-container {
            position: relative;
        }
        .map-overlay {
            position: absolute;
            top: 10px;
            left: 10px;
            z-index: 1000;
            background: white;
            padding: 10px;
            border-radius: 5px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.2);
        }
        .stop-list {
            max-height: 400px;
            overflow-y: auto;
        }
        .selected-stop {
            background-color: #EFF6FF;
            border-left: 4px solid #3B82F6;
        }
        .coordinates-input {
            font-family: monospace;
            font-size: 0.875rem;
        }
        .bus-stop-marker {
            background: #3B82F6;
            border: 3px solid white;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.2);
        }
        .loading {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 3px solid rgba(255,255,255,.3);
            border-radius: 50%;
            border-top-color: #fff;
            animation: spin 1s ease-in-out infinite;
        }
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 sidebar p-0">
                <div class="p-3 border-bottom">
                    <h4 class="text-white mb-0">
                        <i class="fas fa-bus me-2"></i>Bus Tracker
                    </h4>
                    <small class="text-muted">Admin Panel</small>
                </div>
                <nav class="nav flex-column p-3">
                    <a class="nav-link" href="dashboard.php">
                        <i class="fas fa-tachometer-alt me-2"></i>Dashboard
                    </a>
                    <a class="nav-link" href="buses.php">
                        <i class="fas fa-bus me-2"></i>Buses
                    </a>
                    <a class="nav-link" href="assign_drivers.php">
                        <i class="fas fa-users me-2"></i>Drivers
                    </a>
                    <a class="nav-link" href="routes.php">
                        <i class="fas fa-route me-2"></i>Routes
                    </a>
                    <a class="nav-link" href="bus_stops.php">
                        <i class="fas fa-map-marker-alt me-2"></i>Bus Stops
                    </a>
                    <a class="nav-link active" href="bus_stops_map.php">
                        <i class="fas fa-map me-2"></i>Map Editor
                    </a>
                    <a class="nav-link" href="trips.php">
                        <i class="fas fa-shipping-fast me-2"></i>Trips
                    </a>
                    <a class="nav-link" href="passengers.php">
                        <i class="fas fa-user-friends me-2"></i>Passengers
                    </a>
                    <a class="nav-link" href="trip_details.php">
                        <i class="fas fa-chart-bar me-2"></i>Trip_Details
                    </a>
                    <a class="nav-link" href="system_alerts.php">
                        <i class="fas fa-bell me-2"></i>Alerts
                    </a>
                    <div class="mt-4 pt-3 border-top">
                        <a class="nav-link" href="logout.php">
                            <i class="fas fa-sign-out-alt me-2"></i>Logout
                        </a>
                    </div>
                </nav>
            </div>

            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 main-content p-0">
                <!-- Top Bar -->
                <nav class="navbar navbar-light bg-white border-bottom">
                    <div class="container-fluid">
                        <span class="navbar-text">
                            <i class="fas fa-user-shield me-2"></i>Welcome, <strong><?php echo htmlspecialchars($admin_name); ?></strong>
                        </span>
                        <div class="d-flex">
                            <span class="navbar-text me-3">
                                <i class="fas fa-clock me-1"></i><?php echo date('l, F j, Y'); ?>
                            </span>
                        </div>
                    </div>
                </nav>

                <div class="container-fluid p-4">
                    <!-- Page Header -->
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <div>
                            <h2 class="h4 mb-1">
                                <i class="fas fa-map-marked-alt me-2 text-primary"></i>Map-Based Bus Stop Management
                            </h2>
                            <p class="text-muted mb-0">Create and manage bus stops by clicking on the map</p>
                        </div>
                        <div class="d-flex gap-2">
                            <button class="btn btn-outline-primary" onclick="window.location.href='bus_stops.php'">
                                <i class="fas fa-list me-2"></i>List View
                            </button>
                        </div>
                    </div>

                    <!-- Alert Messages -->
                    <div id="statusMessage" class="alert alert-dismissible fade" role="alert">
                        <span id="statusText"></span>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>

                    <!-- Route Selection and Controls -->
                    <div class="row mb-4">
                        <div class="col-md-8">
                            <div class="card">
                                <div class="card-body">
                                    <div class="row g-3 align-items-center">
                                        <div class="col-md-4">
                                            <label for="routeSelect" class="form-label">Select Route</label>
                                            <select class="form-select" id="routeSelect">
                                                <?php foreach ($routes as $route): ?>
                                                    <option value="<?php echo $route['route_id']; ?>" 
                                                        <?php echo $route['route_id'] == $default_route_id ? 'selected' : ''; ?>>
                                                        <?php echo htmlspecialchars($route['route_name']); ?>
                                                    </option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                        <div class="col-md-4">
                                            <label class="form-label">Map Controls</label>
                                            <div class="d-flex gap-2">
                                                <button id="addStopModeBtn" class="btn btn-success">
                                                    <i class="fas fa-plus me-2"></i>Add Stop Mode
                                                </button>
                                                <button id="viewRouteBtn" class="btn btn-info">
                                                    <i class="fas fa-route me-2"></i>View Route
                                                </button>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <label class="form-label">Actions</label>
                                            <div class="d-flex gap-2">
                                                <button id="refreshBtn" class="btn btn-outline-secondary">
                                                    <i class="fas fa-sync-alt me-2"></i>Refresh
                                                </button>
                                                <button id="clearSelectionBtn" class="btn btn-outline-warning">
                                                    <i class="fas fa-times me-2"></i>Clear
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card bg-light">
                                <div class="card-body">
                                    <h6 class="card-title">
                                        <i class="fas fa-info-circle me-2 text-info"></i>Instructions
                                    </h6>
                                    <ol class="small mb-0">
                                        <li>Select a route from the dropdown</li>
                                        <li>Click "Add Stop Mode"</li>
                                        <li>Click on the map to place a stop</li>
                                        <li>Fill in the stop details</li>
                                        <li>Click "Save Stop" to add to database</li>
                                    </ol>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <!-- Map Section -->
                        <div class="col-lg-8 mb-4">
                            <div class="card">
                                <div class="card-header bg-white d-flex justify-content-between align-items-center">
                                    <h5 class="card-title mb-0">
                                        <i class="fas fa-map me-2"></i>Interactive Map
                                    </h5>
                                    <div class="d-flex align-items-center">
                                        <span id="mapStatus" class="badge bg-success me-2">
                                            <i class="fas fa-circle me-1"></i>Ready
                                        </span>
                                        <span id="stopCount" class="badge bg-primary">0 stops</span>
                                    </div>
                                </div>
                                <div class="card-body p-0">
                                    <div class="map-container">
                                        <div id="map"></div>
                                        <div class="map-overlay">
                                            <div class="btn-group-vertical">
                                                <button class="btn btn-sm btn-light" onclick="map.zoomIn()">
                                                    <i class="fas fa-plus"></i>
                                                </button>
                                                <button class="btn btn-sm btn-light" onclick="map.zoomOut()">
                                                    <i class="fas fa-minus"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Bus Stop Form and List -->
                        <div class="col-lg-4">
                            <div class="card">
                                <div class="card-header bg-white">
                                    <h5 class="card-title mb-0">
                                        <i class="fas fa-edit me-2"></i>
                                        <span id="formTitle">Add New Bus Stop</span>
                                    </h5>
                                </div>
                                <div class="card-body">
                                    <form id="busStopForm" class="needs-validation" novalidate>
                                        <input type="hidden" id="stopId">
                                        <input type="hidden" id="routeId" value="<?php echo $default_route_id; ?>">
                                        
                                        <div class="mb-3">
                                            <label for="stopName" class="form-label">Stop Name *</label>
                                            <input type="text" class="form-control" id="stopName" required>
                                            <div class="invalid-feedback">Please provide a stop name.</div>
                                        </div>
                                        
                                        <div class="mb-3">
                                            <label for="landmark" class="form-label">Landmark</label>
                                            <input type="text" class="form-control" id="landmark" placeholder="Nearby landmark">
                                        </div>
                                        
                                        <div class="row mb-3">
                                            <div class="col-md-6">
                                                <label for="latitude" class="form-label">Latitude *</label>
                                                <input type="text" class="form-control coordinates-input" id="latitude" readonly required>
                                            </div>
                                            <div class="col-md-6">
                                                <label for="longitude" class="form-label">Longitude *</label>
                                                <input type="text" class="form-control coordinates-input" id="longitude" readonly required>
                                            </div>
                                        </div>
                                        
                                        <div class="row mb-3">
                                            <div class="col-md-6">
                                                <label for="stopOrder" class="form-label">Stop Order *</label>
                                                <input type="number" class="form-control" id="stopOrder" min="1" required>
                                            </div>
                                            <div class="col-md-6">
                                                <label for="estimatedTime" class="form-label">Est. Time (min) *</label>
                                                <input type="number" class="form-control" id="estimatedTime" min="0" required>
                                            </div>
                                        </div>
                                        
                                        <div class="mb-3 form-check">
                                            <input type="checkbox" class="form-check-input" id="isActive" checked>
                                            <label class="form-check-label" for="isActive">Active Stop</label>
                                        </div>
                                        
                                        <div class="d-grid gap-2">
                                            <button type="submit" class="btn btn-primary" id="submitBtn">
                                                <i class="fas fa-save me-2"></i>Save Stop
                                            </button>
                                            <button type="button" class="btn btn-danger" id="deleteBtn" style="display: none;">
                                                <i class="fas fa-trash me-2"></i>Delete Stop
                                            </button>
                                            <button type="button" class="btn btn-secondary" id="cancelBtn" style="display: none;">
                                                <i class="fas fa-times me-2"></i>Cancel
                                            </button>
                                        </div>
                                    </form>
                                    
                                    <hr class="my-4">
                                    
                                    <h6 class="mb-3">
                                        <i class="fas fa-list me-2"></i>Bus Stops for Selected Route
                                    </h6>
                                    <div class="stop-list" id="stopsList">
                                        <div class="text-center py-4 text-muted">
                                            <div class="loading-spinner"></div>
                                            <p class="mt-2 mb-0">Loading stops...</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Delete Confirmation Modal -->
    <div class="modal fade" id="deleteModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title text-danger">
                        <i class="fas fa-exclamation-triangle me-2"></i>Confirm Deletion
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>Are you sure you want to delete the bus stop: <strong id="deleteStopName"></strong>?</p>
                    <p class="text-danger"><small>This action cannot be undone. The stop will be marked as inactive.</small></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="button" class="btn btn-danger" id="confirmDeleteBtn">
                        <i class="fas fa-trash me-2"></i>Delete Stop
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"></script>
    <script>
        // Global variables
        let map, markers = [], routePolyline = null;
        let isAddingMode = false;
        let selectedStop = null;
        let currentStops = [];
        let tempMarker = null;

        // Initialize the map
        function initMap() {
            // Create a map centered on Kurunagala
            map = L.map('map').setView([7.488133, 80.364240], 14);
            
            // Add OpenStreetMap tiles
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
                maxZoom: 18
            }).addTo(map);
            
            // Load stops for default route
            loadStopsForRoute(document.getElementById('routeSelect').value);
        }

        // Load stops for a specific route
        function loadStopsForRoute(routeId) {
            showLoadingStops();
            
            const formData = new FormData();
            formData.append('action', 'get_stops');
            formData.append('route_id', routeId);
            
            fetch('bus_stops_map.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    currentStops = data.stops;
                    renderStopsOnMap();
                    renderStopsList();
                    updateStopCount();
                } else {
                    showStatus('Error loading stops: ' + data.message, 'danger');
                }
            })
            .catch(error => {
                showStatus('Network error: ' + error.message, 'danger');
            });
        }

        // Render stops on the map
        function renderStopsOnMap() {
            // Clear existing markers
            markers.forEach(marker => map.removeLayer(marker));
            markers = [];
            
            // Add markers for each bus stop
            currentStops.forEach(stop => {
                const marker = L.marker([stop.latitude, stop.longitude], {
                    icon: L.divIcon({
                        className: 'bus-stop-marker',
                        html: `<div style="background: ${stop.is_active ? '#3B82F6' : '#6B7280'};" class="bus-stop-marker"></div>`,
                        iconSize: [20, 20],
                        iconAnchor: [10, 10]
                    })
                }).addTo(map);
                
                marker.bindPopup(`
                    <div class="p-2">
                        <h6 class="mb-1">${stop.stop_name}</h6>
                        <p class="mb-1 small">Order: ${stop.stop_order}</p>
                        <p class="mb-1 small">Est. Time: ${stop.estimated_time_from_start} min</p>
                        ${stop.landmark ? `<p class="mb-1 small">Landmark: ${stop.landmark}</p>` : ''}
                        <button class="btn btn-sm btn-primary mt-1" onclick="editStop(${stop.stop_id})">
                            <i class="fas fa-edit me-1"></i>Edit
                        </button>
                    </div>
                `);
                
                marker.stopData = stop;
                markers.push(marker);
            });
            
            // Draw route if there are enough stops
            if (currentStops.length > 1) {
                drawRoute();
            }
        }

        // Draw the route on the map
        function drawRoute() {
            // Remove existing route if any
            if (routePolyline) {
                map.removeLayer(routePolyline);
            }
            
            // Create points array from bus stops (sorted by order)
            const sortedStops = [...currentStops].sort((a, b) => a.stop_order - b.stop_order);
            const points = sortedStops.map(stop => [stop.latitude, stop.longitude]);
            
            // Draw the route
            routePolyline = L.polyline(points, {
                color: '#3B82F6',
                weight: 4,
                opacity: 0.7,
                dashArray: '5, 10'
            }).addTo(map);
        }

        // Render the list of bus stops
        function renderStopsList() {
            const stopsList = document.getElementById('stopsList');
            
            if (currentStops.length === 0) {
                stopsList.innerHTML = `
                    <div class="text-center py-4 text-muted">
                        <i class="fas fa-map-marker-alt fa-2x mb-3 opacity-50"></i>
                        <p>No bus stops found for this route.</p>
                        <p class="small">Click "Add Stop Mode" and then click on the map to create stops.</p>
                    </div>
                `;
                return;
            }
            
            // Sort stops by order
            const sortedStops = [...currentStops].sort((a, b) => a.stop_order - b.stop_order);
            
            let html = '';
            sortedStops.forEach(stop => {
                const isSelected = selectedStop && selectedStop.stop_id === stop.stop_id;
                html += `
                    <div class="p-3 border-bottom ${isSelected ? 'selected-stop' : ''}">
                        <div class="d-flex justify-content-between align-items-start">
                            <div class="flex-grow-1">
                                <h6 class="mb-1">${stop.stop_name}</h6>
                                <p class="mb-1 small text-muted">
                                    Order: ${stop.stop_order} | Time: ${stop.estimated_time_from_start} min
                                </p>
                                ${stop.landmark ? `<p class="mb-1 small text-muted">${stop.landmark}</p>` : ''}
                                <p class="mb-0 small text-muted">
                                    ${stop.latitude.toFixed(6)}, ${stop.longitude.toFixed(6)}
                                </p>
                            </div>
                            <div class="btn-group btn-group-sm">
                                <button class="btn btn-outline-primary" onclick="editStop(${stop.stop_id})" title="Edit">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <button class="btn btn-outline-danger" onclick="confirmDeleteStop(${stop.stop_id}, '${stop.stop_name}')" title="Delete">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                `;
            });
            
            stopsList.innerHTML = html;
        }

        // Show loading state in stops list
        function showLoadingStops() {
            document.getElementById('stopsList').innerHTML = `
                <div class="text-center py-4 text-muted">
                    <div class="loading-spinner"></div>
                    <p class="mt-2 mb-0">Loading stops...</p>
                </div>
            `;
        }

        // Update stop count display
        function updateStopCount() {
            document.getElementById('stopCount').textContent = `${currentStops.length} stops`;
        }

        // Show status message
        function showStatus(message, type = 'success') {
            const statusDiv = document.getElementById('statusMessage');
            const statusText = document.getElementById('statusText');
            
            statusDiv.className = `alert alert-${type} alert-dismissible fade show`;
            statusText.textContent = message;
            
            // Auto-hide after 5 seconds
            setTimeout(() => {
                const bsAlert = new bootstrap.Alert(statusDiv);
                bsAlert.close();
            }, 5000);
        }

        // Enter add stop mode
        function enterAddStopMode() {
            isAddingMode = true;
            document.getElementById('mapStatus').className = 'badge bg-warning me-2';
            document.getElementById('mapStatus').innerHTML = '<i class="fas fa-circle me-1"></i>Add Stop Mode';
            
            // Change cursor to crosshair
            map.getContainer().style.cursor = 'crosshair';
            
            // Add click event to map
            map.on('click', handleMapClick);
            
            showStatus('Click on the map to place a new bus stop', 'info');
        }

        // Exit add stop mode
        function exitAddStopMode() {
            isAddingMode = false;
            document.getElementById('mapStatus').className = 'badge bg-success me-2';
            document.getElementById('mapStatus').innerHTML = '<i class="fas fa-circle me-1"></i>Ready';
            
            // Reset cursor
            map.getContainer().style.cursor = '';
            
            // Remove click event
            map.off('click', handleMapClick);
            
            // Remove temporary marker
            if (tempMarker) {
                map.removeLayer(tempMarker);
                tempMarker = null;
            }
        }

        // Handle map click in add stop mode
        function handleMapClick(e) {
            const { lat, lng } = e.latlng;
            
            // Remove previous temporary marker
            if (tempMarker) {
                map.removeLayer(tempMarker);
            }
            
            // Add temporary marker
            tempMarker = L.marker([lat, lng], {
                icon: L.divIcon({
                    className: 'bus-stop-marker',
                    html: '<div style="background: #DC2626;" class="bus-stop-marker"></div>',
                    iconSize: [20, 20],
                    iconAnchor: [10, 10]
                }),
                zIndexOffset: 1000
            }).addTo(map).bindPopup('New Stop Location').openPopup();
            
            // Update form coordinates
            document.getElementById('latitude').value = lat.toFixed(6);
            document.getElementById('longitude').value = lng.toFixed(6);
            
            // Auto-generate stop order (next available)
            const nextOrder = currentStops.length > 0 ? 
                Math.max(...currentStops.map(s => s.stop_order)) + 1 : 1;
            document.getElementById('stopOrder').value = nextOrder;
            
            // Auto-generate estimated time (approximate)
            document.getElementById('estimatedTime').value = nextOrder * 2;
            
            showStatus('Location selected. Please fill in the stop details and click "Save Stop"', 'info');
        }

        // Edit a stop
        function editStop(stopId) {
            const stop = currentStops.find(s => s.stop_id === stopId);
            if (!stop) return;
            
            selectedStop = stop;
            
            // Update form fields
            document.getElementById('stopId').value = stop.stop_id;
            document.getElementById('stopName').value = stop.stop_name;
            document.getElementById('landmark').value = stop.landmark || '';
            document.getElementById('latitude').value = stop.latitude;
            document.getElementById('longitude').value = stop.longitude;
            document.getElementById('stopOrder').value = stop.stop_order;
            document.getElementById('estimatedTime').value = stop.estimated_time_from_start;
            document.getElementById('isActive').checked = stop.is_active == 1;
            document.getElementById('routeId').value = stop.route_id;
            
            // Update UI
            document.getElementById('formTitle').textContent = 'Edit Bus Stop';
            document.getElementById('deleteBtn').style.display = 'block';
            document.getElementById('cancelBtn').style.display = 'block';
            document.getElementById('submitBtn').innerHTML = '<i class="fas fa-save me-2"></i>Update Stop';
            
            // Pan to the stop on the map
            map.panTo([stop.latitude, stop.longitude]);
            
            // Highlight in list
            renderStopsList();
            
            exitAddStopMode();
        }

        // Reset form for new stop
        function resetForm() {
            document.getElementById('busStopForm').reset();
            document.getElementById('stopId').value = '';
            document.getElementById('formTitle').textContent = 'Add New Bus Stop';
            document.getElementById('deleteBtn').style.display = 'none';
            document.getElementById('cancelBtn').style.display = 'none';
            document.getElementById('submitBtn').innerHTML = '<i class="fas fa-save me-2"></i>Save Stop';
            document.getElementById('isActive').checked = true;
            document.getElementById('routeId').value = document.getElementById('routeSelect').value;
            
            selectedStop = null;
            renderStopsList();
        }

        // Confirm delete stop
        function confirmDeleteStop(stopId, stopName) {
            document.getElementById('deleteStopName').textContent = stopName;
            const deleteModal = new bootstrap.Modal(document.getElementById('deleteModal'));
            deleteModal.show();
            
            document.getElementById('confirmDeleteBtn').onclick = function() {
                deleteStop(stopId);
                deleteModal.hide();
            };
        }

        // Delete stop
        function deleteStop(stopId) {
            const formData = new FormData();
            formData.append('action', 'delete_stop');
            formData.append('stop_id', stopId);
            
            fetch('bus_stops_map.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    showStatus(data.message, 'success');
                    loadStopsForRoute(document.getElementById('routeSelect').value);
                    resetForm();
                } else {
                    showStatus('Error: ' + data.message, 'danger');
                }
            })
            .catch(error => {
                showStatus('Network error: ' + error.message, 'danger');
            });
        }

        // Initialize the page
        document.addEventListener('DOMContentLoaded', function() {
            // Initialize map
            initMap();
            
            // Event listeners
            document.getElementById('routeSelect').addEventListener('change', function() {
                document.getElementById('routeId').value = this.value;
                loadStopsForRoute(this.value);
                resetForm();
            });
            
            document.getElementById('addStopModeBtn').addEventListener('click', function() {
                if (isAddingMode) {
                    exitAddStopMode();
                    this.innerHTML = '<i class="fas fa-plus me-2"></i>Add Stop Mode';
                } else {
                    enterAddStopMode();
                    this.innerHTML = '<i class="fas fa-times me-2"></i>Cancel Mode';
                    resetForm();
                }
            });
            
            document.getElementById('viewRouteBtn').addEventListener('click', function() {
                if (currentStops.length > 1) {
                    drawRoute();
                    showStatus('Route displayed on map', 'info');
                } else {
                    showStatus('Need at least 2 stops to draw a route', 'warning');
                }
            });
            
            document.getElementById('refreshBtn').addEventListener('click', function() {
                loadStopsForRoute(document.getElementById('routeSelect').value);
                showStatus('Stops refreshed', 'info');
            });
            
            document.getElementById('clearSelectionBtn').addEventListener('click', function() {
                resetForm();
                exitAddStopMode();
                document.getElementById('addStopModeBtn').innerHTML = '<i class="fas fa-plus me-2"></i>Add Stop Mode';
                showStatus('Selection cleared', 'info');
            });
            
            document.getElementById('busStopForm').addEventListener('submit', function(e) {
                e.preventDefault();
                
                if (!this.checkValidity()) {
                    e.stopPropagation();
                    this.classList.add('was-validated');
                    return;
                }
                
                const formData = new FormData();
                const stopId = document.getElementById('stopId').value;
                
                if (stopId) {
                    formData.append('action', 'update_stop');
                    formData.append('stop_id', stopId);
                } else {
                    formData.append('action', 'add_stop');
                }
                
                formData.append('route_id', document.getElementById('routeId').value);
                formData.append('stop_name', document.getElementById('stopName').value);
                formData.append('landmark', document.getElementById('landmark').value);
                formData.append('latitude', document.getElementById('latitude').value);
                formData.append('longitude', document.getElementById('longitude').value);
                formData.append('stop_order', document.getElementById('stopOrder').value);
                formData.append('estimated_time', document.getElementById('estimatedTime').value);
                formData.append('is_active', document.getElementById('isActive').checked ? 1 : 0);
                
                fetch('bus_stops_map.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        showStatus(data.message, 'success');
                        loadStopsForRoute(document.getElementById('routeSelect').value);
                        resetForm();
                        exitAddStopMode();
                        document.getElementById('addStopModeBtn').innerHTML = '<i class="fas fa-plus me-2"></i>Add Stop Mode';
                    } else {
                        showStatus('Error: ' + data.message, 'danger');
                    }
                })
                .catch(error => {
                    showStatus('Network error: ' + error.message, 'danger');
                });
            });
            
            document.getElementById('deleteBtn').addEventListener('click', function() {
                if (selectedStop) {
                    confirmDeleteStop(selectedStop.stop_id, selectedStop.stop_name);
                }
            });
            
            document.getElementById('cancelBtn').addEventListener('click', function() {
                resetForm();
            });
        });
    </script>
</body>
</html>
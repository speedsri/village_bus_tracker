# Get all bus stops for route 1
curl "https://buslk.ru/new_bus_track/get_bus_stops.php?route_id=1"

# Add a new bus stop
curl -X POST https://buslk.ru/new_bus_track/add_bus_stop.php \
  -H "Content-Type: application/json" \
  -d '{
    "route_id": 1,
    "stop_name": "Test Stop",
    "stop_order": 7,
    "latitude": 7.486500,
    "longitude": 80.365500,
    "landmark": "Test Landmark",
    "estimated_time_from_start": 10
  }'

# Update a bus stop
curl -X POST https://buslk.ru/new_bus_track/update_bus_stop.php \
  -H "Content-Type: application/json" \
  -d '{
    "stop_id": 7,
    "stop_name": "Updated Stop Name"
  }'

# Delete a bus stop
curl -X POST https://buslk.ru/new_bus_track/delete_bus_stop.php \
  -H "Content-Type: application/json" \
  -d '{
    "stop_id": 7
  }'
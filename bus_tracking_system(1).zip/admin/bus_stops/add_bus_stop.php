<?php
// add_bus_stop.php
require_once 'db_connection.php';

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);

// Validate required fields
$required_fields = ['route_id', 'stop_name', 'stop_order', 'latitude', 'longitude'];
foreach ($required_fields as $field) {
    if (!isset($input[$field]) || empty($input[$field])) {
        echo json_encode([
            'success' => false,
            'message' => "Missing required field: $field"
        ]);
        exit;
    }
}

try {
    // Prepare SQL statement
    $stmt = $pdo->prepare("
        INSERT INTO bus_stops 
        (route_id, stop_name, stop_order, latitude, longitude, landmark, estimated_time_from_start, is_active) 
        VALUES 
        (:route_id, :stop_name, :stop_order, :latitude, :longitude, :landmark, :estimated_time_from_start, :is_active)
    ");
    
    // Execute with parameters
    $stmt->execute([
        'route_id' => $input['route_id'],
        'stop_name' => $input['stop_name'],
        'stop_order' => $input['stop_order'],
        'latitude' => $input['latitude'],
        'longitude' => $input['longitude'],
        'landmark' => $input['landmark'] ?? '',
        'estimated_time_from_start' => $input['estimated_time_from_start'] ?? 0,
        'is_active' => $input['is_active'] ?? 1
    ]);
    
    // Get the ID of the newly inserted stop
    $stop_id = $pdo->lastInsertId();
    
    echo json_encode([
        'success' => true,
        'message' => 'Bus stop added successfully',
        'stop_id' => $stop_id
    ]);
} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Error adding bus stop: ' . $e->getMessage()
    ]);
}
?>
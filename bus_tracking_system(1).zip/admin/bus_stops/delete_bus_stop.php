<?php
// delete_bus_stop.php
require_once 'db_connection.php';

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);

// Validate required field
if (!isset($input['stop_id']) || empty($input['stop_id'])) {
    echo json_encode([
        'success' => false,
        'message' => 'Missing required field: stop_id'
    ]);
    exit;
}

try {
    $stmt = $pdo->prepare("DELETE FROM bus_stops WHERE stop_id = :stop_id");
    $stmt->execute(['stop_id' => $input['stop_id']]);
    
    if ($stmt->rowCount() > 0) {
        echo json_encode([
            'success' => true,
            'message' => 'Bus stop deleted successfully'
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'No bus stop found with that ID'
        ]);
    }
} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Error deleting bus stop: ' . $e->getMessage()
    ]);
}
?>
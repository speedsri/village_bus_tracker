<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bus Stop Management - BusLK</title>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" />
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"></script>
    <style>
        #map { 
            height: 500px; 
            width: 100%;
            border-radius: 8px;
            z-index: 1;
        }
        .card {
            transition: all 0.3s ease;
        }
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
        }
        .sidebar {
            height: 500px;
            overflow-y: auto;
        }
        .bus-stop-marker {
            border-radius: 50%;
            background: #3B82F6;
            border: 3px solid white;
            box-shadow: 0 2px 4px rgba(0,0,0,0.2);
        }
        .selected-stop {
            background-color: #EFF6FF;
            border-left: 4px solid #3B82F6;
        }
        .loading {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 3px solid rgba(255,255,255,.3);
            border-radius: 50%;
            border-top-color: #fff;
            animation: spin 1s ease-in-out infinite;
        }
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
    </style>
</head>
<body class="bg-gray-100 min-h-screen">
    <div class="container mx-auto px-4 py-8">
        <!-- Header -->
        <header class="bg-blue-600 text-white p-4 rounded-lg shadow mb-6">
            <h1 class="text-2xl font-bold flex items-center">
                <i class="fas fa-map-marker-alt mr-2"></i> Bus Stop Management System
            </h1>
            <p class="mt-2">Manage bus stops for the Kurunagala to Alakoladeniya route</p>
        </header>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <!-- Map Section -->
            <div class="lg:col-span-2 bg-white p-4 rounded-lg shadow">
                <div class="flex justify-between items-center mb-4">
                    <h2 class="text-lg font-semibold">Route Map</h2>
                    <div class="flex space-x-2">
                        <button id="addStopBtn" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md flex items-center">
                            <i class="fas fa-plus mr-2"></i> Add Stop
                        </button>
                        <button id="viewRouteBtn" class="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-md flex items-center">
                            <i class="fas fa-route mr-2"></i> View Route
                        </button>
                        <button id="refreshBtn" class="bg-gray-600 hover:bg-gray-700 text-white px-4 py-2 rounded-md flex items-center">
                            <i class="fas fa-sync-alt mr-2"></i> Refresh
                        </button>
                    </div>
                </div>
                
                <div id="map" class="mb-4"></div>
                
                <div class="bg-gray-50 p-3 rounded-lg">
                    <p class="text-sm text-gray-600 mb-2">Instructions:</p>
                    <ol class="list-decimal pl-5 text-sm space-y-1">
                        <li>Click "Add Stop" to enter creation mode</li>
                        <li>Click on the map to place a new bus stop</li>
                        <li>Fill in the stop details in the form</li>
                        <li>Click "Save Stop" to add to the database</li>
                        <li>Click on existing stops to edit or delete them</li>
                    </ol>
                </div>
            </div>
            
            <!-- Bus Stop Form -->
            <div class="bg-white p-4 rounded-lg shadow sidebar">
                <h2 class="text-lg font-semibold mb-4" id="formTitle">Add New Bus Stop</h2>
                
                <form id="busStopForm" class="space-y-4">
                    <input type="hidden" id="stopId" value="">
                    <input type="hidden" id="routeId" value="1">
                    
                    <div>
                        <label for="stopName" class="block text-sm font-medium text-gray-700">Stop Name *</label>
                        <input type="text" id="stopName" name="stopName" required 
                               class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                    </div>
                    
                    <div>
                        <label for="landmark" class="block text-sm font-medium text-gray-700">Landmark</label>
                        <input type="text" id="landmark" name="landmark" 
                               class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                    </div>
                    
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label for="latitude" class="block text-sm font-medium text-gray-700">Latitude *</label>
                            <input type="number" id="latitude" name="latitude" step="any" required 
                                   class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                        </div>
                        
                        <div>
                            <label for="longitude" class="block text-sm font-medium text-gray-700">Longitude *</label>
                            <input type="number" id="longitude" name="longitude" step="any" required 
                                   class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                        </div>
                    </div>
                    
                    <div>
                        <label for="stopOrder" class="block text-sm font-medium text-gray-700">Stop Order *</label>
                        <input type="number" id="stopOrder" name="stopOrder" min="1" required 
                               class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                    </div>
                    
                    <div>
                        <label for="estimatedTime" class="block text-sm font-medium text-gray-700">Estimated Time from Start (minutes) *</label>
                        <input type="number" id="estimatedTime" name="estimatedTime" min="0" required 
                               class="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500">
                    </div>
                    
                    <div class="flex items-center">
                        <input type="checkbox" id="isActive" name="isActive" class="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded" checked>
                        <label for="isActive" class="ml-2 block text-sm text-gray-700">Active Stop</label>
                    </div>
                    
                    <div class="flex space-x-4 pt-4">
                        <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-md flex items-center">
                            <i class="fas fa-save mr-2"></i> Save Stop
                        </button>
                        <button type="button" id="deleteStopBtn" class="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-md flex items-center hidden">
                            <i class="fas fa-trash mr-2"></i> Delete Stop
                        </button>
                        <button type="button" id="cancelEditBtn" class="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded-md flex items-center hidden">
                            <i class="fas fa-times mr-2"></i> Cancel
                        </button>
                    </div>
                </form>
                
                <div class="mt-6 pt-4 border-t border-gray-200">
                    <h3 class="text-md font-semibold mb-2">Existing Bus Stops</h3>
                    <div id="stopsList" class="space-y-2">
                        <!-- Bus stops will be listed here -->
                        <div class="text-center py-4 text-gray-500">
                            <i class="fas fa-spinner loading"></i> Loading stops...
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Status Messages -->
        <div id="statusMessage" class="hidden p-4 rounded-lg mt-6"></div>
        
        <!-- API Testing Section -->
        <div class="bg-white p-6 rounded-lg shadow mt-6">
            <h3 class="text-lg font-semibold mb-4">API Testing</h3>
            <p class="mb-4">Test the API endpoints directly using these curl commands:</p>
            
            <div class="bg-gray-800 text-green-300 p-4 rounded-lg overflow-x-auto">
                <code class="text-sm">
                    <span class="block mb-2"># Get all bus stops for route 1</span>
                    <span class="block">curl "https://buslk.ru/new_bus_track/get_bus_stops.php?route_id=1"</span>
                    
                    <span class="block mt-4 mb-2"># Add a new bus stop</span>
                    <span class="block">curl -X POST https://buslk.ru/new_bus_track/add_bus_stop.php \</span>
                    <span class="block">-H "Content-Type: application/json" \</span>
                    <span class="block">-d '{</span>
                    <span class="block">  "route_id": 1,</span>
                    <span class="block">  "stop_name": "Test Stop",</span>
                    <span class="block">  "stop_order": 7,</span>
                    <span class="block">  "latitude": 7.486500,</span>
                    <span class="block">  "longitude": 80.365500,</span>
                    <span class="block">  "landmark": "Test Landmark",</span>
                    <span class="block">  "estimated_time_from_start": 10</span>
                    <span class="block">}'</span>
                    
                    <span class="block mt-4 mb-2"># Update a bus stop</span>
                    <span class="block">curl -X POST https://buslk.ru/new_bus_track/update_bus_stop.php \</span>
                    <span class="block">-H "Content-Type: application/json" \</span>
                    <span class="block">-d '{</span>
                    <span class="block">  "stop_id": 7,</span>
                    <span class="block">  "stop_name": "Updated Stop Name"</span>
                    <span class="block">}'</span>
                    
                    <span class="block mt-4 mb-2"># Delete a bus stop</span>
                    <span class="block">curl -X POST https://buslk.ru/new_bus_track/delete_bus_stop.php \</span>
                    <span class="block">-H "Content-Type: application/json" \</span>
                    <span class="block">-d '{</span>
                    <span class="block">  "stop_id": 7</span>
                    <span class="block">}'</span>
                </code>
            </div>
        </div>
    </div>

    <script>
        // Global variables
        let map, markers = [], routePolyline = null;
        let currentRouteId = 1; // Kurunagala to Alakoladeniya route
        let isAddingMode = false;
        let selectedStop = null;
        let busStops = [];

        // Initialize the map
        function initMap() {
            // Create a map centered on the first bus stop
            map = L.map('map').setView([7.4818, 80.3609], 14);
            
            // Add OpenStreetMap tiles
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            }).addTo(map);
            
            // Add click event to map for adding new stops
            map.on('click', function(e) {
                if (isAddingMode) {
                    document.getElementById('latitude').value = e.latlng.lat.toFixed(6);
                    document.getElementById('longitude').value = e.latlng.lng.toFixed(6);
                    
                    // Add a temporary marker
                    const tempMarker = L.marker(e.latlng, {
                        icon: L.icon({
                            iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-red.png',
                            iconSize: [25, 41],
                            iconAnchor: [12, 41]
                        }),
                        zIndexOffset: 1000
                    }).addTo(map).bindPopup('New Stop Location').openPopup();
                    
                    // Remove the marker after 3 seconds
                    setTimeout(() => {
                        map.removeLayer(tempMarker);
                    }, 3000);
                }
            });
            
            // Load bus stops from the server
            fetchBusStops();
        }

        // Fetch bus stops from the server
        async function fetchBusStops() {
            showLoadingStops();
            
            try {
                const response = await fetch(`get_bus_stops.php?route_id=${currentRouteId}`);
                const data = await response.json();
                
                if (data.success) {
                    busStops = data.data;
                    renderBusStops();
                } else {
                    showStatus('Error fetching bus stops: ' + data.message, true);
                }
            } catch (error) {
                showStatus('Network error: ' + error.message, true);
            }
        }

        // Render bus stops on the map
        function renderBusStops() {
            // Clear existing markers
            markers.forEach(marker => map.removeLayer(marker));
            markers = [];
            
            // Add markers for each bus stop
            busStops.forEach(stop => {
                const marker = L.marker([stop.latitude, stop.longitude], {
                    icon: L.icon({
                        iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-blue.png',
                        iconSize: [25, 41],
                        iconAnchor: [12, 41]
                    })
                }).addTo(map);
                
                marker.bindPopup(`
                    <strong>${stop.stop_name}</strong><br>
                    Order: ${stop.stop_order}<br>
                    Est. Time: ${stop.estimated_time_from_start} mins
                    ${stop.landmark ? `<br>Landmark: ${stop.landmark}` : ''}
                `);
                
                // Add click event to select stop
                marker.on('click', () => {
                    selectStop(stop);
                });
                
                markers.push(marker);
            });
            
            // Update the stops list
            renderStopsList();
        }

        // Show loading state in stops list
        function showLoadingStops() {
            document.getElementById('stopsList').innerHTML = `
                <div class="text-center py-4 text-gray-500">
                    <i class="fas fa-spinner loading"></i> Loading stops...
                </div>
            `;
        }

        // Render the list of bus stops
        function renderStopsList() {
            const stopsList = document.getElementById('stopsList');
            stopsList.innerHTML = '';
            
            if (busStops.length === 0) {
                stopsList.innerHTML = `
                    <div class="text-center py-4 text-gray-500">
                        No bus stops found. Click "Add Stop" to create the first one.
                    </div>
                `;
                return;
            }
            
            // Sort stops by their order
            const sortedStops = [...busStops].sort((a, b) => a.stop_order - b.stop_order);
            
            sortedStops.forEach(stop => {
                const stopElement = document.createElement('div');
                stopElement.className = 'p-3 border border-gray-200 rounded-md cursor-pointer';
                if (selectedStop && selectedStop.stop_id === stop.stop_id) {
                    stopElement.classList.add('selected-stop');
                }
                
                stopElement.innerHTML = `
                    <div class="flex justify-between items-start">
                        <div>
                            <p class="font-semibold">${stop.stop_name}</p>
                            <p class="text-sm text-gray-600">Order: ${stop.stop_order} | Est. Time: ${stop.estimated_time_from_start} mins</p>
                        </div>
                        <span class="bg-blue-100 text-blue-800 text-xs font-medium px-2 py-1 rounded">${stop.is_active ? 'Active' : 'Inactive'}</span>
                    </div>
                `;
                
                stopElement.addEventListener('click', () => {
                    selectStop(stop);
                    // Pan to the selected stop on the map
                    map.panTo([stop.latitude, stop.longitude]);
                    // Open the popup
                    markers.find(m => m.getLatLng().lat === stop.latitude && 
                                     m.getLatLng().lng === stop.longitude).openPopup();
                });
                
                stopsList.appendChild(stopElement);
            });
        }

        // Draw the route on the map
        function drawRoute() {
            // Remove existing route if any
            if (routePolyline) {
                map.removeLayer(routePolyline);
            }
            
            // Create points array from bus stops
            const points = busStops
                .sort((a, b) => a.stop_order - b.stop_order)
                .map(stop => [stop.latitude, stop.longitude]);
            
            // Draw the route
            routePolyline = L.polyline(points, {color: 'blue', weight: 4}).addTo(map);
            
            // Fit map to show the entire route
            map.fitBounds(routePolyline.getBounds());
        }

        // Select a bus stop for editing
        function selectStop(stop) {
            selectedStop = stop;
            
            // Update form fields
            document.getElementById('stopId').value = stop.stop_id;
            document.getElementById('stopName').value = stop.stop_name;
            document.getElementById('landmark').value = stop.landmark || '';
            document.getElementById('latitude').value = stop.latitude;
            document.getElementById('longitude').value = stop.longitude;
            document.getElementById('stopOrder').value = stop.stop_order;
            document.getElementById('estimatedTime').value = stop.estimated_time_from_start;
            document.getElementById('isActive').checked = stop.is_active == 1;
            
            // Update UI
            document.getElementById('formTitle').textContent = 'Edit Bus Stop';
            document.getElementById('deleteStopBtn').classList.remove('hidden');
            document.getElementById('cancelEditBtn').classList.remove('hidden');
            document.getElementById('addStopBtn').classList.add('hidden');
            
            // Highlight the selected stop in the list
            renderStopsList();
        }

        // Reset the form to add a new stop
        function resetForm() {
            document.getElementById('busStopForm').reset();
            document.getElementById('stopId').value = '';
            document.getElementById('routeId').value = currentRouteId;
            document.getElementById('formTitle').textContent = 'Add New Bus Stop';
            document.getElementById('deleteStopBtn').classList.add('hidden');
            document.getElementById('cancelEditBtn').classList.add('hidden');
            document.getElementById('addStopBtn').classList.remove('hidden');
            document.getElementById('isActive').checked = true;
            selectedStop = null;
            renderStopsList();
        }

        // Show status message
        function showStatus(message, isError = false) {
            const statusDiv = document.getElementById('statusMessage');
            statusDiv.className = isError ? 
                'bg-red-100 border border-red-400 text-red-700 p-4 rounded-lg' : 
                'bg-green-100 border border-green-400 text-green-700 p-4 rounded-lg';
            statusDiv.innerHTML = `<p>${message}</p>`;
            statusDiv.classList.remove('hidden');
            
            // Auto-hide after 5 seconds
            setTimeout(() => {
                statusDiv.classList.add('hidden');
            }, 5000);
        }

        // Save bus stop to the server
        async function saveBusStop(stopData) {
            const url = stopData.stop_id ? 'update_bus_stop.php' : 'add_bus_stop.php';
            
            try {
                const response = await fetch(url, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(stopData)
                });
                
                const data = await response.json();
                return data;
            } catch (error) {
                throw new Error('Network error: ' + error.message);
            }
        }

        // Delete bus stop from the server
        async function deleteBusStop(stopId) {
            try {
                const response = await fetch('delete_bus_stop.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ stop_id: stopId })
                });
                
                const data = await response.json();
                return data;
            } catch (error) {
                throw new Error('Network error: ' + error.message);
            }
        }

        // Initialize the page
        document.addEventListener('DOMContentLoaded', function() {
            // Initialize map
            initMap();
            
            // Event listeners
            document.getElementById('addStopBtn').addEventListener('click', function() {
                isAddingMode = true;
                resetForm();
                showStatus('Click on the map to select a location for the new bus stop');
            });
            
            document.getElementById('viewRouteBtn').addEventListener('click', function() {
                if (busStops.length > 1) {
                    drawRoute();
                    showStatus('Route displayed on map');
                } else {
                    showStatus('Need at least 2 stops to draw a route', true);
                }
            });
            
            document.getElementById('refreshBtn').addEventListener('click', function() {
                fetchBusStops();
                showStatus('Bus stops refreshed');
            });
            
            document.getElementById('busStopForm').addEventListener('submit', async function(e) {
                e.preventDefault();
                
                const formData = {
                    route_id: parseInt(document.getElementById('routeId').value),
                    stop_name: document.getElementById('stopName').value,
                    landmark: document.getElementById('landmark').value,
                    latitude: parseFloat(document.getElementById('latitude').value),
                    longitude: parseFloat(document.getElementById('longitude').value),
                    stop_order: parseInt(document.getElementById('stopOrder').value),
                    estimated_time_from_start: parseInt(document.getElementById('estimatedTime').value),
                    is_active: document.getElementById('isActive').checked ? 1 : 0
                };
                
                const stopId = document.getElementById('stopId').value;
                if (stopId) {
                    formData.stop_id = parseInt(stopId);
                }
                
                try {
                    const result = await saveBusStop(formData);
                    if (result.success) {
                        showStatus(result.message);
                        fetchBusStops();
                        resetForm();
                        isAddingMode = false;
                    } else {
                        showStatus('Error: ' + result.message, true);
                    }
                } catch (error) {
                    showStatus('Error: ' + error.message, true);
                }
            });
            
            document.getElementById('deleteStopBtn').addEventListener('click', async function() {
                if (!selectedStop) return;
                
                if (confirm(`Are you sure you want to delete "${selectedStop.stop_name}"?`)) {
                    try {
                        const result = await deleteBusStop(selectedStop.stop_id);
                        if (result.success) {
                            showStatus(result.message);
                            fetchBusStops();
                            resetForm();
                        } else {
                            showStatus('Error: ' + result.message, true);
                        }
                    } catch (error) {
                        showStatus('Error: ' + error.message, true);
                    }
                }
            });
            
            document.getElementById('cancelEditBtn').addEventListener('click', function() {
                resetForm();
                isAddingMode = false;
            });
        });
    </script>

    <!-- PHP API Endpoints -->
    <?php
    // Simulate PHP endpoints for demonstration
    // In a real application, these would be separate PHP files
    
    // Database configuration
    $host = 'localhost';
    $database = 'bus_tracking_system';
    $username = 'root';
    $password = '3f90d2f8923ba067';
    $charset = 'utf8mb4';
    
    // Helper function to return JSON responses
    function jsonResponse($success, $message, $data = null) {
        header('Content-Type: application/json');
        $response = ['success' => $success, 'message' => $message];
        if ($data !== null) $response['data'] = $data;
        echo json_encode($response);
        exit;
    }
    
    // GET Bus Stops endpoint
    if (isset($_GET['get_bus_stops'])) {
        try {
            $dsn = "mysql:host=$host;dbname=$database;charset=$charset";
            $pdo = new PDO($dsn, $username, $password);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
            $route_id = isset($_GET['route_id']) ? (int)$_GET['route_id'] : 1;
            $stmt = $pdo->prepare("SELECT * FROM bus_stops WHERE route_id = ? ORDER BY stop_order ASC");
            $stmt->execute([$route_id]);
            $stops = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            jsonResponse(true, 'Bus stops retrieved successfully', $stops);
        } catch (PDOException $e) {
            jsonResponse(false, 'Database error: ' . $e->getMessage());
        }
    }
    
    // POST Add Bus Stop endpoint
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_bus_stop'])) {
        try {
            $dsn = "mysql:host=$host;dbname=$database;charset=$charset";
            $pdo = new PDO($dsn, $username, $password);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
            $input = json_decode(file_get_contents('php://input'), true);
            
            $required_fields = ['route_id', 'stop_name', 'stop_order', 'latitude', 'longitude'];
            foreach ($required_fields as $field) {
                if (!isset($input[$field]) || empty($input[$field])) {
                    jsonResponse(false, "Missing required field: $field");
                }
            }
            
            $stmt = $pdo->prepare("
                INSERT INTO bus_stops 
                (route_id, stop_name, stop_order, latitude, longitude, landmark, estimated_time_from_start, is_active) 
                VALUES 
                (?, ?, ?, ?, ?, ?, ?, ?)
            ");
            
            $stmt->execute([
                $input['route_id'],
                $input['stop_name'],
                $input['stop_order'],
                $input['latitude'],
                $input['longitude'],
                $input['landmark'] ?? '',
                $input['estimated_time_from_start'] ?? 0,
                $input['is_active'] ?? 1
            ]);
            
            $stop_id = $pdo->lastInsertId();
            jsonResponse(true, 'Bus stop added successfully', ['stop_id' => $stop_id]);
        } catch (PDOException $e) {
            jsonResponse(false, 'Database error: ' . $e->getMessage());
        }
    }
    
    // POST Update Bus Stop endpoint
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_bus_stop'])) {
        try {
            $dsn = "mysql:host=$host;dbname=$database;charset=$charset";
            $pdo = new PDO($dsn, $username, $password);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
            $input = json_decode(file_get_contents('php://input'), true);
            
            if (!isset($input['stop_id']) || empty($input['stop_id'])) {
                jsonResponse(false, 'Missing required field: stop_id');
            }
            
            $allowed_fields = [
                'stop_name', 'stop_order', 'latitude', 'longitude', 
                'landmark', 'estimated_time_from_start', 'is_active'
            ];
            
            $update_fields = [];
            $params = ['stop_id' => $input['stop_id']];
            
            foreach ($allowed_fields as $field) {
                if (isset($input[$field])) {
                    $update_fields[] = "$field = :$field";
                    $params[$field] = $input[$field];
                }
            }
            
            if (empty($update_fields)) {
                jsonResponse(false, 'No fields to update');
            }
            
            $sql = "UPDATE bus_stops SET " . implode(', ', $update_fields) . " WHERE stop_id = :stop_id";
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            
            jsonResponse(true, 'Bus stop updated successfully');
        } catch (PDOException $e) {
            jsonResponse(false, 'Database error: ' . $e->getMessage());
        }
    }
    
    // POST Delete Bus Stop endpoint
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_bus_stop'])) {
        try {
            $dsn = "mysql:host=$host;dbname=$database;charset=$charset";
            $pdo = new PDO($dsn, $username, $password);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
            $input = json_decode(file_get_contents('php://input'), true);
            
            if (!isset($input['stop_id']) || empty($input['stop_id'])) {
                jsonResponse(false, 'Missing required field: stop_id');
            }
            
            $stmt = $pdo->prepare("DELETE FROM bus_stops WHERE stop_id = ?");
            $stmt->execute([$input['stop_id']]);
            
            if ($stmt->rowCount() > 0) {
                jsonResponse(true, 'Bus stop deleted successfully');
            } else {
                jsonResponse(false, 'No bus stop found with that ID');
            }
        } catch (PDOException $e) {
            jsonResponse(false, 'Database error: ' . $e->getMessage());
        }
    }
    ?>
</body>
</html>
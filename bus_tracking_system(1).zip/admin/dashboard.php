<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Start session at the very beginning
session_start();

require_once '../includes/config.php';
require_once '../includes/auth.php';

// Check admin auth
if (!isset($_SESSION['admin_id']) || !isset($_SESSION['admin_session_token'])) {
    header('Location: index.php');
    exit;
}

$admin_id = $_SESSION['admin_id'];
$admin_name = isset($_SESSION['admin_name']) ? $_SESSION['admin_name'] : 'Administrator';

// Verify admin session
try {
    $stmt = $pdo->prepare("
        SELECT us.*, u.user_type, u.full_name 
        FROM user_sessions us 
        JOIN users u ON us.user_id = u.user_id 
        WHERE us.user_id = ? AND us.session_token = ? AND us.is_active = 1
        AND u.user_type = 'admin' AND u.is_active = 1
    ");
    $stmt->execute([$admin_id, $_SESSION['admin_session_token']]);
    $session = $stmt->fetch();

    if (!$session) {
        session_destroy();
        header('Location: index.php?session=expired');
        exit;
    }
    
    // Update admin name from session data if available
    if (isset($session['full_name'])) {
        $admin_name = $session['full_name'];
    }
} catch (PDOException $e) {
    error_log("Session verification error: " . $e->getMessage());
    // Continue with basic session check
}

// Initialize all variables with default values
$stats = [
    'total_buses' => 0,
    'active_trips' => 0,
    'total_drivers' => 0,
    'total_routes' => 0,
    'total_passengers' => 0,
    'today_trips' => 0
];

$active_trips = [];
$recent_activities = [];
$system_alerts = [];

try {
    // Get dashboard statistics with error handling
    
    // Total buses
    $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM buses WHERE is_active = 1");
    if ($stmt->execute()) {
        $result = $stmt->fetch();
        $stats['total_buses'] = $result['total'] ?? 0;
    }

    // Active trips
    $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM bus_trips WHERE trip_status = 'in_progress'");
    if ($stmt->execute()) {
        $result = $stmt->fetch();
        $stats['active_trips'] = $result['total'] ?? 0;
    }

    // Total drivers
    $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM users WHERE user_type = 'driver' AND is_active = 1");
    if ($stmt->execute()) {
        $result = $stmt->fetch();
        $stats['total_drivers'] = $result['total'] ?? 0;
    }

    // Total routes
    $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM routes WHERE is_active = 1");
    if ($stmt->execute()) {
        $result = $stmt->fetch();
        $stats['total_routes'] = $result['total'] ?? 0;
    }

    // Total passengers
    $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM users WHERE user_type = 'passenger' AND is_active = 1");
    if ($stmt->execute()) {
        $result = $stmt->fetch();
        $stats['total_passengers'] = $result['total'] ?? 0;
    }

    // Today's trips count
    $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM bus_trips WHERE DATE(created_at) = CURDATE()");
    if ($stmt->execute()) {
        $result = $stmt->fetch();
        $stats['today_trips'] = $result['total'] ?? 0;
    }

    // Get active trips with details
    $stmt = $pdo->prepare("
        SELECT t.trip_id, b.bus_number, r.route_name, u.full_name as driver_name, 
               t.actual_start_time, t.current_stop_id, bs.stop_name as current_stop,
               bl.latitude, bl.longitude, bl.timestamp as last_location_update
        FROM bus_trips t
        JOIN buses b ON t.bus_id = b.bus_id
        JOIN routes r ON t.route_id = r.route_id
        JOIN users u ON t.driver_id = u.user_id
        LEFT JOIN bus_stops bs ON t.current_stop_id = bs.stop_id
        LEFT JOIN bus_locations bl ON t.trip_id = bl.trip_id AND bl.is_current_location = 1
        WHERE t.trip_status = 'in_progress'
        ORDER BY t.actual_start_time DESC
    ");
    if ($stmt->execute()) {
        $active_trips = $stmt->fetchAll();
    }

    // Get recent activity logs
    $stmt = $pdo->prepare("
        SELECT al.*, u.username, u.full_name
        FROM activity_logs al
        LEFT JOIN users u ON al.user_id = u.user_id
        ORDER BY al.timestamp DESC
        LIMIT 10
    ");
    if ($stmt->execute()) {
        $recent_activities = $stmt->fetchAll();
    }

    // Get system alerts
    $stmt = $pdo->prepare("
        SELECT sa.*, b.bus_number, r.route_name
        FROM system_alerts sa
        LEFT JOIN buses b ON sa.bus_id = b.bus_id
        LEFT JOIN routes r ON sa.route_id = r.route_id
        WHERE sa.is_active = 1
        ORDER BY sa.created_at DESC
        LIMIT 5
    ");
    if ($stmt->execute()) {
        $system_alerts = $stmt->fetchAll();
    }

} catch (PDOException $e) {
    error_log("Dashboard database error: " . $e->getMessage());
    // Variables already initialized with defaults, so we can continue
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Bus Tracking System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .stat-card {
            border-radius: 10px;
            border: none;
            transition: transform 0.2s;
            border-left: 4px solid #007bff;
        }
        .stat-card:hover {
            transform: translateY(-5px);
        }
        .stat-icon {
            font-size: 2rem;
            opacity: 0.8;
        }
        #adminMap {
            height: 400px;
            border-radius: 10px;
        }
        .sidebar {
            background: #2c3e50;
            color: white;
            min-height: 100vh;
        }
        .sidebar .nav-link {
            color: #bdc3c7;
            padding: 12px 20px;
            border-radius: 5px;
            margin: 2px 0;
        }
        .sidebar .nav-link:hover, .sidebar .nav-link.active {
            background: #34495e;
            color: white;
        }
        .main-content {
            background: #f8f9fa;
            min-height: 100vh;
        }
        .table-responsive {
            max-height: 400px;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 sidebar p-0">
                <div class="p-3 border-bottom">
                    <h4 class="text-white mb-0">
                        <i class="fas fa-bus me-2"></i>Bus Tracker
                    </h4>
                    <small class="text-muted">Admin Panel</small>
                </div>
                <nav class="nav flex-column p-3">
                    <a class="nav-link active" href="dashboard.php">
                        <i class="fas fa-tachometer-alt me-2"></i>Dashboard
                    </a>
                    <a class="nav-link" href="buses.php">
                        <i class="fas fa-bus me-2"></i>Buses
                    </a>
                    <a class="nav-link" href="assign_drivers.php">
                        <i class="fas fa-users me-2"></i>Drivers
                    </a>
                    <a class="nav-link" href="routes.php">
                        <i class="fas fa-route me-2"></i>Routes
                    </a>
                    
                    <a class="nav-link" href="trips.php">
                        <i class="fas fa-shipping-fast me-2"></i>Trips
                    </a>
                    <a class="nav-link" href="../passenger/index.php">
                        <i class="fas fa-user-friends me-2"></i>Passengers
                    </a>
                    <a class="nav-link" href="trip_details.php">
                        <i class="fas fa-chart-bar me-2"></i>Trip_Details
                    </a>
                    <a class="nav-link" href="system_alerts.php">
                        <i class="fas fa-bell me-2"></i>Alerts
                    </a>
                    <a class="nav-link" href="hault_management/index.php">
                        <i class="fas fa-bell me-2"></i>Bus Halt Creation
                    </a>                    
                    
                    <div class="mt-4 pt-3 border-top">
                        <a class="nav-link" href="logout.php">
                            <i class="fas fa-sign-out-alt me-2"></i>Logout
                        </a>
                    </div>
                </nav>
            </div>

            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 main-content p-0">
                <!-- Top Bar -->
                <nav class="navbar navbar-light bg-white border-bottom">
                    <div class="container-fluid">
                        <span class="navbar-text">
                            <i class="fas fa-user-shield me-2"></i>Welcome, <strong><?php echo htmlspecialchars($admin_name); ?></strong>
                        </span>
                        <div class="d-flex">
                            <span class="navbar-text me-3">
                                <i class="fas fa-clock me-1"></i><?php echo date('l, F j, Y'); ?>
                            </span>
                        </div>
                    </div>
                </nav>

                <div class="container-fluid p-4">
                    <!-- Welcome Alert -->
                    <div class="alert alert-primary mb-4">
                        <h4 class="alert-heading"><i class="fas fa-tachometer-alt me-2"></i>Admin Dashboard</h4>
                        <p class="mb-0">Welcome to the Bus Tracking System Admin Panel. Monitor all system activities from here.</p>
                    </div>

                    <!-- Statistics Cards -->
                    <div class="row mb-4">
                        <div class="col-xl-2 col-md-4 col-sm-6 mb-3">
                            <div class="card stat-card border-left-primary">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between">
                                        <div>
                                            <h4 class="card-title text-primary"><?php echo $stats['total_buses']; ?></h4>
                                            <p class="card-text text-muted">Total Buses</p>
                                        </div>
                                        <div class="stat-icon text-primary">
                                            <i class="fas fa-bus"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-2 col-md-4 col-sm-6 mb-3">
                            <div class="card stat-card border-left-success">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between">
                                        <div>
                                            <h4 class="card-title text-success"><?php echo $stats['active_trips']; ?></h4>
                                            <p class="card-text text-muted">Active Trips</p>
                                        </div>
                                        <div class="stat-icon text-success">
                                            <i class="fas fa-shipping-fast"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-2 col-md-4 col-sm-6 mb-3">
                            <div class="card stat-card border-left-warning">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between">
                                        <div>
                                            <h4 class="card-title text-warning"><?php echo $stats['total_drivers']; ?></h4>
                                            <p class="card-text text-muted">Drivers</p>
                                        </div>
                                        <div class="stat-icon text-warning">
                                            <i class="fas fa-users"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-2 col-md-4 col-sm-6 mb-3">
                            <div class="card stat-card border-left-info">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between">
                                        <div>
                                            <h4 class="card-title text-info"><?php echo $stats['total_routes']; ?></h4>
                                            <p class="card-text text-muted">Routes</p>
                                        </div>
                                        <div class="stat-icon text-info">
                                            <i class="fas fa-route"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-2 col-md-4 col-sm-6 mb-3">
                            <div class="card stat-card border-left-secondary">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between">
                                        <div>
                                            <h4 class="card-title text-secondary"><?php echo $stats['total_passengers']; ?></h4>
                                            <p class="card-text text-muted">Passengers</p>
                                        </div>
                                        <div class="stat-icon text-secondary">
                                            <i class="fas fa-user-friends"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-2 col-md-4 col-sm-6 mb-3">
                            <div class="card stat-card border-left-danger">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between">
                                        <div>
                                            <h4 class="card-title text-danger"><?php echo $stats['today_trips']; ?></h4>
                                            <p class="card-text text-muted">Today's Trips</p>
                                        </div>
                                        <div class="stat-icon text-danger">
                                            <i class="fas fa-calendar-day"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <!-- Active Trips -->
                        <div class="col-lg-6 mb-4">
                            <div class="card h-100">
                                <div class="card-header bg-success text-white d-flex justify-content-between align-items-center">
                                    <h5 class="card-title mb-0">
                                        <i class="fas fa-shipping-fast me-2"></i>Active Trips
                                    </h5>
                                    <span class="badge bg-light text-dark"><?php echo count($active_trips); ?> Active</span>
                                </div>
                                <div class="card-body p-0">
                                    <?php if (!empty($active_trips)): ?>
                                        <div class="table-responsive">
                                            <table class="table table-sm table-hover mb-0">
                                                <thead class="table-light">
                                                    <tr>
                                                        <th>Bus</th>
                                                        <th>Route</th>
                                                        <th>Driver</th>
                                                        <th>Current Stop</th>
                                                        <th>Started</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php foreach ($active_trips as $trip): ?>
                                                        <tr>
                                                            <td>
                                                                <i class="fas fa-bus text-primary me-1"></i>
                                                                <strong><?php echo htmlspecialchars($trip['bus_number']); ?></strong>
                                                            </td>
                                                            <td><?php echo htmlspecialchars($trip['route_name']); ?></td>
                                                            <td>
                                                                <i class="fas fa-user text-warning me-1"></i>
                                                                <?php echo htmlspecialchars($trip['driver_name']); ?>
                                                            </td>
                                                            <td>
                                                                <?php if (!empty($trip['current_stop'])): ?>
                                                                    <span class="badge bg-info"><?php echo htmlspecialchars($trip['current_stop']); ?></span>
                                                                <?php else: ?>
                                                                    <span class="badge bg-secondary">En route</span>
                                                                <?php endif; ?>
                                                            </td>
                                                            <td>
                                                                <small><?php echo date('H:i', strtotime($trip['actual_start_time'])); ?></small>
                                                            </td>
                                                        </tr>
                                                    <?php endforeach; ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    <?php else: ?>
                                        <div class="text-center py-4">
                                            <i class="fas fa-shipping-fast fa-3x text-muted mb-3"></i>
                                            <p class="text-muted">No active trips at the moment</p>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <!-- System Alerts -->
                        <div class="col-lg-6 mb-4">
                            <div class="card h-100">
                                <div class="card-header bg-warning text-dark d-flex justify-content-between align-items-center">
                                    <h5 class="card-title mb-0">
                                        <i class="fas fa-exclamation-triangle me-2"></i>System Alerts
                                    </h5>
                                    <span class="badge bg-danger"><?php echo count($system_alerts); ?> Alerts</span>
                                </div>
                                <div class="card-body p-0">
                                    <?php if (!empty($system_alerts)): ?>
                                        <div class="list-group list-group-flush">
                                            <?php foreach ($system_alerts as $alert): ?>
                                                <div class="list-group-item">
                                                    <div class="d-flex w-100 justify-content-between">
                                                        <h6 class="mb-1"><?php echo htmlspecialchars($alert['title']); ?></h6>
                                                        <small class="text-muted">
                                                            <?php 
                                                                $created = new DateTime($alert['created_at']);
                                                                $now = new DateTime();
                                                                $diff = $now->diff($created);
                                                                echo $diff->h . 'h ' . $diff->i . 'm ago';
                                                            ?>
                                                        </small>
                                                    </div>
                                                    <p class="mb-1"><?php echo htmlspecialchars($alert['message']); ?></p>
                                                    <small class="text-muted">
                                                        <?php if (!empty($alert['bus_number'])): ?>
                                                            Bus: <?php echo htmlspecialchars($alert['bus_number']); ?>
                                                        <?php endif; ?>
                                                        <?php if (!empty($alert['route_name'])): ?>
                                                            | Route: <?php echo htmlspecialchars($alert['route_name']); ?>
                                                        <?php endif; ?>
                                                    </small>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    <?php else: ?>
                                        <div class="text-center py-4">
                                            <i class="fas fa-check-circle fa-3x text-success mb-3"></i>
                                            <p class="text-muted">No active system alerts</p>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Recent Activity -->
                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header d-flex justify-content-between align-items-center">
                                    <h5 class="card-title mb-0">
                                        <i class="fas fa-history me-2"></i>Recent Activity
                                    </h5>
                                    <a href="activity_logs.php" class="btn btn-sm btn-outline-primary">View All</a>
                                </div>
                                <div class="card-body p-0">
                                    <div class="table-responsive">
                                        <table class="table table-sm table-striped mb-0">
                                            <thead class="table-light">
                                                <tr>
                                                    <th>Time</th>
                                                    <th>User</th>
                                                    <th>Action</th>
                                                    <th>Table</th>
                                                    <th>IP Address</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php if (!empty($recent_activities)): ?>
                                                    <?php foreach ($recent_activities as $activity): ?>
                                                        <tr>
                                                            <td>
                                                                <small><?php echo date('H:i:s', strtotime($activity['timestamp'])); ?></small>
                                                            </td>
                                                            <td>
                                                                <?php if (!empty($activity['full_name'])): ?>
                                                                    <i class="fas fa-user me-1 text-warning"></i>
                                                                    <?php echo htmlspecialchars($activity['full_name']); ?>
                                                                <?php elseif (!empty($activity['username'])): ?>
                                                                    <i class="fas fa-user me-1 text-info"></i>
                                                                    <?php echo htmlspecialchars($activity['username']); ?>
                                                                <?php else: ?>
                                                                    <i class="fas fa-robot me-1 text-secondary"></i>
                                                                    System
                                                                <?php endif; ?>
                                                            </td>
                                                            <td>
                                                                <span class="badge bg-<?php 
                                                                    switch($activity['action_type']) {
                                                                        case 'login': echo 'success'; break;
                                                                        case 'logout': echo 'secondary'; break;
                                                                        case 'create': echo 'primary'; break;
                                                                        case 'update': echo 'warning'; break;
                                                                        case 'delete': echo 'danger'; break;
                                                                        default: echo 'info';
                                                                    }
                                                                ?>">
                                                                    <?php echo htmlspecialchars($activity['action_type']); ?>
                                                                </span>
                                                            </td>
                                                            <td>
                                                                <small><?php echo !empty($activity['table_affected']) ? htmlspecialchars($activity['table_affected']) : 'N/A'; ?></small>
                                                            </td>
                                                            <td>
                                                                <small class="text-muted"><?php echo htmlspecialchars($activity['ip_address']); ?></small>
                                                            </td>
                                                        </tr>
                                                    <?php endforeach; ?>
                                                <?php else: ?>
                                                    <tr>
                                                        <td colspan="5" class="text-center py-3 text-muted">
                                                            <i class="fas fa-info-circle me-2"></i>No recent activity
                                                        </td>
                                                    </tr>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"></script>
    <script>
        // Auto refresh dashboard every 30 seconds
        setInterval(function() {
            // You can implement partial page refresh here if needed
            console.log('Dashboard auto-refresh check');
        }, 30000);

        // Initialize tooltips
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
        var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl)
        });
    </script>
</body>
</html>
<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Start session at the very beginning
session_start();

require_once '../includes/config.php';
require_once '../includes/auth.php';

// Check admin auth
if (!isset($_SESSION['admin_id']) || !isset($_SESSION['admin_session_token'])) {
    header('Location: index.php');
    exit;
}

$admin_id = $_SESSION['admin_id'];
$admin_name = isset($_SESSION['admin_name']) ? $_SESSION['admin_name'] : 'Administrator';

// Verify admin session
try {
    $stmt = $pdo->prepare("
        SELECT us.*, u.user_type, u.full_name 
        FROM user_sessions us 
        JOIN users u ON us.user_id = u.user_id 
        WHERE us.user_id = ? AND us.session_token = ? AND us.is_active = 1
        AND u.user_type = 'admin' AND u.is_active = 1
    ");
    $stmt->execute([$admin_id, $_SESSION['admin_session_token']]);
    $session = $stmt->fetch();

    if (!$session) {
        session_destroy();
        header('Location: index.php?session=expired');
        exit;
    }
} catch (PDOException $e) {
    error_log("Session verification error: " . $e->getMessage());
}

// Handle form submissions
$message = '';
$message_type = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_trip_status'])) {
        $trip_id = intval($_POST['trip_id']);
        $status = $_POST['status'];
        
        try {
            $stmt = $pdo->prepare("
                UPDATE bus_trips 
                SET trip_status = ? 
                WHERE trip_id = ?
            ");
            
            if ($stmt->execute([$status, $trip_id])) {
                $message = 'Trip status updated successfully!';
                $message_type = 'success';
                
                // Log the activity
                $stmt = $pdo->prepare("
                    INSERT INTO activity_logs (user_id, action_type, table_affected, record_id, new_values, ip_address)
                    VALUES (?, 'update_trip', 'bus_trips', ?, ?, ?)
                ");
                $stmt->execute([
                    $admin_id,
                    $trip_id,
                    json_encode(['status' => $status]),
                    $_SERVER['REMOTE_ADDR']
                ]);
            } else {
                $message = 'Failed to update trip status!';
                $message_type = 'error';
            }
        } catch (PDOException $e) {
            error_log("Trip update error: " . $e->getMessage());
            $message = 'Database error: ' . $e->getMessage();
            $message_type = 'error';
        }
    } elseif (isset($_POST['create_trip'])) {
        // Manually create a trip
        $bus_id = intval($_POST['bus_id']);
        $route_id = intval($_POST['route_id']);
        $driver_id = intval($_POST['driver_id']);
        $trip_direction = $_POST['trip_direction'];
        $scheduled_start = $_POST['scheduled_start'];
        
        try {
            // Check if bus is already on a trip
            $stmt = $pdo->prepare("
                SELECT trip_id FROM bus_trips 
                WHERE bus_id = ? AND trip_status = 'in_progress'
            ");
            $stmt->execute([$bus_id]);
            
            if ($stmt->fetch()) {
                $message = 'Bus is already on an active trip!';
                $message_type = 'error';
            } else {
                $scheduled_end = date('Y-m-d H:i:s', strtotime($scheduled_start . ' +2 hours'));
                
                $stmt = $pdo->prepare("
                    INSERT INTO bus_trips (bus_id, route_id, driver_id, trip_direction, scheduled_start_time, scheduled_end_time, trip_status)
                    VALUES (?, ?, ?, ?, ?, ?, 'scheduled')
                ");
                
                if ($stmt->execute([$bus_id, $route_id, $driver_id, $trip_direction, $scheduled_start, $scheduled_end])) {
                    $message = 'Trip created successfully!';
                    $message_type = 'success';
                    
                    // Log the activity
                    $stmt = $pdo->prepare("
                        INSERT INTO activity_logs (user_id, action_type, table_affected, record_id, new_values, ip_address)
                        VALUES (?, 'create_trip', 'bus_trips', ?, ?, ?)
                    ");
                    $stmt->execute([
                        $admin_id,
                        $pdo->lastInsertId(),
                        json_encode(['bus_id' => $bus_id, 'route_id' => $route_id, 'driver_id' => $driver_id]),
                        $_SERVER['REMOTE_ADDR']
                    ]);
                } else {
                    $message = 'Failed to create trip!';
                    $message_type = 'error';
                }
            }
        } catch (PDOException $e) {
            error_log("Trip creation error: " . $e->getMessage());
            $message = 'Database error: ' . $e->getMessage();
            $message_type = 'error';
        }
    }
}

// Get data for forms and display
$trips = [];
$drivers = [];
$buses = [];
$routes = [];

try {
    // Get trips with details
    $stmt = $pdo->query("
        SELECT 
            t.*,
            u.full_name as driver_name,
            b.bus_number,
            r.route_name,
            r.start_location,
            r.end_location,
            bs_current.stop_name as current_stop_name,
            (SELECT COUNT(*) FROM bus_locations WHERE trip_id = t.trip_id) as location_count
        FROM bus_trips t
        JOIN users u ON t.driver_id = u.user_id
        JOIN buses b ON t.bus_id = b.bus_id
        JOIN routes r ON t.route_id = r.route_id
        LEFT JOIN bus_stops bs_current ON t.current_stop_id = bs_current.stop_id
        ORDER BY t.created_at DESC
    ");
    $trips = $stmt->fetchAll();

    // Get active drivers
    $stmt = $pdo->query("
        SELECT user_id, full_name 
        FROM users 
        WHERE user_type = 'driver' AND is_active = 1 
        ORDER BY full_name
    ");
    $drivers = $stmt->fetchAll();

    // Get active buses
    $stmt = $pdo->query("
        SELECT bus_id, bus_number 
        FROM buses 
        WHERE is_active = 1 
        ORDER BY bus_number
    ");
    $buses = $stmt->fetchAll();

    // Get active routes
    $stmt = $pdo->query("
        SELECT route_id, route_name 
        FROM routes 
        WHERE is_active = 1 
        ORDER BY route_name
    ");
    $routes = $stmt->fetchAll();
} catch (PDOException $e) {
    error_log("Data fetch error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trip Management - Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .sidebar {
            background: #2c3e50;
            color: white;
            min-height: 100vh;
        }
        .sidebar .nav-link {
            color: #bdc3c7;
            padding: 12px 20px;
            border-radius: 5px;
            margin: 2px 0;
        }
        .sidebar .nav-link:hover, .sidebar .nav-link.active {
            background: #34495e;
            color: white;
        }
        .main-content {
            background: #f8f9fa;
            min-height: 100vh;
        }
        .card {
            box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
            border: 1px solid rgba(0, 0, 0, 0.125);
        }
        .status-scheduled { background-color: #fff3cd; color: #856404; }
        .status-in_progress { background-color: #d1ecf1; color: #0c5460; }
        .status-completed { background-color: #d4edda; color: #155724; }
        .status-cancelled { background-color: #f8d7da; color: #721c24; }
        .status-delayed { background-color: #fce9e5; color: #8b4513; }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 sidebar p-0">
                <div class="p-3 border-bottom">
                    <h4 class="text-white mb-0">
                        <i class="fas fa-bus me-2"></i>Bus Tracker
                    </h4>
                    <small class="text-muted">Admin Panel</small>
                </div>
                <nav class="nav flex-column p-3">
                    <a class="nav-link" href="dashboard.php">
                        <i class="fas fa-tachometer-alt me-2"></i>Dashboard
                    </a>
                    <a class="nav-link" href="buses.php">
                        <i class="fas fa-bus me-2"></i>Buses
                    </a>
                    <a class="nav-link" href="drivers.php">
                        <i class="fas fa-users me-2"></i>Drivers
                    </a>
                    <a class="nav-link" href="routes.php">
                        <i class="fas fa-route me-2"></i>Routes
                    </a>
                    <a class="nav-link" href="assign_drivers.php">
                        <i class="fas fa-calendar-check me-2"></i>Driver Assignments
                    </a>
                    <a class="nav-link active" href="trips.php">
                        <i class="fas fa-shipping-fast me-2"></i>Trips
                    </a>
                    <a class="nav-link" href="passengers.php">
                        <i class="fas fa-user-friends me-2"></i>Passengers
                    </a>
                    <a class="nav-link" href="reports.php">
                        <i class="fas fa-chart-bar me-2"></i>Reports
                    </a>
                    <a class="nav-link" href="system_alerts.php">
                        <i class="fas fa-bell me-2"></i>Alerts
                    </a>
                    <div class="mt-4 pt-3 border-top">
                        <a class="nav-link" href="logout.php">
                            <i class="fas fa-sign-out-alt me-2"></i>Logout
                        </a>
                    </div>
                </nav>
            </div>

            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 main-content p-0">
                <!-- Top Bar -->
                <nav class="navbar navbar-light bg-white border-bottom">
                    <div class="container-fluid">
                        <span class="navbar-text">
                            <i class="fas fa-user-shield me-2"></i>Welcome, <strong><?php echo htmlspecialchars($admin_name); ?></strong>
                        </span>
                        <div class="d-flex">
                            <span class="navbar-text me-3">
                                <i class="fas fa-clock me-1"></i><?php echo date('l, F j, Y'); ?>
                            </span>
                        </div>
                    </div>
                </nav>

                <div class="container-fluid p-4">
                    <!-- Page Header -->
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h2 class="h3 mb-0">
                            <i class="fas fa-shipping-fast me-2"></i>Trip Management
                        </h2>
                        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#createTripModal">
                            <i class="fas fa-plus-circle me-1"></i>Create Trip
                        </button>
                    </div>

                    <!-- Status Message -->
                    <?php if ($message): ?>
                        <div class="alert alert-<?php echo $message_type === 'success' ? 'success' : 'danger'; ?> alert-dismissible fade show" role="alert">
                            <?php echo htmlspecialchars($message); ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                        </div>
                    <?php endif; ?>

                    <!-- Trips Table -->
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title mb-0">
                                <i class="fas fa-list me-2"></i>All Trips
                            </h5>
                        </div>
                        <div class="card-body">
                            <?php if (!empty($trips)): ?>
                                <div class="table-responsive">
                                    <table class="table table-striped table-hover">
                                        <thead>
                                            <tr>
                                                <th>Trip ID</th>
                                                <th>Driver</th>
                                                <th>Bus</th>
                                                <th>Route</th>
                                                <th>Direction</th>
                                                <th>Scheduled Start</th>
                                                <th>Current Stop</th>
                                                <th>Status</th>
                                                <th>Locations</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($trips as $trip): ?>
                                                <tr>
                                                    <td>
                                                        <strong>#<?php echo $trip['trip_id']; ?></strong>
                                                    </td>
                                                    <td><?php echo htmlspecialchars($trip['driver_name']); ?></td>
                                                    <td><?php echo htmlspecialchars($trip['bus_number']); ?></td>
                                                    <td>
                                                        <?php echo htmlspecialchars($trip['route_name']); ?><br>
                                                        <small class="text-muted">
                                                            <?php echo htmlspecialchars($trip['start_location']); ?> → 
                                                            <?php echo htmlspecialchars($trip['end_location']); ?>
                                                        </small>
                                                    </td>
                                                    <td>
                                                        <span class="badge bg-info">
                                                            <?php echo ucfirst($trip['trip_direction']); ?>
                                                        </span>
                                                    </td>
                                                    <td>
                                                        <?php echo date('M j, g:i A', strtotime($trip['scheduled_start_time'])); ?>
                                                    </td>
                                                    <td>
                                                        <?php echo $trip['current_stop_name'] ? htmlspecialchars($trip['current_stop_name']) : '<span class="text-muted">Not started</span>'; ?>
                                                    </td>
                                                    <td>
                                                        <span class="badge status-<?php echo $trip['trip_status']; ?>">
                                                            <?php echo ucfirst(str_replace('_', ' ', $trip['trip_status'])); ?>
                                                        </span>
                                                    </td>
                                                    <td>
                                                        <span class="badge bg-secondary">
                                                            <?php echo $trip['location_count']; ?> updates
                                                        </span>
                                                    </td>
                                                    <td>
                                                        <div class="btn-group btn-group-sm">
                                                            <button type="button" class="btn btn-outline-primary" 
                                                                    data-bs-toggle="modal" data-bs-target="#editTripModal"
                                                                    onclick="editTrip(<?php echo htmlspecialchars(json_encode($trip)); ?>)">
                                                                <i class="fas fa-edit"></i>
                                                            </button>
                                                            <a href="trip_details.php?id=<?php echo $trip['trip_id']; ?>" 
                                                               class="btn btn-outline-info" title="View Details">
                                                                <i class="fas fa-eye"></i>
                                                            </a>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php else: ?>
                                <div class="text-center py-4">
                                    <i class="fas fa-shipping-fast fa-3x text-muted mb-3"></i>
                                    <p class="text-muted">No trips found.</p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Create Trip Modal -->
    <div class="modal fade" id="createTripModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Create New Trip</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form method="POST" id="createTripForm">
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="driver_id" class="form-label">Driver</label>
                                <select class="form-select" id="driver_id" name="driver_id" required>
                                    <option value="">Select Driver</option>
                                    <?php foreach ($drivers as $driver): ?>
                                        <option value="<?php echo $driver['user_id']; ?>">
                                            <?php echo htmlspecialchars($driver['full_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="bus_id" class="form-label">Bus</label>
                                <select class="form-select" id="bus_id" name="bus_id" required>
                                    <option value="">Select Bus</option>
                                    <?php foreach ($buses as $bus): ?>
                                        <option value="<?php echo $bus['bus_id']; ?>">
                                            <?php echo htmlspecialchars($bus['bus_number']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="route_id" class="form-label">Route</label>
                                <select class="form-select" id="route_id" name="route_id" required>
                                    <option value="">Select Route</option>
                                    <?php foreach ($routes as $route): ?>
                                        <option value="<?php echo $route['route_id']; ?>">
                                            <?php echo htmlspecialchars($route['route_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="trip_direction" class="form-label">Direction</label>
                                <select class="form-select" id="trip_direction" name="trip_direction" required>
                                    <option value="outbound">Outbound</option>
                                    <option value="return">Return</option>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="scheduled_start" class="form-label">Scheduled Start</label>
                                <input type="datetime-local" class="form-control" id="scheduled_start" name="scheduled_start" 
                                       value="<?php echo date('Y-m-d\TH:i'); ?>" required>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="create_trip" class="btn btn-primary">Create Trip</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Edit Trip Modal -->
    <div class="modal fade" id="editTripModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Update Trip Status</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form method="POST" id="editTripForm">
                    <div class="modal-body">
                        <input type="hidden" name="trip_id" id="edit_trip_id">
                        <div class="mb-3">
                            <label for="edit_status" class="form-label">Status</label>
                            <select class="form-select" id="edit_status" name="status" required>
                                <option value="scheduled">Scheduled</option>
                                <option value="in_progress">In Progress</option>
                                <option value="completed">Completed</option>
                                <option value="cancelled">Cancelled</option>
                                <option value="delayed">Delayed</option>
                            </select>
                        </div>
                        <div class="alert alert-info">
                            <small>
                                <i class="fas fa-info-circle me-1"></i>
                                Changing trip status will affect driver app functionality.
                            </small>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="update_trip_status" class="btn btn-primary">Update Status</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function editTrip(trip) {
            document.getElementById('edit_trip_id').value = trip.trip_id;
            document.getElementById('edit_status').value = trip.trip_status;
        }

        // Set minimum datetime to current time
        document.getElementById('scheduled_start').min = new Date().toISOString().slice(0, 16);
    </script>
</body>
</html>
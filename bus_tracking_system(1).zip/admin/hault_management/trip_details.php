<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Start session at the very beginning
session_start();

require_once '../includes/config.php';
require_once '../includes/auth.php';

// Check admin auth
if (!isset($_SESSION['admin_id']) || !isset($_SESSION['admin_session_token'])) {
    header('Location: index.php');
    exit;
}

$admin_id = $_SESSION['admin_id'];
$admin_name = isset($_SESSION['admin_name']) ? $_SESSION['admin_name'] : 'Administrator';

// Verify admin session
try {
    $stmt = $pdo->prepare("
        SELECT us.*, u.user_type, u.full_name 
        FROM user_sessions us 
        JOIN users u ON us.user_id = u.user_id 
        WHERE us.user_id = ? AND us.session_token = ? AND us.is_active = 1
        AND u.user_type = 'admin' AND u.is_active = 1
    ");
    $stmt->execute([$admin_id, $_SESSION['admin_session_token']]);
    $session = $stmt->fetch();

    if (!$session) {
        session_destroy();
        header('Location: index.php?session=expired');
        exit;
    }
} catch (PDOException $e) {
    error_log("Session verification error: " . $e->getMessage());
}

// Get trip ID from URL
$trip_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if (!$trip_id) {
    header('Location: trips.php');
    exit;
}

// Get trip details
$trip = [];
$locations = [];
$stop_arrivals = [];

try {
    // Get trip details
    $stmt = $pdo->prepare("
        SELECT 
            t.*,
            u.full_name as driver_name,
            b.bus_number,
            r.route_name,
            r.start_location,
            r.end_location,
            bs_current.stop_name as current_stop_name
        FROM bus_trips t
        JOIN users u ON t.driver_id = u.user_id
        JOIN buses b ON t.bus_id = b.bus_id
        JOIN routes r ON t.route_id = r.route_id
        LEFT JOIN bus_stops bs_current ON t.current_stop_id = bs_current.stop_id
        WHERE t.trip_id = ?
    ");
    $stmt->execute([$trip_id]);
    $trip = $stmt->fetch();

    if (!$trip) {
        header('Location: trips.php');
        exit;
    }

    // Get location history
    $stmt = $pdo->prepare("
        SELECT *
        FROM bus_locations 
        WHERE trip_id = ?
        ORDER BY timestamp DESC
    ");
    $stmt->execute([$trip_id]);
    $locations = $stmt->fetchAll();

    // Get stop arrivals
    $stmt = $pdo->prepare("
        SELECT sa.*, bs.stop_name
        FROM stop_arrivals sa
        JOIN bus_stops bs ON sa.stop_id = bs.stop_id
        WHERE sa.trip_id = ?
        ORDER BY sa.scheduled_arrival_time
    ");
    $stmt->execute([$trip_id]);
    $stop_arrivals = $stmt->fetchAll();
} catch (PDOException $e) {
    error_log("Trip details fetch error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Trip Details - Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .sidebar {
            background: #2c3e50;
            color: white;
            min-height: 100vh;
        }
        .sidebar .nav-link {
            color: #bdc3c7;
            padding: 12px 20px;
            border-radius: 5px;
            margin: 2px 0;
        }
        .sidebar .nav-link:hover, .sidebar .nav-link.active {
            background: #34495e;
            color: white;
        }
        .main-content {
            background: #f8f9fa;
            min-height: 100vh;
        }
        .card {
            box-shadow: 0 0.125rem 0.25rem rgba(0, 0, 0, 0.075);
            border: 1px solid rgba(0, 0, 0, 0.125);
        }
        .location-item {
            border-left: 4px solid #007bff;
            padding: 10px;
            margin-bottom: 8px;
            background: #f8f9fa;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 sidebar p-0">
                <div class="p-3 border-bottom">
                    <h4 class="text-white mb-0">
                        <i class="fas fa-bus me-2"></i>Bus Tracker
                    </h4>
                    <small class="text-muted">Admin Panel</small>
                </div>
                <nav class="nav flex-column p-3">
                    <a class="nav-link" href="dashboard.php">
                        <i class="fas fa-tachometer-alt me-2"></i>Dashboard
                    </a>
                    <a class="nav-link" href="buses.php">
                        <i class="fas fa-bus me-2"></i>Buses
                    </a>
                    <a class="nav-link" href="drivers.php">
                        <i class="fas fa-users me-2"></i>Drivers
                    </a>
                    <a class="nav-link" href="routes.php">
                        <i class="fas fa-route me-2"></i>Routes
                    </a>
                    <a class="nav-link" href="assign_drivers.php">
                        <i class="fas fa-calendar-check me-2"></i>Driver Assignments
                    </a>
                    <a class="nav-link active" href="trips.php">
                        <i class="fas fa-shipping-fast me-2"></i>Trips
                    </a>
                    <a class="nav-link" href="passengers.php">
                        <i class="fas fa-user-friends me-2"></i>Passengers
                    </a>
                    <a class="nav-link" href="reports.php">
                        <i class="fas fa-chart-bar me-2"></i>Reports
                    </a>
                    <a class="nav-link" href="system_alerts.php">
                        <i class="fas fa-bell me-2"></i>Alerts
                    </a>
                    <div class="mt-4 pt-3 border-top">
                        <a class="nav-link" href="logout.php">
                            <i class="fas fa-sign-out-alt me-2"></i>Logout
                        </a>
                    </div>
                </nav>
            </div>

            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 main-content p-0">
                <!-- Top Bar -->
                <nav class="navbar navbar-light bg-white border-bottom">
                    <div class="container-fluid">
                        <span class="navbar-text">
                            <i class="fas fa-user-shield me-2"></i>Welcome, <strong><?php echo htmlspecialchars($admin_name); ?></strong>
                        </span>
                        <div class="d-flex">
                            <span class="navbar-text me-3">
                                <i class="fas fa-clock me-1"></i><?php echo date('l, F j, Y'); ?>
                            </span>
                        </div>
                    </div>
                </nav>

                <div class="container-fluid p-4">
                    <!-- Page Header -->
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <div>
                            <h2 class="h3 mb-0">
                                <i class="fas fa-shipping-fast me-2"></i>Trip Details
                            </h2>
                            <nav aria-label="breadcrumb">
                                <ol class="breadcrumb mb-0">
                                    <li class="breadcrumb-item"><a href="trips.php">Trips</a></li>
                                    <li class="breadcrumb-item active">Trip #<?php echo $trip_id; ?></li>
                                </ol>
                            </nav>
                        </div>
                        <a href="trips.php" class="btn btn-outline-secondary">
                            <i class="fas fa-arrow-left me-1"></i>Back to Trips
                        </a>
                    </div>

                    <!-- Trip Overview -->
                    <div class="row mb-4">
                        <div class="col-md-4">
                            <div class="card">
                                <div class="card-body">
                                    <h6 class="card-title text-muted">Driver</h6>
                                    <p class="card-text h5"><?php echo htmlspecialchars($trip['driver_name']); ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card">
                                <div class="card-body">
                                    <h6 class="card-title text-muted">Bus</h6>
                                    <p class="card-text h5"><?php echo htmlspecialchars($trip['bus_number']); ?></p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="card">
                                <div class="card-body">
                                    <h6 class="card-title text-muted">Status</h6>
                                    <p class="card-text h5">
                                        <span class="badge bg-<?php 
                                            switch($trip['trip_status']) {
                                                case 'in_progress': echo 'primary'; break;
                                                case 'completed': echo 'success'; break;
                                                case 'cancelled': echo 'danger'; break;
                                                case 'delayed': echo 'warning'; break;
                                                default: echo 'secondary';
                                            }
                                        ?>">
                                            <?php echo ucfirst(str_replace('_', ' ', $trip['trip_status'])); ?>
                                        </span>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <!-- Location History -->
                        <div class="col-lg-6 mb-4">
                            <div class="card">
                                <div class="card-header">
                                    <h5 class="card-title mb-0">
                                        <i class="fas fa-map-marker-alt me-2"></i>Location History
                                    </h5>
                                </div>
                                <div class="card-body">
                                    <?php if (!empty($locations)): ?>
                                        <div style="max-height: 400px; overflow-y: auto;">
                                            <?php foreach ($locations as $location): ?>
                                                <div class="location-item">
                                                    <div class="d-flex justify-content-between">
                                                        <strong>
                                                            <?php echo $location['latitude']; ?>, <?php echo $location['longitude']; ?>
                                                        </strong>
                                                        <small class="text-muted">
                                                            <?php echo date('H:i:s', strtotime($location['timestamp'])); ?>
                                                        </small>
                                                    </div>
                                                    <div class="small text-muted">
                                                        Speed: <?php echo $location['speed_kmh'] ? $location['speed_kmh'] . ' km/h' : 'N/A'; ?> |
                                                        Accuracy: <?php echo $location['accuracy_meters'] ? $location['accuracy_meters'] . 'm' : 'N/A'; ?>
                                                    </div>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                    <?php else: ?>
                                        <p class="text-muted text-center py-4">No location data available</p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <!-- Trip Information -->
                        <div class="col-lg-6 mb-4">
                            <div class="card">
                                <div class="card-header">
                                    <h5 class="card-title mb-0">
                                        <i class="fas fa-info-circle me-2"></i>Trip Information
                                    </h5>
                                </div>
                                <div class="card-body">
                                    <table class="table table-sm">
                                        <tr>
                                            <td><strong>Route:</strong></td>
                                            <td><?php echo htmlspecialchars($trip['route_name']); ?></td>
                                        </tr>
                                        <tr>
                                            <td><strong>Direction:</strong></td>
                                            <td><?php echo ucfirst($trip['trip_direction']); ?></td>
                                        </tr>
                                        <tr>
                                            <td><strong>Scheduled Start:</strong></td>
                                            <td><?php echo date('M j, Y g:i A', strtotime($trip['scheduled_start_time'])); ?></td>
                                        </tr>
                                        <tr>
                                            <td><strong>Actual Start:</strong></td>
                                            <td>
                                                <?php echo $trip['actual_start_time'] ? 
                                                    date('M j, Y g:i A', strtotime($trip['actual_start_time'])) : 
                                                    '<span class="text-muted">Not started</span>'; ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td><strong>Scheduled End:</strong></td>
                                            <td><?php echo date('M j, Y g:i A', strtotime($trip['scheduled_end_time'])); ?></td>
                                        </tr>
                                        <tr>
                                            <td><strong>Actual End:</strong></td>
                                            <td>
                                                <?php echo $trip['actual_end_time'] ? 
                                                    date('M j, Y g:i A', strtotime($trip['actual_end_time'])) : 
                                                    '<span class="text-muted">Not ended</span>'; ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td><strong>Current Stop:</strong></td>
                                            <td>
                                                <?php echo $trip['current_stop_name'] ? 
                                                    htmlspecialchars($trip['current_stop_name']) : 
                                                    '<span class="text-muted">Not set</span>'; ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td><strong>Passenger Count:</strong></td>
                                            <td><?php echo $trip['passenger_count']; ?></td>
                                        </tr>
                                        <tr>
                                            <td><strong>Created:</strong></td>
                                            <td><?php echo date('M j, Y g:i A', strtotime($trip['created_at'])); ?></td>
                                        </tr>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Stop Arrivals -->
                    <?php if (!empty($stop_arrivals)): ?>
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title mb-0">
                                <i class="fas fa-map-pin me-2"></i>Stop Arrivals
                            </h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-sm table-striped">
                                    <thead>
                                        <tr>
                                            <th>Stop Name</th>
                                            <th>Scheduled Arrival</th>
                                            <th>Actual Arrival</th>
                                            <th>Departure</th>
                                            <th>Delay</th>
                                            <th>Passengers On</th>
                                            <th>Passengers Off</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($stop_arrivals as $arrival): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($arrival['stop_name']); ?></td>
                                                <td><?php echo date('H:i', strtotime($arrival['scheduled_arrival_time'])); ?></td>
                                                <td>
                                                    <?php echo $arrival['actual_arrival_time'] ? 
                                                        date('H:i', strtotime($arrival['actual_arrival_time'])) : 
                                                        '<span class="text-muted">Not arrived</span>'; ?>
                                                </td>
                                                <td>
                                                    <?php echo $arrival['departure_time'] ? 
                                                        date('H:i', strtotime($arrival['departure_time'])) : 
                                                        '<span class="text-muted">Not departed</span>'; ?>
                                                </td>
                                                <td>
                                                    <?php if ($arrival['delay_minutes']): ?>
                                                        <span class="badge bg-<?php echo $arrival['delay_minutes'] > 0 ? 'warning' : 'success'; ?>">
                                                            <?php echo $arrival['delay_minutes']; ?> min
                                                        </span>
                                                    <?php else: ?>
                                                        <span class="text-muted">-</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td><?php echo $arrival['passenger_count_on']; ?></td>
                                                <td><?php echo $arrival['passenger_count_off']; ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
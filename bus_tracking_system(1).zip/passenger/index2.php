<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BusLK - Real-time Bus Tracker</title>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" />
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"></script>
    <style>
        :root {
            --primary-color: #3B82F6;
            --secondary-color: #1E40AF;
            --accent-color: #F59E0B;
            --success-color: #10B981;
            --warning-color: #F59E0B;
            --danger-color: #EF4444;
        }
        
        #map {
            height: 400px;
            width: 100%;
            border-radius: 16px;
            z-index: 1;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
        }
        
        .glass-effect {
            background: rgba(255, 255, 255, 0.25);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.18);
        }
        
        .card {
            border-radius: 16px;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            border: 1px solid rgba(255, 255, 255, 0.2);
            overflow: hidden;
        }
        
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1);
        }
        
        .stop-list {
            max-height: 400px;
            overflow-y: auto;
            scrollbar-width: thin;
        }
        
        .stop-list::-webkit-scrollbar {
            width: 6px;
        }
        
        .stop-list::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 10px;
        }
        
        .stop-list::-webkit-scrollbar-thumb {
            background: var(--primary-color);
            border-radius: 10px;
        }
        
        .current-stop {
            background: linear-gradient(135deg, #E1F5FE 0%, #B3E5FC 100%);
            border-left: 4px solid var(--primary-color);
            position: relative;
        }
        
        .current-stop::before {
            content: '';
            position: absolute;
            left: 0;
            top: 0;
            height: 100%;
            width: 3px;
            background: var(--primary-color);
            animation: pulse 2s infinite;
        }
        
        .passed-stop {
            color: #9CA3AF;
            opacity: 0.7;
        }
        
        .next-stop {
            background: linear-gradient(135deg, #F0F9FF 0%, #E0F2FE 100%);
            border-left: 4px solid var(--success-color);
        }
        
        .bus-marker {
            filter: drop-shadow(0 4px 8px rgba(0,0,0,0.3));
        }
        
        .pulse-dot {
            animation: pulse 2s infinite;
        }
        
        @keyframes pulse {
            0% { transform: scale(1); opacity: 1; }
            50% { transform: scale(1.2); opacity: 0.7; }
            100% { transform: scale(1); opacity: 1; }
        }
        
        .progress-container {
            position: relative;
            height: 12px;
            background: linear-gradient(90deg, #E5E7EB 0%, #F3F4F6 100%);
            border-radius: 10px;
            overflow: hidden;
            box-shadow: inset 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .progress-fill {
            height: 100%;
            background: linear-gradient(90deg, var(--success-color) 0%, #34D399 100%);
            border-radius: 10px;
            transition: width 0.8s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
            overflow: hidden;
        }
        
        .progress-fill::after {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.4), transparent);
            animation: shimmer 2s infinite;
        }
        
        @keyframes shimmer {
            0% { left: -100%; }
            100% { left: 100%; }
        }
        
        .stop-marker {
            position: absolute;
            top: 50%;
            transform: translate(-50%, -50%);
            width: 8px;
            height: 8px;
            border-radius: 50%;
            background: #6B7280;
            border: 2px solid white;
            box-shadow: 0 2px 4px rgba(0,0,0,0.2);
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .stop-marker:hover {
            transform: translate(-50%, -50%) scale(1.5);
        }
        
        .stop-marker.passed {
            background: var(--success-color);
        }
        
        .stop-marker.current {
            background: var(--primary-color);
            animation: pulse 1.5s infinite;
            transform: translate(-50%, -50%) scale(1.3);
        }
        
        .stop-marker.next {
            background: var(--warning-color);
        }
        
        .status-indicator {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            margin-right: 0.5rem;
            display: inline-block;
        }
        
        .online {
            background: linear-gradient(135deg, var(--success-color) 0%, #059669 100%);
            box-shadow: 0 0 8px rgba(16, 185, 129, 0.4);
        }
        
        .offline {
            background: linear-gradient(135deg, var(--danger-color) 0%, #DC2626 100%);
        }
        
        .trip-status {
            font-size: 0.75rem;
            padding: 0.25rem 0.75rem;
            border-radius: 20px;
            margin-left: 0.5rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .trip-active {
            background: linear-gradient(135deg, var(--success-color) 0%, #059669 100%);
            color: white;
            box-shadow: 0 2px 4px rgba(16, 185, 129, 0.3);
        }
        
        .trip-inactive {
            background: linear-gradient(135deg, var(--warning-color) 0%, #D97706 100%);
            color: white;
        }
        
        .trip-not-started {
            background: linear-gradient(135deg, #9CA3AF 0%, #6B7280 100%);
            color: white;
        }
        
        .trip-completed {
            background: linear-gradient(135deg, var(--primary-color) 0%, #1D4ED8 100%);
            color: white;
        }
        
        .loading-spinner {
            border: 3px solid #f3f3f3;
            border-top: 3px solid var(--primary-color);
            border-radius: 50%;
            width: 20px;
            height: 20px;
            animation: spin 1s linear infinite;
            display: inline-block;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .notification-badge {
            position: absolute;
            top: -5px;
            right: -5px;
            background: var(--danger-color);
            color: white;
            border-radius: 50%;
            width: 18px;
            height: 18px;
            font-size: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
        }
        
        .fade-in {
            animation: fadeIn 0.6s ease-in;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .slide-in {
            animation: slideIn 0.5s ease-out;
        }
        
        @keyframes slideIn {
            from { transform: translateX(-100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
        
        .gradient-bg {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        }
        
        .floating-card {
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.1), 0 8px 16px rgba(0, 0, 0, 0.08);
        }
        
        .info-bubble {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 12px;
            padding: 12px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
    </style>
</head>
<body class="bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 min-h-screen">
    <!-- Loading Overlay -->
    <div id="loadingOverlay" class="fixed inset-0 bg-white flex items-center justify-center z-50 transition-opacity duration-500">
        <div class="text-center">
            <div class="w-16 h-16 border-4 border-blue-200 border-t-blue-600 rounded-full animate-spin mx-auto mb-4"></div>
            <h3 class="text-xl font-bold text-gray-800 mb-2">BusLK Passenger</h3>
            <p class="text-gray-600">Loading real-time bus tracking...</p>
        </div>
    </div>

    <div class="container mx-auto px-4 py-6 max-w-7xl">
        <!-- Header -->
        <header class="bg-gradient-to-r from-blue-600 to-purple-600 text-white p-6 rounded-2xl shadow-2xl mb-8 relative overflow-hidden floating-card fade-in">
            <div class="absolute inset-0 bg-black opacity-10"></div>
            <div class="absolute top-0 right-0 w-32 h-32 bg-white opacity-10 rounded-full -translate-y-16 translate-x-16"></div>
            <div class="absolute bottom-0 left-0 w-24 h-24 bg-white opacity-10 rounded-full translate-y-12 -translate-x-12"></div>
            
            <div class="relative z-10">
                <div class="flex flex-col md:flex-row md:items-center md:justify-between">
                    <div class="text-center md:text-left mb-4 md:mb-0">
                        <h1 class="text-3xl font-bold flex items-center justify-center md:justify-start">
                            <i class="fas fa-bus mr-3"></i> BusLK Passenger
                        </h1>
                        <p class="mt-2 text-blue-100 font-medium">Real-time bus tracking for Kurunagala to Alakoladeniya</p>
                    </div>
                    <div class="flex flex-col items-center md:items-end space-y-3">
                        <div class="driver-status flex items-center glass-effect px-4 py-2 rounded-full">
                            <span class="status-indicator offline" id="driverOnlineStatus"></span>
                            <span id="driverStatusText" class="font-medium">Driver: Offline</span>
                            <span class="trip-status trip-not-started" id="tripStatusText">Trip: Not Started</span>
                        </div>
                        <div class="flex items-center space-x-3">
                            <button id="refreshBtn" class="glass-effect hover:bg-white hover:bg-opacity-30 text-white p-3 rounded-full transition-all duration-300 transform hover:rotate-180">
                                <i class="fas fa-sync-alt"></i>
                            </button>
                            <div class="relative">
                                <button id="notificationBtn" class="glass-effect hover:bg-white hover:bg-opacity-30 text-white p-3 rounded-full transition-all duration-300">
                                    <i class="fas fa-bell"></i>
                                </button>
                                <span class="notification-badge hidden" id="notificationBadge">3</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <!-- Route Progress with Stop Markers -->
        <div class="bg-white p-6 rounded-2xl shadow-xl mb-8 card fade-in floating-card">
            <div class="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
                <div>
                    <h2 class="text-xl font-bold text-gray-800">Route: Kurunagala to Alakoladeniya</h2>
                    <p class="text-gray-600 mt-1"><span id="totalStops">28</span> stops • Approximately 30 minutes</p>
                </div>
                <div class="mt-4 md:mt-0">
                    <div class="flex items-center bg-blue-50 px-4 py-2 rounded-full">
                        <span class="text-sm text-blue-700 font-medium mr-2">Next bus in:</span>
                        <span class="bg-blue-100 text-blue-800 text-sm font-bold px-3 py-1 rounded-full" id="nextBusIn">
                            <span class="loading-spinner mr-1"></span> Updating...
                        </span>
                    </div>
                </div>
            </div>

            <!-- Enhanced Progress Bar with Stop Markers -->
            <div class="mb-4">
                <div class="flex justify-between text-sm text-gray-600 mb-3 font-medium">
                    <span class="flex items-center">
                        <i class="fas fa-map-marker-alt text-green-500 mr-1"></i> Main Stand
                    </span>
                    <span class="flex items-center">
                        <i class="fas fa-flag-checkered text-purple-500 mr-1"></i> Alakoladeniya
                    </span>
                </div>
                
                <div class="progress-container mb-2" id="progressContainer">
                    <div class="progress-fill" id="progressFill" style="width: 0%"></div>
                    <!-- Stop markers will be dynamically added here -->
                </div>
                
                <div class="flex justify-between text-xs text-gray-500 mt-2">
                    <span>Started: <span id="startTime">-</span></span>
                    <span>ETA: <span id="routeETA">-</span></span>
                </div>
            </div>

            <!-- Current Progress Info -->
            <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
                <div class="bg-gradient-to-r from-blue-50 to-blue-100 p-4 rounded-xl border-l-4 border-blue-500">
                    <p class="text-sm text-blue-600 font-medium mb-1">Current Stop</p>
                    <p class="font-bold text-gray-800 text-lg" id="currentStop">Updating...</p>
                </div>
                <div class="bg-gradient-to-r from-green-50 to-green-100 p-4 rounded-xl border-l-4 border-green-500">
                    <p class="text-sm text-green-600 font-medium mb-1">Next Stop</p>
                    <p class="font-bold text-gray-800 text-lg" id="nextStop">Updating...</p>
                </div>
                <div class="bg-gradient-to-r from-purple-50 to-purple-100 p-4 rounded-xl border-l-4 border-purple-500">
                    <p class="text-sm text-purple-600 font-medium mb-1">Route Progress</p>
                    <p class="font-bold text-gray-800 text-lg" id="routeProgress">0%</p>
                </div>
            </div>
        </div>

        <!-- Main Content Grid -->
        <div class="grid grid-cols-1 xl:grid-cols-4 gap-8 mb-8">
            <!-- Map Section -->
            <div class="xl:col-span-3 bg-white p-6 rounded-2xl shadow-xl card fade-in floating-card">
                <div class="flex justify-between items-center mb-6">
                    <h3 class="text-xl font-bold text-gray-800 flex items-center">
                        <i class="fas fa-map-marked-alt text-blue-500 mr-2"></i> Live Bus Location
                    </h3>
                    <div class="flex items-center text-sm text-gray-600 bg-green-50 px-3 py-1 rounded-full">
                        <span class="flex h-3 w-3 relative mr-2">
                            <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                            <span class="relative inline-flex rounded-full h-3 w-3 bg-green-500"></span>
                        </span>
                        <span class="font-medium">Live Tracking Active</span>
                    </div>
                </div>
                <div id="map" class="mb-6"></div>

                <!-- Bus Information Cards -->
                <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div class="bg-gradient-to-r from-blue-50 to-blue-100 p-3 rounded-xl">
                        <p class="text-xs text-blue-600 font-medium mb-1">Bus Number</p>
                        <p class="font-bold text-gray-800" id="busNumber">-</p>
                    </div>
                    <div class="bg-gradient-to-r from-green-50 to-green-100 p-3 rounded-xl">
                        <p class="text-xs text-green-600 font-medium mb-1">Driver</p>
                        <p class="font-bold text-gray-800" id="driverName">-</p>
                    </div>
                    <div class="bg-gradient-to-r from-purple-50 to-purple-100 p-3 rounded-xl">
                        <p class="text-xs text-purple-600 font-medium mb-1">Passengers</p>
                        <p class="font-bold text-gray-800" id="passengerCount">-</p>
                    </div>
                    <div class="bg-gradient-to-r from-orange-50 to-orange-100 p-3 rounded-xl">
                        <p class="text-xs text-orange-600 font-medium mb-1">Speed</p>
                        <p class="font-bold text-gray-800" id="currentSpeed">0 km/h</p>
                    </div>
                </div>
            </div>

            <!-- Bus Stops List & Actions -->
            <div class="bg-white p-6 rounded-2xl shadow-xl card fade-in floating-card">
                <h3 class="text-xl font-bold text-gray-800 mb-4 flex items-center">
                    <i class="fas fa-map-marker-alt text-red-500 mr-2"></i> Bus Stops
                </h3>
                <div class="stop-list mb-6" id="stopsList">
                    <div class="text-center py-8 text-gray-500">
                        <div class="loading-spinner mx-auto mb-3"></div>
                        <p>Loading bus stops...</p>
                    </div>
                </div>

                <!-- Quick Actions -->
                <div class="space-y-4">
                    <button id="notifyBtn" class="w-full bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-white py-3 rounded-xl flex items-center justify-center font-bold transition-all duration-300 transform hover:scale-105 shadow-lg">
                        <i class="fas fa-bell mr-3"></i> Notify Me at Next Stop
                    </button>
                    
                    <div class="grid grid-cols-2 gap-3">
                        <button class="bg-blue-500 hover:bg-blue-600 text-white py-2 rounded-lg flex items-center justify-center transition-all duration-300">
                            <i class="fas fa-share-alt mr-2"></i> Share
                        </button>
                        <button class="bg-gray-500 hover:bg-gray-600 text-white py-2 rounded-lg flex items-center justify-center transition-all duration-300">
                            <i class="fas fa-info-circle mr-2"></i> Info
                        </button>
                    </div>
                </div>

                <!-- Last Update -->
                <div class="mt-6 pt-4 border-t border-gray-200">
                    <p class="text-sm text-gray-600">
                        <i class="fas fa-clock mr-2"></i>Last updated: <span id="lastUpdate">-</span>
                    </p>
                </div>
            </div>
        </div>

        <!-- Additional Information Cards -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <!-- Bus Status Card -->
            <div class="bg-white p-6 rounded-2xl shadow-xl card fade-in floating-card">
                <h3 class="text-lg font-bold text-gray-800 mb-4 flex items-center">
                    <i class="fas fa-chart-line text-green-500 mr-2"></i> Bus Status
                </h3>
                <div class="space-y-4">
                    <div class="flex justify-between items-center p-3 bg-gray-50 rounded-xl">
                        <span class="text-gray-600 font-medium">Estimated Arrival</span>
                        <span class="font-bold text-gray-800" id="eta">-</span>
                    </div>
                    <div class="flex justify-between items-center p-3 bg-gray-50 rounded-xl">
                        <span class="text-gray-600 font-medium">Distance Covered</span>
                        <span class="font-bold text-gray-800" id="distanceCovered">-</span>
                    </div>
                    <div class="flex justify-between items-center p-3 bg-gray-50 rounded-xl">
                        <span class="text-gray-600 font-medium">Stops Passed</span>
                        <span class="font-bold text-gray-800" id="stopsPassed">0/28</span>
                    </div>
                </div>
            </div>

            <!-- Service Information -->
            <div class="bg-white p-6 rounded-2xl shadow-xl card fade-in floating-card">
                <h3 class="text-lg font-bold text-gray-800 mb-4 flex items-center">
                    <i class="fas fa-info-circle text-blue-500 mr-2"></i> Service Info
                </h3>
                <div class="space-y-3">
                    <div class="flex items-center p-2">
                        <i class="fas fa-clock text-blue-500 w-6"></i>
                        <span class="ml-3 text-gray-700">Service Hours: 5:00 AM - 10:00 PM</span>
                    </div>
                    <div class="flex items-center p-2">
                        <i class="fas fa-tachometer-alt text-green-500 w-6"></i>
                        <span class="ml-3 text-gray-700">Frequency: Every 15-20 minutes</span>
                    </div>
                    <div class="flex items-center p-2">
                        <i class="fas fa-phone-alt text-purple-500 w-6"></i>
                        <span class="ml-3 text-gray-700">Contact: +94 77 123 4567</span>
                    </div>
                </div>
            </div>

            <!-- Quick Actions -->
            <div class="bg-white p-6 rounded-2xl shadow-xl card fade-in floating-card">
                <h3 class="text-lg font-bold text-gray-800 mb-4 flex items-center">
                    <i class="fas fa-bolt text-yellow-500 mr-2"></i> Quick Actions
                </h3>
                <div class="grid grid-cols-2 gap-3">
                    <button class="bg-blue-500 hover:bg-blue-600 text-white p-4 rounded-xl flex flex-col items-center justify-center transition-all duration-300 transform hover:scale-105">
                        <i class="fas fa-map-marker-alt text-xl mb-2"></i>
                        <span class="text-sm">Save Stop</span>
                    </button>
                    <button class="bg-green-500 hover:bg-green-600 text-white p-4 rounded-xl flex flex-col items-center justify-center transition-all duration-300 transform hover:scale-105">
                        <i class="fas fa-route text-xl mb-2"></i>
                        <span class="text-sm">View Route</span>
                    </button>
                    <button class="bg-purple-500 hover:bg-purple-600 text-white p-4 rounded-xl flex flex-col items-center justify-center transition-all duration-300 transform hover:scale-105">
                        <i class="fas fa-bell text-xl mb-2"></i>
                        <span class="text-sm">Alerts</span>
                    </button>
                    <button class="bg-orange-500 hover:bg-orange-600 text-white p-4 rounded-xl flex flex-col items-center justify-center transition-all duration-300 transform hover:scale-105">
                        <i class="fas fa-question text-xl mb-2"></i>
                        <span class="text-sm">Help</span>
                    </button>
                </div>
            </div>
        </div>

        <!-- Footer -->
        <footer class="text-center text-gray-600 text-sm p-6 mt-8">
            <div class="flex flex-col md:flex-row justify-between items-center">
                <p>BusLK Village Passenger App &copy; 2025 - Real-time bus tracking system</p>
                <div class="flex space-x-4 mt-2 md:mt-0">
                    <span class="flex items-center">
                        <span class="status-indicator online mr-1"></span> System Online
                    </span>
                    <span id="connectionStatus" class="flex items-center text-green-600">
                        <i class="fas fa-wifi mr-1"></i> Connected
                    </span>
                </div>
            </div>
        </footer>
    </div>

    <script>
        // Global variables
        let map, busMarker, routePolyline, busStopsLayer;
        let busStops = [];
        let currentStopIndex = 0;
        let lastUpdateTime = new Date();
        let updateInterval;
        let connectionRetries = 0;
        const MAX_RETRIES = 5;

        // Initialize the map
        function initMap(lat = 7.48813300, lng = 80.36424000) {
            // Create a map centered on the route
            map = L.map('map', {
                zoomControl: true,
                scrollWheelZoom: true
            }).setView([lat, lng], 14);

            // Add OpenStreetMap tiles
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
                maxZoom: 18
            }).addTo(map);

            // Create bus marker with custom icon
            const busIcon = L.divIcon({
                className: 'bus-marker',
                html: `
                    <div class="relative">
                        <div class="pulse-dot w-4 h-4 bg-red-500 rounded-full absolute -top-1 -right-1"></div>
                        <div class="w-12 h-12 bg-red-600 rounded-full flex items-center justify-center shadow-lg border-4 border-white">
                            <i class="fas fa-bus text-white text-lg"></i>
                        </div>
                    </div>
                `,
                iconSize: [48, 48],
                iconAnchor: [24, 48]
            });

            busMarker = L.marker([lat, lng], { 
                icon: busIcon,
                zIndexOffset: 1000
            }).addTo(map).bindPopup(`
                <div class="text-center p-2 min-w-48">
                    <h4 class="font-bold text-gray-800 mb-2">Bus Location</h4>
                    <div class="space-y-1 text-sm">
                        <div class="flex justify-between">
                            <span class="text-gray-600">Latitude:</span>
                            <span class="font-mono">${lat.toFixed(6)}</span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-gray-600">Longitude:</span>
                            <span class="font-mono">${lng.toFixed(6)}</span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-gray-600">Last Update:</span>
                            <span class="text-green-600">Just now</span>
                        </div>
                    </div>
                </div>
            `).openPopup();
        }

        // Update map with bus stops and route
        function updateMapWithStops(stops) {
            busStops = stops;
            
            // Clear existing stops and route if they exist
            if (busStopsLayer) {
                map.removeLayer(busStopsLayer);
            }
            if (routePolyline) {
                map.removeLayer(routePolyline);
            }

            // Create a layer group for bus stops
            busStopsLayer = L.layerGroup().addTo(map);

            // Add markers for bus stops
            stops.forEach((stop, index) => {
                const isCurrent = stop.stop_id === currentStopId;
                const isNext = stop.stop_id === nextStopId;
                const isPassed = currentStopId && 
                    busStops.findIndex(s => s.stop_id === currentStopId) > index;
                
                const stopIcon = L.divIcon({
                    className: 'custom-stop-marker',
                    html: `
                        <div class="w-10 h-10 rounded-full flex items-center justify-center text-white font-bold text-xs shadow-lg border-3 border-white
                            ${isCurrent ? 'bg-green-500' : isNext ? 'bg-yellow-500' : isPassed ? 'bg-gray-400' : 'bg-blue-500'}">
                            ${stop.stop_order}
                        </div>
                    `,
                    iconSize: [40, 40],
                    iconAnchor: [20, 20]
                });

                const marker = L.marker([stop.latitude, stop.longitude], {icon: stopIcon})
                    .addTo(busStopsLayer)
                    .bindPopup(`
                        <div class="p-3 min-w-56">
                            <h4 class="font-bold text-gray-800 mb-2">${stop.stop_name}</h4>
                            <div class="space-y-1 text-sm">
                                ${stop.landmark ? `<p class="text-gray-600"><i class="fas fa-landmark mr-2"></i>${stop.landmark}</p>` : ''}
                                <p class="text-gray-600"><i class="fas fa-sort-numeric-up mr-2"></i>Order: ${stop.stop_order}</p>
                                <p class="text-gray-600"><i class="fas fa-clock mr-2"></i>ETA: ${stop.estimated_time_from_start} min</p>
                                ${isCurrent ? '<p class="text-green-600 font-bold"><i class="fas fa-circle mr-2"></i>Current Stop</p>' : ''}
                                ${isNext ? '<p class="text-yellow-600 font-bold"><i class="fas fa-arrow-right mr-2"></i>Next Stop</p>' : ''}
                            </div>
                        </div>
                    `);

                // Add different color for current and next stops
                if (isCurrent) {
                    marker.openPopup();
                }
            });

            // Draw the route
            const routePoints = stops.map(stop => [stop.latitude, stop.longitude]);
            routePolyline = L.polyline(routePoints, {
                color: '#3b82f6',
                weight: 6,
                opacity: 0.8,
                dashArray: '8, 12',
                lineJoin: 'round'
            }).addTo(map);

            // Update progress bar with stop markers
            updateProgressBarWithMarkers();

            // Update total stops count
            document.getElementById('totalStops').textContent = stops.length;
        }

        // Update progress bar with stop markers
        function updateProgressBarWithMarkers() {
            const progressContainer = document.getElementById('progressContainer');
            const progressFill = document.getElementById('progressFill');
            
            // Clear existing markers
            const existingMarkers = progressContainer.querySelectorAll('.stop-marker');
            existingMarkers.forEach(marker => marker.remove());
            
            // Add markers for each stop
            busStops.forEach((stop, index) => {
                const percentage = (index / (busStops.length - 1)) * 100;
                const marker = document.createElement('div');
                marker.className = 'stop-marker';
                
                // Determine marker status
                if (stop.stop_id === currentStopId) {
                    marker.classList.add('current');
                } else if (currentStopId && busStops.findIndex(s => s.stop_id === currentStopId) > index) {
                    marker.classList.add('passed');
                } else if (stop.stop_id === nextStopId) {
                    marker.classList.add('next');
                }
                
                marker.style.left = `${percentage}%`;
                marker.title = `${stop.stop_name} (Order: ${stop.stop_order})`;
                
                // Add click event to show stop info
                marker.addEventListener('click', () => {
                    showStopInfo(stop);
                });
                
                progressContainer.appendChild(marker);
            });
        }

        // Show stop information in a tooltip
        function showStopInfo(stop) {
            // Create and show a custom tooltip
            const tooltip = document.createElement('div');
            tooltip.className = 'info-bubble fixed z-50';
            tooltip.innerHTML = `
                <h4 class="font-bold text-gray-800 mb-1">${stop.stop_name}</h4>
                <p class="text-sm text-gray-600">Order: ${stop.stop_order}</p>
                <p class="text-sm text-gray-600">ETA: ${stop.estimated_time_from_start} min</p>
                ${stop.landmark ? `<p class="text-sm text-gray-600">${stop.landmark}</p>` : ''}
            `;
            
            document.body.appendChild(tooltip);
            
            // Position near the progress bar
            const progressContainer = document.getElementById('progressContainer');
            const rect = progressContainer.getBoundingClientRect();
            tooltip.style.top = `${rect.top - tooltip.offsetHeight - 10}px`;
            tooltip.style.left = `${rect.left + (rect.width * (stop.stop_order - 1) / (busStops.length - 1))}px`;
            
            // Remove after 3 seconds
            setTimeout(() => {
                tooltip.remove();
            }, 3000);
        }

        // Update bus position on map
        function updateBusPosition(lat, lng) {
            if (busMarker) {
                const oldLatLng = busMarker.getLatLng();
                busMarker.setLatLng([lat, lng]);
                
                // Smooth pan to new position
                map.panTo([lat, lng], {
                    animate: true,
                    duration: 1.5
                });
                
                busMarker.bindPopup(`
                    <div class="text-center p-3 min-w-48">
                        <h4 class="font-bold text-gray-800 mb-2">Bus Location</h4>
                        <div class="space-y-1 text-sm">
                            <div class="flex justify-between">
                                <span class="text-gray-600">Latitude:</span>
                                <span class="font-mono">${lat.toFixed(6)}</span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-gray-600">Longitude:</span>
                                <span class="font-mono">${lng.toFixed(6)}</span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-gray-600">Last Update:</span>
                                <span class="text-green-600">Just now</span>
                            </div>
                        </div>
                    </div>
                `);
            }
        }

        // Render the list of bus stops
        function renderStopsList(currentStopId, nextStopId) {
            const stopsList = document.getElementById('stopsList');
            
            if (busStops.length === 0) {
                stopsList.innerHTML = `
                    <div class="text-center py-8 text-gray-500">
                        <i class="fas fa-map-marker-alt text-3xl mb-3 opacity-50"></i>
                        <p>No bus stops available</p>
                    </div>
                `;
                return;
            }

            let stopsHTML = '';
            
            busStops.forEach((stop, index) => {
                const isCurrent = stop.stop_id === currentStopId;
                const isNext = stop.stop_id === nextStopId;
                const isPassed = currentStopId && 
                    busStops.findIndex(s => s.stop_id === currentStopId) > index;

                let stopClass = 'p-4 border-b border-gray-100 transition-all duration-300 cursor-pointer';
                if (isPassed) stopClass += ' passed-stop';
                if (isCurrent) stopClass += ' current-stop';
                if (isNext) stopClass += ' next-stop';

                stopsHTML += `
                    <div class="${stopClass}" onclick="focusOnStop(${stop.stop_id})">
                        <div class="flex justify-between items-start">
                            <div class="flex items-center">
                                <div class="w-12 h-12 rounded-full flex items-center justify-center mr-3 text-white font-bold
                                    ${isCurrent ? 'bg-green-500' : 
                                      isNext ? 'bg-yellow-500' : 
                                      isPassed ? 'bg-gray-400' : 'bg-blue-500'}">
                                    ${stop.stop_order}
                                </div>
                                <div>
                                    <p class="font-semibold ${isPassed ? 'text-gray-400' : 'text-gray-800'}">${stop.stop_name}</p>
                                    <p class="text-sm ${isPassed ? 'text-gray-400' : 'text-gray-600'}">
                                        ${stop.landmark || 'No landmark'}
                                    </p>
                                    <p class="text-xs ${isPassed ? 'text-gray-400' : 'text-gray-500'}">
                                        ETA: ${stop.estimated_time_from_start} min
                                    </p>
                                </div>
                            </div>
                            <div class="text-right">
                                ${isCurrent ?
                                    '<span class="text-xs bg-green-100 text-green-800 px-2 py-1 rounded-full font-medium">Current</span>' : ''}
                                ${isNext ?
                                    '<span class="text-xs bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full font-medium">Next</span>' : ''}
                                ${isPassed ?
                                    '<span class="text-xs bg-gray-100 text-gray-800 px-2 py-1 rounded-full font-medium">Passed</span>' : ''}
                            </div>
                        </div>
                    </div>
                `;
            });

            stopsList.innerHTML = stopsHTML;
        }

        // Focus on a specific stop on the map
        function focusOnStop(stopId) {
            const stop = busStops.find(s => s.stop_id === stopId);
            if (stop) {
                map.setView([stop.latitude, stop.longitude], 16);
                // Find and open the marker popup
                busStopsLayer.eachLayer(layer => {
                    if (layer.stopData && layer.stopData.stop_id === stopId) {
                        layer.openPopup();
                    }
                });
            }
        }

        // Update bus information display
        function updateBusInfo(busData) {
            // Update basic info with animations
            fadeUpdate('currentStop', busData.current_stop_name || 'Not available');
            fadeUpdate('nextStop', busData.next_stop_name || 'Not available');
            fadeUpdate('busNumber', busData.bus_number);
            fadeUpdate('driverName', busData.driver_name);
            fadeUpdate('passengerCount', `${busData.passenger_count}/${busData.capacity}`);
            fadeUpdate('currentSpeed', busData.speed_kmh ? `${busData.speed_kmh.toFixed(1)} km/h` : '0 km/h');
            fadeUpdate('eta', `${busData.eta_minutes} minutes`);
            fadeUpdate('routeProgress', `${Math.round(busData.progress_percentage)}%`);
            
            // Calculate stops passed
            const stopsPassed = busData.current_stop_order ? busData.current_stop_order - 1 : 0;
            const totalStops = busData.total_stops || busStops.length;
            document.getElementById('stopsPassed').textContent = `${stopsPassed}/${totalStops}`;
            
            // Calculate distance covered (approximate)
            const distanceCovered = ((busData.progress_percentage / 100) * 85.5).toFixed(1);
            document.getElementById('distanceCovered').textContent = `${distanceCovered} km`;

            // Update progress bar with animation
            const progressFill = document.getElementById('progressFill');
            progressFill.style.width = `${busData.progress_percentage}%`;

            // Update driver status
            const driverStatusIndicator = document.getElementById('driverOnlineStatus');
            const driverStatusText = document.getElementById('driverStatusText');
            const tripStatusText = document.getElementById('tripStatusText');

            if (busData.driver_online) {
                driverStatusIndicator.className = 'status-indicator online';
                driverStatusText.textContent = 'Driver: Online';
            } else {
                driverStatusIndicator.className = 'status-indicator offline';
                driverStatusText.textContent = 'Driver: Offline';
            }

            // Update trip status
            if (busData.trip_status === 'in_progress') {
                tripStatusText.className = 'trip-status trip-active';
                tripStatusText.textContent = 'Trip: Active';
                document.getElementById('nextBusIn').innerHTML = '<span class="text-green-600">Now</span>';
            } else if (busData.trip_status === 'scheduled') {
                tripStatusText.className = 'trip-status trip-inactive';
                tripStatusText.textContent = 'Trip: Scheduled';
                document.getElementById('nextBusIn').textContent = '15 minutes';
            } else {
                tripStatusText.className = 'trip-status trip-not-started';
                tripStatusText.textContent = 'Trip: Not Started';
                document.getElementById('nextBusIn').textContent = 'No active trip';
            }

            // Update last update time
            updateLastUpdateTime();
            
            // Update ETA and start time
            const now = new Date();
            const etaTime = new Date(now.getTime() + busData.eta_minutes * 60000);
            document.getElementById('routeETA').textContent = `${etaTime.getHours()}:${etaTime.getMinutes().toString().padStart(2, '0')}`;
            
            if (busData.trip_status === 'in_progress') {
                document.getElementById('startTime').textContent = '7:00 AM';
            } else {
                document.getElementById('startTime').textContent = '-';
            }
        }

        // Helper function for fade-in updates
        function fadeUpdate(elementId, newText) {
            const element = document.getElementById(elementId);
            if (element.textContent !== newText) {
                element.style.opacity = '0.5';
                setTimeout(() => {
                    element.textContent = newText;
                    element.style.opacity = '1';
                }, 150);
            }
        }

        // Update last update time display
        function updateLastUpdateTime() {
            const timeDiff = Math.floor((new Date() - lastUpdateTime) / 1000);
            let timeText = '';
            
            if (timeDiff < 10) {
                timeText = 'Just now';
            } else if (timeDiff < 60) {
                timeText = `${timeDiff} seconds ago`;
            } else if (timeDiff < 3600) {
                timeText = `${Math.floor(timeDiff / 60)} minutes ago`;
            } else {
                timeText = `${Math.floor(timeDiff / 3600)} hours ago`;
            }
            
            document.getElementById('lastUpdate').textContent = timeText;
        }

        // Show connection status
        function updateConnectionStatus(connected, message = '') {
            const statusElement = document.getElementById('connectionStatus');
            
            if (connected) {
                statusElement.className = 'flex items-center text-green-600';
                statusElement.innerHTML = '<i class="fas fa-wifi mr-1"></i> Connected';
                connectionRetries = 0;
            } else {
                statusElement.className = 'flex items-center text-red-600';
                statusElement.innerHTML = `<i class="fas fa-exclamation-triangle mr-1"></i> ${message}`;
            }
        }

        // Show notification
        function showNotification(message, type = 'info') {
            // Create notification element
            const notification = document.createElement('div');
            notification.className = `fixed top-4 right-4 p-4 rounded-xl shadow-lg z-50 transform transition-all duration-300 translate-x-full ${
                type === 'error' ? 'bg-red-500 text-white' : 
                type === 'success' ? 'bg-green-500 text-white' : 'bg-blue-500 text-white'
            }`;
            notification.innerHTML = `
                <div class="flex items-center">
                    <i class="fas ${
                        type === 'error' ? 'fa-exclamation-triangle' : 
                        type === 'success' ? 'fa-check-circle' : 'fa-info-circle'
                    } mr-2"></i>
                    <span>${message}</span>
                </div>
            `;
            
            document.body.appendChild(notification);
            
            // Animate in
            setTimeout(() => {
                notification.style.transform = 'translateX(0)';
            }, 10);
            
            // Remove after 5 seconds
            setTimeout(() => {
                notification.style.transform = 'translateX(100%)';
                setTimeout(() => {
                    if (notification.parentNode) {
                        notification.parentNode.removeChild(notification);
                    }
                }, 300);
            }, 5000);
        }

        // Fetch the latest bus data from the server
        function fetchBusData() {
            fetch('../api/get_passenger_bus_data.php')
                .then(response => {
                    if (!response.ok) {
                        throw new Error(`HTTP error! status: ${response.status}`);
                    }
                    return response.json();
                })
                .then(data => {
                    if (data.success) {
                        lastUpdateTime = new Date();
                        
                        const busData = data.bus_data;
                        const stops = data.bus_stops;

                        // Update map with stops if we have them
                        if (stops && stops.length > 0) {
                            updateMapWithStops(stops);
                        }

                        // Update bus position
                        updateBusPosition(busData.latitude, busData.longitude);

                        // Update stops list
                        renderStopsList(busData.current_stop_id, busData.next_stop_id);

                        // Update bus information
                        updateBusInfo(busData);

                        // Update connection status
                        updateConnectionStatus(true);
                        
                        // Hide loading overlay after first successful load
                        const loadingOverlay = document.getElementById('loadingOverlay');
                        if (loadingOverlay) {
                            setTimeout(() => {
                                loadingOverlay.style.opacity = '0';
                                setTimeout(() => {
                                    loadingOverlay.style.display = 'none';
                                }, 500);
                            }, 1000);
                        }

                    } else {
                        throw new Error(data.message || 'Unknown error occurred');
                    }
                })
                .catch(error => {
                    console.error('Error fetching bus data:', error);
                    
                    connectionRetries++;
                    if (connectionRetries <= MAX_RETRIES) {
                        updateConnectionStatus(false, `Retrying... (${connectionRetries}/${MAX_RETRIES})`);
                        showNotification('Connection issue. Retrying...', 'error');
                    } else {
                        updateConnectionStatus(false, 'Connection failed');
                        showNotification('Unable to connect to bus tracking service', 'error');
                    }
                });
        }

        // Initialize the app
        document.addEventListener('DOMContentLoaded', function() {
            // Initialize map with default location
            initMap();

            // Fetch bus data immediately
            fetchBusData();

            // Set up periodic updates every 5 seconds for real-time feel
            updateInterval = setInterval(fetchBusData, 5000);

            // Refresh button
            document.getElementById('refreshBtn').addEventListener('click', function() {
                const icon = this.querySelector('i');
                icon.classList.add('fa-spin');
                fetchBusData();
                setTimeout(() => {
                    icon.classList.remove('fa-spin');
                    showNotification('Data refreshed successfully', 'success');
                }, 1000);
            });

            // Notify button
            document.getElementById('notifyBtn').addEventListener('click', function() {
                const currentStop = document.getElementById('currentStop').textContent;
                const nextStop = document.getElementById('nextStop').textContent;
                
                // Add loading state to button
                const originalText = this.innerHTML;
                this.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Setting notification...';
                this.disabled = true;
                
                setTimeout(() => {
                    this.innerHTML = originalText;
                    this.disabled = false;
                    showNotification(`You will be notified when the bus approaches ${nextStop}!`, 'success');
                    
                    // Update notification badge
                    const badge = document.getElementById('notificationBadge');
                    badge.classList.remove('hidden');
                }, 1500);
            });

            // Notification button
            document.getElementById('notificationBtn').addEventListener('click', function() {
                showNotification('Notification settings would open here', 'info');
                const badge = document.getElementById('notificationBadge');
                badge.classList.add('hidden');
            });

            // Handle page visibility changes
            document.addEventListener('visibilitychange', function() {
                if (document.hidden) {
                    // Page is hidden, reduce update frequency to save resources
                    clearInterval(updateInterval);
                    updateInterval = setInterval(fetchBusData, 30000); // Every 30 seconds
                } else {
                    // Page is visible, use real-time updates
                    clearInterval(updateInterval);
                    updateInterval = setInterval(fetchBusData, 5000); // Every 5 seconds
                    fetchBusData(); // Immediate update
                }
            });

            // Handle online/offline events
            window.addEventListener('online', function() {
                showNotification('Connection restored', 'success');
                fetchBusData();
            });

            window.addEventListener('offline', function() {
                showNotification('You are currently offline', 'error');
            });
        });

        // Clean up on page unload
        window.addEventListener('beforeunload', function() {
            if (updateInterval) {
                clearInterval(updateInterval);
            }
        });

        // Global variables for current and next stop IDs
        let currentStopId = null;
        let nextStopId = null;
    </script>
</body>
</html>
bus_tracking_system/
├── passenger/
│   ├── index.php (main passenger app)
│   ├── style.css
│   └── script.js
├── api/
│   ├── get_passenger_bus_data.php
│   └── get_bus_locations_history.php
└── includes/
    ├── config.php
    └── functions.php
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BusLK - Village Passenger App</title>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" />
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"></script>
    <style>
        #map {
            height: 400px;
            width: 100%;
            border-radius: 8px;
            z-index: 1;
        }
        .card {
            transition: all 0.3s ease;
        }
        .card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .stop-list {
            max-height: 400px;
            overflow-y: auto;
        }
        .current-stop {
            background-color: #E1F5FE;
            border-left: 4px solid #0288D1;
        }
        .passed-stop {
            color: #9E9E9E;
        }
        .next-stop {
            font-weight: bold;
        }
        .bus-marker {
            filter: drop-shadow(0 0 5px rgba(0,0,0,0.3));
        }
        .loading {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 3px solid rgba(255,255,255,.3);
            border-radius: 50%;
            border-top-color: #fff;
            animation: spin 1s ease-in-out infinite;
        }
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
        .progress-bar {
            height: 6px;
            background-color: #E0E0E0;
            border-radius: 3px;
            overflow: hidden;
        }
        .progress-fill {
            height: 100%;
            background-color: #4CAF50;
            border-radius: 3px;
            transition: width 0.5s ease;
        }
        .driver-status {
            display: flex;
            align-items: center;
            margin-bottom: 1rem;
        }
        .status-indicator {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            margin-right: 0.5rem;
        }
        .online {
            background-color: #4CAF50;
        }
        .offline {
            background-color: #F44336;
        }
        .trip-status {
            font-size: 0.875rem;
            padding: 0.25rem 0.5rem;
            border-radius: 0.25rem;
            margin-left: 0.5rem;
        }
        .trip-active {
            background-color: #4CAF50;
            color: white;
        }
        .trip-inactive {
            background-color: #FF9800;
            color: white;
        }
        .trip-not-started {
            background-color: #9E9E9E;
            color: white;
        }
        .trip-completed {
            background-color: #2196F3;
            color: white;
        }
    </style>
</head>
<body class="bg-gray-100 min-h-screen">
    <div class="container mx-auto px-4 py-6">
        <!-- Header -->
        <header class="bg-blue-600 text-white p-4 rounded-lg shadow mb-6">
            <div class="flex flex-col md:flex-row md:items-center md:justify-between">
                <div>
                    <h1 class="text-2xl font-bold flex items-center">
                        <i class="fas fa-bus mr-2"></i> BusLK - Village Passenger
                    </h1>
                    <p class="mt-1">Kurunagala to Alakoladeniya Bus Service</p>
                </div>
                <div class="mt-4 md:mt-0 flex items-center">
                    <div class="driver-status">
                        <span class="status-indicator" id="driverOnlineStatus"></span>
                        <span id="driverStatusText">Driver: Offline</span>
                        <span class="trip-status" id="tripStatusText">Trip: Not Started</span>
                    </div>
                    <button id="refreshBtn" class="ml-4 bg-blue-700 hover:bg-blue-800 text-white p-2 rounded-full">
                        <i class="fas fa-sync-alt"></i>
                    </button>
                </div>
            </div>
        </header>

        <!-- Route Information -->
        <div class="bg-white p-4 rounded-lg shadow mb-6">
            <div class="flex flex-col md:flex-row md:items-center md:justify-between">
                <div>
                    <h2 class="text-lg font-semibold">Route: Kurunagala to Alakoladeniya</h2>
                    <p class="text-gray-600"><span id="totalStops">28</span> stops • Approximately 30 minutes</p>
                </div>
                <div class="mt-2 md:mt-0">
                    <div class="flex items-center">
                        <span class="text-sm text-gray-600 mr-2">Next bus in:</span>
                        <span class="bg-blue-100 text-blue-800 text-sm font-medium px-2 py-1 rounded" id="nextBusIn">Updating...</span>
                    </div>
                </div>
            </div>

            <div class="mt-4">
                <div class="flex justify-between text-sm text-gray-600 mb-1">
                    <span>Main Stand</span>
                    <span>Alakoladeniya End Terminal</span>
                </div>
                <div class="progress-bar">
                    <div class="progress-fill" id="progressFill" style="width: 0%;"></div>
                </div>
                <div class="flex justify-between text-xs text-gray-500 mt-1">
                    <span>Started: <span id="startTime">-</span></span>
                    <span>ETA: <span id="routeETA">-</span></span>
                </div>
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
            <!-- Map Section -->
            <div class="lg:col-span-2 bg-white p-4 rounded-lg shadow">
                <h3 class="text-lg font-semibold mb-4">Live Bus Location</h3>
                <div id="map" class="mb-4"></div>

                <div class="grid grid-cols-2 gap-4">
                    <div class="bg-blue-50 p-3 rounded-lg">
                        <p class="text-sm text-blue-600">Current Stop</p>
                        <p class="font-semibold" id="currentStop">Updating...</p>
                    </div>
                    <div class="bg-green-50 p-3 rounded-lg">
                        <p class="text-sm text-green-600">Next Stop</p>
                        <p class="font-semibold" id="nextStop">Updating...</p>
                    </div>
                </div>
            </div>

            <!-- Bus Stops List -->
            <div class="bg-white p-4 rounded-lg shadow">
                <h3 class="text-lg font-semibold mb-4">Bus Stops</h3>
                <div class="stop-list" id="stopsList">
                    <div class="text-center py-4 text-gray-500">
                        <i class="fas fa-spinner fa-spin mr-2"></i>Loading stops...
                    </div>
                </div>
            </div>
        </div>

        <!-- Bus Information -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div class="bg-white p-4 rounded-lg shadow">
                <h3 class="text-lg font-semibold mb-4">Bus Information</h3>
                <div class="space-y-3">
                    <div class="flex items-center">
                        <div class="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center mr-3">
                            <i class="fas fa-bus text-blue-600"></i>
                        </div>
                        <div>
                            <p class="text-sm text-gray-600">Bus Number</p>
                            <p class="font-semibold" id="busNumber">-</p>
                        </div>
                    </div>
                    <div class="flex items-center">
                        <div class="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center mr-3">
                            <i class="fas fa-user text-green-600"></i>
                        </div>
                        <div>
                            <p class="text-sm text-gray-600">Driver</p>
                            <p class="font-semibold" id="driverName">-</p>
                        </div>
                    </div>
                    <div class="flex items-center">
                        <div class="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center mr-3">
                            <i class="fas fa-users text-purple-600"></i>
                        </div>
                        <div>
                            <p class="text-sm text-gray-600">Passengers</p>
                            <p class="font-semibold" id="passengerCount">-</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="bg-white p-4 rounded-lg shadow">
                <h3 class="text-lg font-semibold mb-4">Bus Status</h3>
                <div class="space-y-3">
                    <div class="flex justify-between">
                        <span class="text-gray-600">Current Speed</span>
                        <span class="font-semibold" id="currentSpeed">-</span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-gray-600">Last Updated</span>
                        <span class="font-semibold" id="lastUpdate">-</span>
                    </div>
                    <div class="flex justify-between">
                        <span class="text-gray-600">Estimated Arrival</span>
                        <span class="font-semibold" id="eta">-</span>
                    </div>
                </div>

                <div class="mt-4 pt-3 border-t border-gray-200">
                    <button id="notifyBtn" class="w-full bg-yellow-500 hover:bg-yellow-600 text-white py-2 rounded-lg flex items-center justify-center">
                        <i class="fas fa-bell mr-2"></i> Notify Me at Next Stop
                    </button>
                </div>
            </div>
        </div>

        <!-- Footer -->
        <footer class="text-center text-gray-600 text-sm p-4">
            <p>BusLK Village Passenger App &copy; 2025 - Real-time bus tracking for Kurunagala to Alakoladeniya route</p>
        </footer>
    </div>

    <script>
        // Global variables
        let map, busMarker, routePolyline;
        let busStops = [];
        let currentStopIndex = 0;
        let lastUpdateTime = new Date();
        let updateInterval;

        // Initialize the map
        function initMap(lat = 7.48813300, lng = 80.36424000) {
            // Create a map centered on the route
            map = L.map('map').setView([lat, lng], 13);

            // Add OpenStreetMap tiles
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            }).addTo(map);

            // Create bus marker with custom icon
            const busIcon = L.divIcon({
                className: 'bus-marker',
                html: `<div style="
                    background-color: #dc2626;
                    width: 30px;
                    height: 30px;
                    border-radius: 50% 50% 50% 0;
                    transform: rotate(-45deg);
                    border: 3px solid white;
                    box-shadow: 0 2px 4px rgba(0,0,0,0.3);
                    display: flex;
                    align-items: center;
                    justify-content: center;
                "><i class="fas fa-bus" style="color: white; transform: rotate(45deg); font-size: 12px;"></i></div>`,
                iconSize: [30, 30],
                iconAnchor: [15, 30]
            });

            busMarker = L.marker([lat, lng], {icon: busIcon})
                .addTo(map)
                .bindPopup('Bus Location')
                .openPopup();
        }

        // Update map with bus stops and route
        function updateMapWithStops(stops) {
            busStops = stops;
            
            // Clear existing stops and route
            map.eachLayer(layer => {
                if (layer instanceof L.Marker && layer !== busMarker) {
                    map.removeLayer(layer);
                }
                if (layer === routePolyline) {
                    map.removeLayer(layer);
                }
            });

            // Add markers for bus stops
            stops.forEach(stop => {
                const stopIcon = L.divIcon({
                    className: 'custom-stop-marker',
                    html: `<div style="
                        background-color: #2563eb;
                        width: 20px;
                        height: 20px;
                        border-radius: 50%;
                        border: 3px solid white;
                        box-shadow: 0 2px 4px rgba(0,0,0,0.3);
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        color: white;
                        font-size: 10px;
                        font-weight: bold;
                    ">${stop.stop_order}</div>`,
                    iconSize: [20, 20],
                    iconAnchor: [10, 10]
                });

                L.marker([stop.latitude, stop.longitude], {icon: stopIcon})
                 .addTo(map)
                 .bindPopup(`
                    <strong>${stop.stop_name}</strong><br>
                    ${stop.landmark ? `Landmark: ${stop.landmark}<br>` : ''}
                    Order: ${stop.stop_order}<br>
                    Est. Time: ${stop.estimated_time_from_start} mins
                 `);
            });

            // Draw the route
            const routePoints = stops.map(stop => [stop.latitude, stop.longitude]);
            routePolyline = L.polyline(routePoints, {
                color: 'blue', 
                weight: 4,
                opacity: 0.7,
                dashArray: '5, 10'
            }).addTo(map);

            // Update total stops count
            document.getElementById('totalStops').textContent = stops.length;
        }

        // Update bus position on map
        function updateBusPosition(lat, lng) {
            if (busMarker) {
                busMarker.setLatLng([lat, lng]);
                busMarker.bindPopup(`Bus Location: ${lat.toFixed(6)}, ${lng.toFixed(6)}`).openPopup();
            }
            map.panTo([lat, lng]);
        }

        // Render the list of bus stops
        function renderStopsList(currentStopId, nextStopId) {
            const stopsList = document.getElementById('stopsList');
            stopsList.innerHTML = '';

            if (busStops.length === 0) {
                stopsList.innerHTML = '<div class="text-center py-4 text-gray-500">No stops available</div>';
                return;
            }

            busStops.forEach((stop, index) => {
                const stopElement = document.createElement('div');
                stopElement.className = 'p-3 border-b border-gray-200';

                const isCurrent = stop.stop_id === currentStopId;
                const isNext = stop.stop_id === nextStopId;
                const isPassed = currentStopId && 
                    busStops.findIndex(s => s.stop_id === currentStopId) > index;

                if (isPassed) {
                    stopElement.classList.add('passed-stop');
                } else if (isCurrent) {
                    stopElement.classList.add('current-stop');
                } else if (isNext) {
                    stopElement.classList.add('next-stop');
                }

                stopElement.innerHTML = `
                    <div class="flex justify-between items-center">
                        <div>
                            <p class="font-medium">${stop.stop_name}</p>
                            <p class="text-sm text-gray-600">${stop.landmark || ''}</p>
                        </div>
                        <div class="text-right">
                            <span class="text-xs bg-gray-100 text-gray-800 px-2 py-1 rounded">${stop.stop_order}</span>
                            ${isCurrent ?
                                '<span class="ml-2 text-xs bg-green-100 text-green-800 px-2 py-1 rounded">Current</span>' : ''}
                            ${isNext ?
                                '<span class="ml-2 text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded">Next</span>' : ''}
                        </div>
                    </div>
                `;

                stopsList.appendChild(stopElement);
            });
        }

        // Update bus information display
        function updateBusInfo(busData) {
            // Update basic info
            document.getElementById('currentStop').textContent = busData.current_stop_name || 'Not available';
            document.getElementById('nextStop').textContent = busData.next_stop_name || 'Not available';
            document.getElementById('busNumber').textContent = busData.bus_number;
            document.getElementById('driverName').textContent = busData.driver_name;
            document.getElementById('passengerCount').textContent = `${busData.passenger_count}/${busData.capacity}`;
            document.getElementById('currentSpeed').textContent = busData.speed_kmh ? `${busData.speed_kmh.toFixed(1)} km/h` : '0 km/h';
            document.getElementById('eta').textContent = `${busData.eta_minutes} minutes`;

            // Update progress bar
            document.getElementById('progressFill').style.width = `${busData.progress_percentage}%`;

            // Update driver status
            const driverStatusIndicator = document.getElementById('driverOnlineStatus');
            const driverStatusText = document.getElementById('driverStatusText');
            const tripStatusText = document.getElementById('tripStatusText');

            if (busData.driver_online) {
                driverStatusIndicator.className = 'status-indicator online';
                driverStatusText.textContent = 'Driver: Online';
            } else {
                driverStatusIndicator.className = 'status-indicator offline';
                driverStatusText.textContent = 'Driver: Offline';
            }

            // Update trip status
            if (busData.trip_status === 'in_progress') {
                tripStatusText.className = 'trip-status trip-active';
                tripStatusText.textContent = 'Trip: Active';
                document.getElementById('nextBusIn').textContent = 'Now';
            } else if (busData.trip_status === 'scheduled') {
                tripStatusText.className = 'trip-status trip-inactive';
                tripStatusText.textContent = 'Trip: Scheduled';
                document.getElementById('nextBusIn').textContent = '15 minutes';
            } else {
                tripStatusText.className = 'trip-status trip-not-started';
                tripStatusText.textContent = 'Trip: Not Started';
                document.getElementById('nextBusIn').textContent = 'No active trip';
            }

            // Update last update time
            const timeDiff = Math.floor((new Date() - lastUpdateTime) / 1000);
            let timeText = '';
            if (timeDiff < 60) {
                timeText = 'Just now';
            } else if (timeDiff < 3600) {
                timeText = `${Math.floor(timeDiff / 60)} minutes ago`;
            } else {
                timeText = `${Math.floor(timeDiff / 3600)} hours ago`;
            }
            document.getElementById('lastUpdate').textContent = timeText;

            // Update ETA
            const now = new Date();
            const etaTime = new Date(now.getTime() + busData.eta_minutes * 60000);
            document.getElementById('routeETA').textContent = `${etaTime.getHours()}:${etaTime.getMinutes().toString().padStart(2, '0')}`;
            
            // Update start time
            if (busData.trip_status === 'in_progress') {
                document.getElementById('startTime').textContent = '7:00 AM';
            } else {
                document.getElementById('startTime').textContent = '-';
            }
        }

        // Fetch the latest bus data from the server
        function fetchBusData() {
            fetch('../api/get_passenger_bus_data.php')
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        lastUpdateTime = new Date();
                        
                        const busData = data.bus_data;
                        const stops = data.bus_stops;

                        // Update map with stops if we have them
                        if (stops && stops.length > 0) {
                            updateMapWithStops(stops);
                        }

                        // Update bus position
                        updateBusPosition(busData.latitude, busData.longitude);

                        // Update stops list
                        renderStopsList(busData.current_stop_id, busData.next_stop_id);

                        // Update bus information
                        updateBusInfo(busData);

                    } else {
                        console.error('Error fetching bus data:', data.message);
                        showStatus('Error loading bus data', true);
                    }
                })
                .catch(error => {
                    console.error('Error fetching bus data:', error);
                    showStatus('Network error - unable to load bus data', true);
                });
        }

        // Show status message
        function showStatus(message, isError = false) {
            // Create a temporary status display
            const statusDiv = document.createElement('div');
            statusDiv.className = `fixed top-4 right-4 p-4 rounded-lg shadow-lg z-50 ${
                isError ? 'bg-red-500 text-white' : 'bg-green-500 text-white'
            }`;
            statusDiv.innerHTML = `
                <div class="flex items-center">
                    <i class="fas ${isError ? 'fa-exclamation-triangle' : 'fa-check-circle'} mr-2"></i>
                    <span>${message}</span>
                </div>
            `;
            
            document.body.appendChild(statusDiv);
            
            // Remove after 3 seconds
            setTimeout(() => {
                if (statusDiv.parentNode) {
                    statusDiv.parentNode.removeChild(statusDiv);
                }
            }, 3000);
        }

        // Initialize the app
        document.addEventListener('DOMContentLoaded', function() {
            // Initialize map with default location
            initMap();

            // Fetch bus data immediately
            fetchBusData();

            // Set up periodic updates every 10 seconds
            updateInterval = setInterval(fetchBusData, 10000);

            // Refresh button
            document.getElementById('refreshBtn').addEventListener('click', function() {
                fetchBusData();
                const icon = this.querySelector('i');
                icon.classList.add('fa-spin');
                setTimeout(() => icon.classList.remove('fa-spin'), 1000);
            });

            // Notify button
            document.getElementById('notifyBtn').addEventListener('click', function() {
                const currentStop = document.getElementById('currentStop').textContent;
                const nextStop = document.getElementById('nextStop').textContent;
                alert(`You will be notified when the bus approaches ${nextStop}! Current location: ${currentStop}`);
            });

            // Handle page visibility changes
            document.addEventListener('visibilitychange', function() {
                if (document.hidden) {
                    // Page is hidden, stop updates to save resources
                    clearInterval(updateInterval);
                } else {
                    // Page is visible, restart updates
                    updateInterval = setInterval(fetchBusData, 10000);
                    fetchBusData(); // Immediate update
                }
            });
        });

        // Clean up on page unload
        window.addEventListener('beforeunload', function() {
            if (updateInterval) {
                clearInterval(updateInterval);
            }
        });
    </script>
</body>
</html>
<?php
// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../includes/config.php';
require_once '../includes/functions.php';

// Start session at the very beginning
session_start();

// Debug: Check if session is working
error_log("Session ID: " . session_id());
error_log("Session status: " . session_status());

// Check if user is already logged in
if (isset($_SESSION['driver_id']) && isset($_SESSION['session_token'])) {
    header('Location: dashboard.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = sanitize_input($_POST['username']);
    $password = $_POST['password'];
    
    error_log("Login attempt for username: " . $username);
    
    // Validate inputs
    if (empty($username) || empty($password)) {
        $error = "Username and password are required";
    } else {
        try {
            // Get user by username
            $stmt = $pdo->prepare("
                SELECT user_id, username, password_hash, full_name, user_type 
                FROM users 
                WHERE username = ? AND user_type = 'driver' AND is_active = 1
            ");
            $stmt->execute([$username]);
            $user = $stmt->fetch();
            
            error_log("User query result: " . print_r($user, true));
            
            if ($user) {
                // Debug password verification
                error_log("Input password: " . $password);
                error_log("Stored hash: " . $user['password_hash']);
                error_log("Password verify result: " . (password_verify($password, $user['password_hash']) ? 'true' : 'false'));
                
                if (password_verify($password, $user['password_hash'])) {
                    // Create session token
                    $session_token = generate_session_token();
                    $ip_address = get_client_ip();
                    $user_agent = $_SERVER['HTTP_USER_AGENT'];
                    
                    error_log("Creating session for user: " . $user['user_id']);
                    
                    // Insert session record
                    $stmt = $pdo->prepare("
                        INSERT INTO user_sessions (user_id, session_token, ip_address, user_agent) 
                        VALUES (?, ?, ?, ?)
                    ");
                    $insert_result = $stmt->execute([$user['user_id'], $session_token, $ip_address, $user_agent]);
                    
                    error_log("Session insert result: " . ($insert_result ? 'success' : 'failed'));
                    
                    if ($insert_result) {
                        // Update last login
                        $stmt = $pdo->prepare("UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE user_id = ?");
                        $stmt->execute([$user['user_id']]);
                        
                        // Set session variables
                        $_SESSION['driver_id'] = $user['user_id'];
                        $_SESSION['driver_name'] = $user['full_name'];
                        $_SESSION['session_token'] = $session_token;
                        
                        error_log("Session variables set:");
                        error_log("driver_id: " . $_SESSION['driver_id']);
                        error_log("driver_name: " . $_SESSION['driver_name']);
                        error_log("session_token: " . $_SESSION['session_token']);
                        
                        // Verify session is set
                        if (isset($_SESSION['driver_id']) && isset($_SESSION['session_token'])) {
                            error_log("Redirecting to dashboard...");
                            header('Location: dashboard.php');
                            exit;
                        } else {
                            $error = "Session creation failed";
                        }
                    } else {
                        $error = "Failed to create session";
                    }
                } else {
                    $error = "Invalid password";
                }
            } else {
                $error = "Driver not found or inactive";
            }
        } catch (PDOException $e) {
            error_log("Database error: " . $e->getMessage());
            $error = "Database error occurred. Please try again.";
        } catch (Exception $e) {
            error_log("General error: " . $e->getMessage());
            $error = "An error occurred. Please try again.";
        }
    }
}

// Debug: Check if we reached this point
error_log("Login page loaded with error: " . $error);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Driver Login - Bus Tracking System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { 
            background: #f8f9fa; 
            font-family: Arial, sans-serif;
        }
        .login-container { 
            max-width: 400px; 
            margin: 100px auto; 
            padding: 20px; 
        }
        .card { 
            border-radius: 10px; 
            box-shadow: 0 0 20px rgba(0,0,0,0.1); 
            border: none;
        }
        .card-header {
            background: #007bff;
            color: white;
            text-align: center;
            border-radius: 10px 10px 0 0 !important;
            padding: 20px;
        }
        .btn-primary {
            background: #007bff;
            border: none;
            padding: 12px;
            font-weight: 600;
        }
        .btn-primary:hover {
            background: #0056b3;
        }
        .alert {
            border-radius: 8px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="login-container">
            <div class="card">
                <div class="card-header">
                    <h3 class="mb-0">Driver Login</h3>
                    <p class="mb-0 opacity-75">Bus Tracking System</p>
                </div>
                <div class="card-body p-4">
                    <?php if (!empty($error)): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <?php echo htmlspecialchars($error); ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>
                    
                    <?php if (isset($_GET['logout']) && $_GET['logout'] == 'success'): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            You have been successfully logged out.
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>
                    
                    <?php if (isset($_GET['session']) && $_GET['session'] == 'expired'): ?>
                        <div class="alert alert-warning alert-dismissible fade show" role="alert">
                            Your session has expired. Please login again.
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>

                    <form method="POST" id="loginForm">
                        <div class="mb-3">
                            <label for="username" class="form-label">Username</label>
                            <input type="text" class="form-control" id="username" name="username" 
                                   value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>" 
                                   required autofocus>
                        </div>
                        <div class="mb-3">
                            <label for="password" class="form-label">Password</label>
                            <input type="password" class="form-control" id="password" name="password" required>
                        </div>
                        <button type="submit" class="btn btn-primary w-100">Login</button>
                    </form>
                    
                    <div class="mt-3 text-center">
                        <small class="text-muted">
                            Test Credentials: driver1 / [check database for password]
                        </small>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Form validation
        document.getElementById('loginForm').addEventListener('submit', function(e) {
            const username = document.getElementById('username').value.trim();
            const password = document.getElementById('password').value.trim();
            
            if (!username || !password) {
                e.preventDefault();
                alert('Please fill in both username and password');
                return false;
            }
        });

        // Clear error when user starts typing
        document.getElementById('username').addEventListener('input', function() {
            const alert = document.querySelector('.alert');
            if (alert) {
                alert.remove();
            }
        });

        document.getElementById('password').addEventListener('input', function() {
            const alert = document.querySelector('.alert');
            if (alert) {
                alert.remove();
            }
        });
    </script>
</body>
</html>
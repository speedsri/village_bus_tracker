<?php
require_once '../includes/config.php';

header('Content-Type: application/json');

$route_id = intval($_GET['route_id']);

$stmt = $pdo->prepare("
    SELECT stop_id, stop_name, stop_order, latitude, longitude, landmark
    FROM bus_stops 
    WHERE route_id = ? AND is_active = 1
    ORDER BY stop_order
");
$stmt->execute([$route_id]);

$stops = $stmt->fetchAll();
echo json_encode($stops);
?>
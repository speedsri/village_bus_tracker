<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $driver_id = intval($input['driver_id']);
    $assignment_id = intval($input['assignment_id']);
    
    try {
        // Get driver's current assignment and bus
        $stmt = $pdo->prepare("
            SELECT da.*, b.bus_id, b.route_id
            FROM driver_assignments da
            JOIN buses b ON da.bus_id = b.bus_id
            WHERE da.assignment_id = ? AND da.driver_id = ? AND da.assigned_date = CURDATE() 
            AND da.status IN ('scheduled', 'active')
        ");
        $stmt->execute([$assignment_id, $driver_id]);
        $assignment = $stmt->fetch();
        
        if (!$assignment) {
            echo json_encode(['success' => false, 'message' => 'No active assignment found']);
            exit;
        }
        
        // Check if there's already an active trip
        $stmt = $pdo->prepare("
            SELECT trip_id FROM bus_trips 
            WHERE driver_id = ? AND trip_status = 'in_progress'
        ");
        $stmt->execute([$driver_id]);
        if ($stmt->fetch()) {
            echo json_encode(['success' => false, 'message' => 'You already have an active trip']);
            exit;
        }
        
        // Get first stop for the route
        $stmt = $pdo->prepare("
            SELECT stop_id FROM bus_stops 
            WHERE route_id = ? AND stop_order = 1 AND is_active = 1
        ");
        $stmt->execute([$assignment['route_id']]);
        $first_stop = $stmt->fetch();
        
        // Create new trip
        $scheduled_start = date('Y-m-d H:i:s');
        $scheduled_end = date('Y-m-d H:i:s', strtotime('+2 hours'));
        
        $stmt = $pdo->prepare("
            INSERT INTO bus_trips (bus_id, route_id, driver_id, trip_direction, 
                                 scheduled_start_time, actual_start_time, scheduled_end_time, 
                                 current_stop_id, trip_status, passenger_count)
            VALUES (?, ?, ?, 'outbound', ?, NOW(), ?, ?, 'in_progress', 0)
        ");
        
        $result = $stmt->execute([
            $assignment['bus_id'], 
            $assignment['route_id'], 
            $driver_id, 
            $scheduled_start, 
            $scheduled_end,
            $first_stop ? $first_stop['stop_id'] : null
        ]);
        
        if ($result) {
            $trip_id = $pdo->lastInsertId();
            
            // Update assignment status to active
            $stmt = $pdo->prepare("UPDATE driver_assignments SET status = 'active' WHERE assignment_id = ?");
            $stmt->execute([$assignment_id]);
            
            // Log the activity
            $stmt = $pdo->prepare("
                INSERT INTO activity_logs (user_id, action_type, table_affected, record_id, new_values, ip_address)
                VALUES (?, 'start_trip', 'bus_trips', ?, ?, ?)
            ");
            $stmt->execute([
                $driver_id,
                $trip_id,
                json_encode(['trip_id' => $trip_id, 'status' => 'in_progress']),
                get_client_ip()
            ]);
            
            echo json_encode(['success' => true, 'trip_id' => $trip_id]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to start trip']);
        }
    } catch (PDOException $e) {
        error_log("Start trip error: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}
?>
<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST');
header('Access-Control-Allow-Headers: Content-Type');

// Add cache control headers for real-time data
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');

try {
    // Get the latest bus location data with improved query
    $stmt = $pdo->prepare("
        SELECT 
            bl.latitude,
            bl.longitude,
            bl.speed_kmh,
            bl.timestamp,
            bl.current_stop_id,
            bl.next_stop_id,
            bs_current.stop_name as current_stop_name,
            bs_next.stop_name as next_stop_name,
            t.trip_id,
            t.trip_status,
            t.trip_direction,
            t.passenger_count,
            t.actual_start_time,
            b.bus_number,
            b.capacity,
            u.full_name as driver_name,
            u.user_id as driver_id,
            r.route_name,
            r.start_location,
            r.end_location,
            CASE 
                WHEN t.trip_status = 'in_progress' AND TIMESTAMPDIFF(MINUTE, bl.timestamp, NOW()) < 5 THEN 1 
                ELSE 0 
            END as driver_online,
            (SELECT COUNT(*) FROM bus_stops WHERE route_id = t.route_id AND is_active = 1) as total_stops,
            (SELECT stop_order FROM bus_stops WHERE stop_id = bl.current_stop_id) as current_stop_order
        FROM bus_locations bl
        JOIN bus_trips t ON bl.trip_id = t.trip_id
        JOIN buses b ON t.bus_id = b.bus_id
        JOIN routes r ON t.route_id = r.route_id
        JOIN users u ON t.driver_id = u.user_id
        LEFT JOIN bus_stops bs_current ON bl.current_stop_id = bs_current.stop_id
        LEFT JOIN bus_stops bs_next ON bl.next_stop_id = bs_next.stop_id
        WHERE bl.is_current_location = 1
        AND t.trip_status IN ('in_progress', 'scheduled')
        AND t.route_id = 1  -- Kurunagala to Alakoladeniya route
        ORDER BY bl.timestamp DESC
        LIMIT 1
    ");
    
    $stmt->execute();
    $bus_data = $stmt->fetch();

    // Get all bus stops for the route
    $stmt = $pdo->prepare("
        SELECT stop_id, stop_name, stop_order, latitude, longitude, landmark, estimated_time_from_start
        FROM bus_stops 
        WHERE route_id = 1 AND is_active = 1 
        ORDER BY stop_order
    ");
    $stmt->execute();
    $bus_stops = $stmt->fetchAll();

    if ($bus_data) {
        // Calculate progress and ETA
        $total_stops = count($bus_stops);
        $current_stop_order = $bus_data['current_stop_order'] ?? 1;
        
        $progress_percentage = $total_stops > 0 ? 
            (($current_stop_order - 1) / ($total_stops - 1)) * 100 : 0;
        
        $remaining_stops = $total_stops - $current_stop_order;
        $eta_minutes = max(1, $remaining_stops * 2); // Approx 2 minutes per stop
        
        // Prepare response data
        $response_data = [
            'latitude' => floatval($bus_data['latitude']),
            'longitude' => floatval($bus_data['longitude']),
            'speed_kmh' => $bus_data['speed_kmh'] ? floatval($bus_data['speed_kmh']) : 0,
            'current_stop_id' => $bus_data['current_stop_id'],
            'next_stop_id' => $bus_data['next_stop_id'],
            'current_stop_name' => $bus_data['current_stop_name'] ?? 'Not available',
            'next_stop_name' => $bus_data['next_stop_name'] ?? 'Not available',
            'trip_status' => $bus_data['trip_status'],
            'trip_direction' => $bus_data['trip_direction'],
            'passenger_count' => intval($bus_data['passenger_count']),
            'bus_number' => $bus_data['bus_number'],
            'capacity' => intval($bus_data['capacity']),
            'driver_name' => $bus_data['driver_name'],
            'driver_online' => boolval($bus_data['driver_online']),
            'route_name' => $bus_data['route_name'],
            'last_update' => $bus_data['timestamp'],
            'progress_percentage' => min(100, max(0, $progress_percentage)),
            'eta_minutes' => $eta_minutes,
            'total_stops' => $total_stops,
            'current_stop_order' => $current_stop_order
        ];

        echo json_encode([
            'success' => true,
            'bus_data' => $response_data,
            'bus_stops' => $bus_stops,
            'server_time' => date('Y-m-d H:i:s')
        ]);
        
    } else {
        // No active trip found, return default data
        $default_data = [
            'latitude' => 7.48813300,
            'longitude' => 80.36424000,
            'speed_kmh' => 0,
            'current_stop_id' => 7,
            'next_stop_id' => 8,
            'current_stop_name' => 'Main Stand',
            'next_stop_name' => 'Police Halt',
            'trip_status' => 'not_started',
            'trip_direction' => 'outbound',
            'passenger_count' => 0,
            'bus_number' => 'KGA-001',
            'capacity' => 52,
            'driver_name' => 'No Active Driver',
            'driver_online' => false,
            'route_name' => 'Kurunagala to Alakoladeniya',
            'last_update' => date('Y-m-d H:i:s'),
            'progress_percentage' => 0,
            'eta_minutes' => 30,
            'total_stops' => count($bus_stops),
            'current_stop_order' => 1
        ];

        echo json_encode([
            'success' => true,
            'bus_data' => $default_data,
            'bus_stops' => $bus_stops,
            'server_time' => date('Y-m-d H:i:s'),
            'message' => 'No active trip - showing default data'
        ]);
    }

} catch (PDOException $e) {
    error_log("API Error: " . $e->getMessage());
    
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Database error occurred',
        'error' => $e->getMessage(),
        'server_time' => date('Y-m-d H:i:s')
    ]);
}
?>
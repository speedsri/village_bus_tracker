<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    
    $username = sanitize_input($input['username']);
    $password = $input['password'];
    
    $stmt = $pdo->prepare("
        SELECT user_id, username, password_hash, full_name 
        FROM users 
        WHERE username = ? AND user_type = 'driver' AND is_active = 1
    ");
    $stmt->execute([$username]);
    $user = $stmt->fetch();
    
    if ($user && password_verify($password, $user['password_hash'])) {
        $session_token = generate_session_token();
        $ip_address = get_client_ip();
        $user_agent = $_SERVER['HTTP_USER_AGENT'];
        
        $stmt = $pdo->prepare("
            INSERT INTO user_sessions (user_id, session_token, ip_address, user_agent) 
            VALUES (?, ?, ?, ?)
        ");
        $stmt->execute([$user['user_id'], $session_token, $ip_address, $user_agent]);
        
        echo json_encode([
            'success' => true,
            'driver_id' => $user['user_id'],
            'driver_name' => $user['full_name'],
            'session_token' => $session_token
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Invalid credentials'
        ]);
    }
}
?>
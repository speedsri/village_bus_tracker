<?php
require_once '../includes/config.php';

header('Content-Type: application/json');

// Get current bus locations with trip info
$stmt = $pdo->query("
    SELECT 
        b.bus_id,
        b.bus_number,
        r.route_name,
        bl.latitude,
        bl.longitude,
        bl.speed_kmh,
        bl.timestamp as last_update,
        t.trip_status,
        t.trip_direction,
        bs_current.stop_name as current_stop,
        bs_next.stop_name as next_stop
    FROM bus_locations bl
    JOIN buses b ON bl.bus_id = b.bus_id
    JOIN bus_trips t ON bl.trip_id = t.trip_id
    JOIN routes r ON t.route_id = r.route_id
    LEFT JOIN bus_stops bs_current ON bl.current_stop_id = bs_current.stop_id
    LEFT JOIN bus_stops bs_next ON bl.next_stop_id = bs_next.stop_id
    WHERE bl.is_current_location = 1 
    AND t.trip_status = 'in_progress'
    ORDER BY bl.timestamp DESC
");

$buses = $stmt->fetchAll();
echo json_encode($buses);
?>
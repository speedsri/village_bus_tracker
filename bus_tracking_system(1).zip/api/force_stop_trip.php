<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $driver_id = isset($input['driver_id']) ? intval($input['driver_id']) : null;
    
    try {
        // Get any active trip for this driver
        $stmt = $pdo->prepare("
            SELECT trip_id FROM bus_trips 
            WHERE driver_id = ? AND trip_status = 'in_progress'
        ");
        $stmt->execute([$driver_id]);
        $active_trip = $stmt->fetch();
        
        if ($active_trip) {
            // Force end the trip
            $stmt = $pdo->prepare("
                UPDATE bus_trips 
                SET trip_status = 'cancelled', actual_end_time = NOW() 
                WHERE trip_id = ?
            ");
            
            if ($stmt->execute([$active_trip['trip_id']])) {
                echo json_encode(['success' => true]);
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to force stop trip']);
            }
        } else {
            echo json_encode(['success' => false, 'message' => 'No active trip found']);
        }
    } catch (PDOException $e) {
        error_log("Force stop trip error: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}
?>
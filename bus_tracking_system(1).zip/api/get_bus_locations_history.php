<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

$trip_id = isset($_GET['trip_id']) ? intval($_GET['trip_id']) : null;

try {
    if ($trip_id) {
        // Get location history for specific trip
        $stmt = $pdo->prepare("
            SELECT latitude, longitude, speed_kmh, timestamp, accuracy_meters
            FROM bus_locations 
            WHERE trip_id = ? 
            ORDER BY timestamp DESC 
            LIMIT 50
        ");
        $stmt->execute([$trip_id]);
    } else {
        // Get recent locations for all active trips
        $stmt = $pdo->prepare("
            SELECT bl.latitude, bl.longitude, bl.speed_kmh, bl.timestamp, 
                   b.bus_number, t.trip_id
            FROM bus_locations bl
            JOIN bus_trips t ON bl.trip_id = t.trip_id
            JOIN buses b ON t.bus_id = b.bus_id
            WHERE t.trip_status = 'in_progress'
            AND bl.timestamp >= DATE_SUB(NOW(), INTERVAL 1 HOUR)
            ORDER BY bl.timestamp DESC
            LIMIT 100
        ");
        $stmt->execute();
    }
    
    $locations = $stmt->fetchAll();
    
    echo json_encode([
        'success' => true,
        'locations' => $locations,
        'count' => count($locations)
    ]);
    
} catch (PDOException $e) {
    error_log("Location history error: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'Database error occurred'
    ]);
}
?>
bus_tracking_system/
├── includes/
│   ├── config.php
│   ├── functions.php
│   └── auth.php
├── driver/
│   ├── index.php (login)
│   ├── dashboard.php
│   ├── trip.php
│   └── location.php
├── passenger/
│   ├── index.php
│   ├── map.php
│   └── routes.php
├── api/
│   ├── driver_login.php
│   ├── update_location.php
│   ├── start_trip.php
│   ├── end_trip.php
│   ├── get_bus_locations.php
│   └── get_routes.php
├── assets/
│   ├── css/
│   ├── js/
│   └── images/
└── README.md


# Bus Tracking System

A real-time bus tracking system with Driver and Passenger web applications.

## Features

### Driver App
- Secure login for drivers
- Trip management (start/end trips)
- Real-time GPS location sharing
- Route and stop information
- Offline capability (sync when online)

### Passenger App
- Live bus tracking on interactive map
- Route information and schedules
- Estimated arrival times
- Filter buses by route

## Installation

1. **Database Setup**
   - Import the provided `bus_tracking_system.sql` into your MySQL database
   - Update database credentials in `includes/config.php`

2. **Web Server Setup**
   - Place all files in your web server directory (Apache/Nginx)
   - Ensure PHP 7.4+ with PDO MySQL extension
   - Configure proper file permissions

3. **Configuration**
   - Update database credentials in `includes/config.php`
   - Set your timezone in the same file
   - Configure your server for HTTPS in production

## Usage

### For Drivers
1. Navigate to `/driver/index.php`
2. Login with driver credentials
3. View assigned bus and route
4. Start trip when ready
5. Location updates automatically every 10 seconds
6. End trip when completed

### For Passengers
1. Navigate to `/passenger/index.php`
2. View live bus locations on map
3. Filter by route using dropdown
4. Check route details in "Routes & Schedules" page

## API Endpoints

- `POST /api/driver_login.php` - Driver authentication
- `POST /api/start_trip.php` - Start new trip
- `POST /api/end_trip.php` - End current trip  
- `POST /api/update_location.php` - Update bus location
- `GET /api/get_bus_locations.php` - Get current bus locations
- `GET /api/get_routes.php` - Get all routes
- `GET /api/get_route_stops.php` - Get stops for a route

## Security Features

- Password hashing using bcrypt
- Session management with tokens
- Input sanitization
- SQL injection prevention with prepared statements
- IP tracking for sessions

## Performance Optimization

- Efficient database indexing
- Minimal location update frequency
- Cached route data
- Optimized map rendering

## Browser Support

- Chrome 60+
- Firefox 55+
- Safari 12+
- Edge 79+

## Mobile Support

- Responsive design for mobile devices
- Touch-friendly interface
- Optimized for mobile data usage
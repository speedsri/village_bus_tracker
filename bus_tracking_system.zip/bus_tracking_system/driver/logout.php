<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../includes/config.php';
require_once '../includes/auth.php';

error_log("Logout attempt");

if (is_driver_logged_in()) {
    $driver_id = $_SESSION['driver_id'];
    $session_token = $_SESSION['session_token'];
    
    error_log("Logging out driver: " . $driver_id);
    
    // Logout from database
    logout_user($pdo, $driver_id, $session_token);
    
    // Clear session
    session_unset();
    session_destroy();
    
    error_log("Logout successful");
} else {
    error_log("No active session to logout");
}

// Redirect to login page with success message
header('Location: index.php?logout=success');
exit;
?>
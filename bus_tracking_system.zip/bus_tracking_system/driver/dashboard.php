<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Start session at the very beginning
session_start();

require_once '../includes/config.php';
require_once '../includes/auth.php';

if (!is_driver_logged_in()) {
    header('Location: index.php');
    exit;
}

$driver_id = $_SESSION['driver_id'];
$driver_name = $_SESSION['driver_name'];
$session_token = $_SESSION['session_token'];

// Verify session
$session = verify_session($pdo, $driver_id, $session_token);
if (!$session) {
    session_destroy();
    header('Location: index.php?session=expired');
    exit;
}

// Get driver's current assignment
$stmt = $pdo->prepare("
    SELECT da.*, b.bus_id, b.bus_number, b.registration_number, b.model, b.capacity,
           r.route_id, r.route_name, r.route_code, r.start_location, r.end_location,
           r.total_distance_km, r.estimated_duration_minutes
    FROM driver_assignments da
    JOIN buses b ON da.bus_id = b.bus_id
    JOIN routes r ON da.route_id = r.route_id
    WHERE da.driver_id = ? AND da.assigned_date = CURDATE() AND da.status IN ('scheduled', 'active')
    ORDER BY da.assignment_id DESC LIMIT 1
");
$stmt->execute([$driver_id]);
$assignment = $stmt->fetch();

// Get current active trip
$stmt = $pdo->prepare("
    SELECT t.*, r.route_name, b.bus_number,
           bs_current.stop_name as current_stop_name
    FROM bus_trips t
    JOIN routes r ON t.route_id = r.route_id
    JOIN buses b ON t.bus_id = b.bus_id
    LEFT JOIN bus_stops bs_current ON t.current_stop_id = bs_current.stop_id
    WHERE t.driver_id = ? AND t.trip_status = 'in_progress'
    ORDER BY t.trip_id DESC LIMIT 1
");
$stmt->execute([$driver_id]);
$active_trip = $stmt->fetch();

// Get route stops
$route_id = $assignment ? $assignment['route_id'] : null;
$bus_stops = [];
if ($route_id) {
    $stmt = $pdo->prepare("
        SELECT stop_id, stop_name, stop_order, latitude, longitude, landmark, estimated_time_from_start
        FROM bus_stops 
        WHERE route_id = ? AND is_active = 1 
        ORDER BY stop_order
    ");
    $stmt->execute([$route_id]);
    $bus_stops = $stmt->fetchAll();
}

// Get recent location updates
$recent_locations = [];
if ($active_trip) {
    $stmt = $pdo->prepare("
        SELECT latitude, longitude, speed_kmh, timestamp, accuracy_meters
        FROM bus_locations 
        WHERE trip_id = ? 
        ORDER BY timestamp DESC 
        LIMIT 5
    ");
    $stmt->execute([$active_trip['trip_id']]);
    $recent_locations = $stmt->fetchAll();
}

// Convert bus stops to JSON for JavaScript
$bus_stops_json = json_encode($bus_stops);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BusLK - Driver Tracking System</title>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" />
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"></script>
    <style>
        #map {
            height: 400px;
            width: 100%;
            z-index: 1;
            border-radius: 8px;
        }
        .loading {
            display: inline-block;
            width: 20px;
            height: 20px;
            border: 3px solid rgba(255,255,255,.3);
            border-radius: 50%;
            border-top-color: #fff;
            animation: spin 1s ease-in-out infinite;
        }
        @keyframes spin {
            to { transform: rotate(360deg); }
        }
        .card {
            transition: all 0.3s ease;
        }
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
        }
        .sidebar {
            width: 280px;
            transition: all 0.3s ease;
        }
        .main-content {
            transition: all 0.3s ease;
        }
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
                position: fixed;
                height: 100vh;
                z-index: 100;
            }
            .sidebar.active {
                transform: translateX(0);
            }
            .main-content {
                width: 100%;
            }
            .menu-btn {
                display: block;
            }
        }
        .stop-list {
            max-height: 300px;
            overflow-y: auto;
        }
        .current-stop {
            background-color: #E1F5FE;
            border-left: 4px solid #0288D1;
        }
        .passed-stop {
            color: #9E9E9E;
        }
        .next-stop {
            font-weight: bold;
        }
        .hidden {
            display: none !important;
        }
        .location-update {
            background: #f8f9fa;
            border-left: 4px solid #007bff;
            padding: 8px;
            margin-bottom: 6px;
            border-radius: 4px;
            font-size: 0.875rem;
        }
    </style>
</head>
<body class="bg-gray-100 min-h-screen flex">
    <!-- Sidebar -->
    <div class="sidebar bg-blue-800 text-white p-4 flex flex-col">
        <div class="flex items-center justify-between mb-8">
            <h1 class="text-xl font-bold flex items-center">
                <i class="fas fa-bus mr-2"></i> BusLK Driver
            </h1>
            <button class="menu-btn md:hidden text-white" onclick="toggleSidebar()">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <div class="flex items-center mb-8 p-2 bg-blue-700 rounded-lg">
            <div class="w-12 h-12 rounded-full bg-blue-600 flex items-center justify-center mr-3">
                <i class="fas fa-user text-xl"></i>
            </div>
            <div>
                <p class="font-semibold" id="sidebarDriverName"><?php echo htmlspecialchars($driver_name); ?></p>
                <p class="text-sm text-blue-200">ID: DRV-<?php echo str_pad($driver_id, 3, '0', STR_PAD_LEFT); ?></p>
            </div>
        </div>
        <nav class="flex-1">
            <ul>
                <li class="mb-2">
                    <a href="#" class="flex items-center p-2 rounded-lg bg-blue-700">
                        <i class="fas fa-map-marker-alt mr-3"></i> Live Tracking
                    </a>
                </li>
                <li class="mb-2">
                    <a href="#" class="flex items-center p-2 rounded-lg hover:bg-blue-700">
                        <i class="fas fa-route mr-3"></i> Routes
                    </a>
                </li>
                <li class="mb-2">
                    <a href="#" class="flex items-center p-2 rounded-lg hover:bg-blue-700">
                        <i class="fas fa-history mr-3"></i> Trip History
                    </a>
                </li>
                <li class="mb-2">
                    <a href="#" class="flex items-center p-2 rounded-lg hover:bg-blue-700">
                        <i class="fas fa-cog mr-3"></i> Settings
                    </a>
                </li>
            </ul>
        </nav>
        <div class="mt-auto">
            <a href="logout.php" class="w-full flex items-center justify-center p-2 rounded-lg bg-blue-700 hover:bg-blue-600 text-white">
                <i class="fas fa-sign-out-alt mr-2"></i> Logout
            </a>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content flex-1 p-6">
        <div class="flex justify-between items-center mb-6">
            <button class="menu-btn md:hidden text-gray-600" onclick="toggleSidebar()">
                <i class="fas fa-bars text-xl"></i>
            </button>
            <h2 class="text-2xl font-bold text-gray-800">Bus Tracking Dashboard</h2>
            <div class="flex items-center">
                <span class="bg-green-100 text-green-800 text-xs font-medium mr-2 px-2.5 py-0.5 rounded-full">Online</span>
                <div class="w-10 h-10 rounded-full bg-gray-200 flex items-center justify-center ml-4">
                    <i class="fas fa-bell text-gray-600"></i>
                </div>
            </div>
        </div>

        <!-- Status Cards -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <div class="card bg-white p-4 rounded-lg shadow">
                <div class="flex items-center">
                    <div class="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center mr-4">
                        <i class="fas fa-bus text-blue-600 text-xl"></i>
                    </div>
                    <div>
                        <p class="text-sm text-gray-600">Bus Number</p>
                        <p class="font-semibold text-lg" id="busNumber">
                            <?php echo $assignment ? htmlspecialchars($assignment['bus_number']) : 'Not Assigned'; ?>
                        </p>
                    </div>
                </div>
            </div>
            <div class="card bg-white p-4 rounded-lg shadow">
                <div class="flex items-center">
                    <div class="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center mr-4">
                        <i class="fas fa-route text-green-600 text-xl"></i>
                    </div>
                    <div>
                        <p class="text-sm text-gray-600">Current Route</p>
                        <p class="font-semibold text-lg" id="routeInfo">
                            <?php echo $assignment ? htmlspecialchars($assignment['route_name']) : 'No Route'; ?>
                        </p>
                    </div>
                </div>
            </div>
            <div class="card bg-white p-4 rounded-lg shadow">
                <div class="flex items-center">
                    <div class="w-12 h-12 rounded-full bg-purple-100 flex items-center justify-center mr-4">
                        <i class="fas fa-users text-purple-600 text-xl"></i>
                    </div>
                    <div>
                        <p class="text-sm text-gray-600">Passengers</p>
                        <p class="font-semibold text-lg">
                            <?php echo $assignment ? '0/' . $assignment['capacity'] : '0/0'; ?>
                        </p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Map and Controls -->
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
            <div class="lg:col-span-2 bg-white p-4 rounded-lg shadow">
                <div class="flex justify-between items-center mb-4">
                    <h3 class="text-lg font-semibold">Live Location Tracking</h3>
                    <div class="flex items-center text-sm text-gray-600">
                        <span class="flex h-3 w-3 relative">
                            <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                            <span class="relative inline-flex rounded-full h-3 w-3 bg-green-500"></span>
                        </span>
                        <span class="ml-2">Live</span>
                    </div>
                </div>
                <div id="map"></div>
                <div class="grid grid-cols-2 gap-4 mt-4">
                    <div class="bg-gray-50 p-3 rounded-lg">
                        <p class="text-sm text-gray-600">Latitude</p>
                        <p class="font-semibold" id="latitude">0.000000</p>
                    </div>
                    <div class="bg-gray-50 p-3 rounded-lg">
                        <p class="text-sm text-gray-600">Longitude</p>
                        <p class="font-semibold" id="longitude">0.000000</p>
                    </div>
                </div>
            </div>

            <div class="bg-white p-4 rounded-lg shadow">
                <h3 class="text-lg font-semibold mb-4">Trip Controls</h3>
                <div class="mb-6">
                    <p class="text-sm text-gray-600 mb-2">Current Trip Status</p>
                    <div class="flex items-center">
                        <span class="bg-yellow-100 text-yellow-800 text-xs font-medium px-2.5 py-0.5 rounded-full" id="tripStatus">
                            <?php echo $active_trip ? 'In Progress' : 'Not Started'; ?>
                        </span>
                    </div>
                </div>

                <div class="space-y-4">
                    <!-- Force Stop Trip Button -->
                    <button id="forceStopTripBtn" class="w-full bg-orange-600 hover:bg-orange-700 text-white py-3 rounded-lg flex items-center justify-center hidden">
                        <i class="fas fa-exclamation-triangle mr-2"></i> Force Stop Trip
                    </button>

                    <!-- Start Trip Button -->
                    <button id="startTripBtn" class="w-full bg-green-600 hover:bg-green-700 text-white py-3 rounded-lg flex items-center justify-center <?php echo $active_trip ? 'hidden' : ''; ?>">
                        <i class="fas fa-play-circle mr-2"></i> Start Trip
                    </button>

                    <!-- End Trip Button -->
                    <button id="endTripBtn" class="w-full bg-red-600 hover:bg-red-700 text-white py-3 rounded-lg flex items-center justify-center <?php echo $active_trip ? '' : 'hidden'; ?>">
                        <i class="fas fa-stop-circle mr-2"></i> End Trip
                    </button>

                    <!-- Change Direction Button -->
                    <button id="changeDirectionBtn" class="w-full bg-purple-600 hover:bg-purple-700 text-white py-3 rounded-lg flex items-center justify-center hidden">
                        <i class="fas fa-exchange-alt mr-2"></i> Change Direction
                    </button>

                    <!-- Update Location Button -->
                    <button id="updateLocationBtn" class="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-lg flex items-center justify-center">
                        <i class="fas fa-location-arrow mr-2"></i> Update Location
                    </button>
                </div>

                <div class="mt-6 pt-4 border-t border-gray-200">
                    <h4 class="text-md font-semibold mb-2">Next Stop</h4>
                    <div class="flex items-center">
                        <div class="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center mr-3">
                            <i class="fas fa-map-marker text-blue-600"></i>
                        </div>
                        <div>
                            <p class="font-semibold" id="nextStop">-</p>
                            <p class="text-sm text-gray-600">ETA: <span id="eta">-</span></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Recent Locations & Bus Stops -->
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
            <!-- Recent Locations -->
            <div class="bg-white p-4 rounded-lg shadow">
                <h3 class="text-lg font-semibold mb-4">Recent Locations</h3>
                <div id="recentLocations">
                    <?php if (!empty($recent_locations)): ?>
                        <?php foreach ($recent_locations as $location): ?>
                            <div class="location-update">
                                <strong><?php echo $location['latitude']; ?>, <?php echo $location['longitude']; ?></strong><br>
                                Speed: <?php echo $location['speed_kmh'] ? $location['speed_kmh'] . ' km/h' : 'N/A'; ?> | 
                                <?php echo date('H:i:s', strtotime($location['timestamp'])); ?>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p class="text-gray-500 text-center py-4">No location updates yet</p>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Bus Stops List -->
            <div class="bg-white p-4 rounded-lg shadow">
                <h3 class="text-lg font-semibold mb-4">Bus Stops</h3>
                <div class="stop-list" id="stopsList">
                    <!-- Stops will be populated by JavaScript -->
                </div>
            </div>
        </div>

        <!-- Status Messages -->
        <div id="statusMessage" class="hidden p-4 rounded-lg mb-6"></div>

        <!-- Upcoming Stops Table -->
        <div class="bg-white p-4 rounded-lg shadow">
            <h3 class="text-lg font-semibold mb-4">Route Stops</h3>
            <div class="overflow-x-auto">
                <table class="w-full text-sm text-left text-gray-600">
                    <thead class="text-xs text-gray-700 uppercase bg-gray-50">
                        <tr>
                            <th scope="col" class="px-4 py-3">Stop</th>
                            <th scope="col" class="px-4 py-3">Order</th>
                            <th scope="col" class="px-4 py-3">Landmark</th>
                            <th scope="col" class="px-4 py-3">Est. Time</th>
                            <th scope="col" class="px-4 py-3">Status</th>
                        </tr>
                    </thead>
                    <tbody id="stopsTableBody">
                        <?php foreach ($bus_stops as $stop): ?>
                            <tr class="bg-white border-b hover:bg-gray-50">
                                <td class="px-4 py-2 font-medium text-gray-900"><?php echo htmlspecialchars($stop['stop_name']); ?></td>
                                <td class="px-4 py-2"><?php echo $stop['stop_order']; ?></td>
                                <td class="px-4 py-2"><?php echo htmlspecialchars($stop['landmark'] ?: '-'); ?></td>
                                <td class="px-4 py-2"><?php echo $stop['estimated_time_from_start']; ?> min</td>
                                <td class="px-4 py-2">
                                    <span class="bg-gray-100 text-gray-800 text-xs font-medium px-2 py-0.5 rounded">Pending</span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script>
        // Bus stops data from PHP
        const busStops = <?php echo $bus_stops_json ?: '[]'; ?>;
        
        // Global variables
        let map, marker, watchId;
        let currentTrip = <?php echo $active_trip ? json_encode($active_trip) : 'null'; ?>;
        let isTracking = false;
        let currentStopIndex = 0;
        let currentDirection = 'outbound';
        let locationUpdateInterval = null;

        // Initialize the map
        function initMap(lat = 7.48813300, lng = 80.36424000) {
            map = L.map('map').setView([lat, lng], 14);
            
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            }).addTo(map);

            // Add markers for bus stops
            const stopsToRender = currentDirection === 'outbound' ? busStops : [...busStops].reverse();
            
            stopsToRender.forEach((stop, index) => {
                const isPassed = index < currentStopIndex;
                const isCurrent = index === currentStopIndex;
                const isNext = index === currentStopIndex + 1;
                
                const stopIcon = L.divIcon({
                    className: 'custom-stop-marker',
                    html: `<div style="
                        background-color: ${isCurrent ? '#dc2626' : isPassed ? '#16a34a' : '#2563eb'};
                        width: 20px;
                        height: 20px;
                        border-radius: 50%;
                        border: 3px solid white;
                        box-shadow: 0 2px 4px rgba(0,0,0,0.3);
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        color: white;
                        font-size: 10px;
                        font-weight: bold;
                    ">${stop.stop_order}</div>`,
                    iconSize: [20, 20],
                    iconAnchor: [10, 10]
                });

                L.marker([stop.latitude, stop.longitude], {icon: stopIcon})
                 .addTo(map)
                 .bindPopup(`
                    <strong>${stop.stop_name}</strong><br>
                    ${stop.landmark ? `Landmark: ${stop.landmark}<br>` : ''}
                    Order: ${stop.stop_order}<br>
                    Est. Time: ${stop.estimated_time_from_start} mins
                 `);
            });

            // Add route line
            const routePoints = stopsToRender.map(stop => [stop.latitude, stop.longitude]);
            L.polyline(routePoints, {
                color: '#3b82f6',
                weight: 4,
                opacity: 0.7,
                dashArray: '5, 10'
            }).addTo(map);

            // Initialize marker for current position (bus icon)
            const busIcon = L.divIcon({
                className: 'custom-bus-marker',
                html: `<div style="
                    background-color: #dc2626;
                    width: 30px;
                    height: 30px;
                    border-radius: 50% 50% 50% 0;
                    transform: rotate(-45deg);
                    border: 3px solid white;
                    box-shadow: 0 2px 4px rgba(0,0,0,0.3);
                    display: flex;
                    align-items: center;
                    justify-content: center;
                "><i class="fas fa-bus" style="color: white; transform: rotate(45deg); font-size: 12px;"></i></div>`,
                iconSize: [30, 30],
                iconAnchor: [15, 30]
            });

            marker = L.marker([lat, lng], {icon: busIcon})
                .addTo(map)
                .bindPopup('Bus Current Location');

            // Fit map to show all stops
            if (stopsToRender.length > 0) {
                const group = new L.featureGroup(stopsToRender.map(stop => 
                    L.marker([stop.latitude, stop.longitude])
                ));
                map.fitBounds(group.getBounds().pad(0.1));
            }
        }

        // Update map with new location
        function updateMap(lat, lng) {
            if (marker) {
                marker.setLatLng([lat, lng]);
                marker.bindPopup(`Bus Location: ${lat.toFixed(6)}, ${lng.toFixed(6)}`).openPopup();
            }
            map.panTo([lat, lng]);

            // Update location info
            document.getElementById('latitude').textContent = lat.toFixed(6);
            document.getElementById('longitude').textContent = lng.toFixed(6);

            // Update next stop info based on proximity
            updateNextStopInfo(lat, lng);
        }

        // Update next stop information based on current location
        function updateNextStopInfo(lat, lng) {
            const stopsToCheck = currentDirection === 'outbound' ? busStops : [...busStops].reverse();
            let closestStop = null;
            let minDistance = Infinity;

            stopsToCheck.forEach((stop, index) => {
                const distance = calculateDistance(lat, lng, stop.latitude, stop.longitude);
                if (distance < minDistance && distance < 0.5) { // Within 500 meters
                    minDistance = distance;
                    closestStop = {stop, index};
                }
            });

            if (closestStop) {
                currentStopIndex = closestStop.index;
                const nextStop = stopsToCheck[currentStopIndex + 1];
                
                if (nextStop) {
                    document.getElementById('nextStop').textContent = nextStop.stop_name;
                    const eta = Math.max(1, Math.round(minDistance * 10));
                    document.getElementById('eta').textContent = `${eta} minutes`;
                } else {
                    document.getElementById('nextStop').textContent = 'End of Route';
                    document.getElementById('eta').textContent = 'Arrived';
                }

                // Show "Change Direction" button only at terminals
                const isAtTerminal = closestStop.stop.stop_name.includes('Terminal') || 
                                   closestStop.stop.stop_name.includes('Main Stand');
                document.getElementById('changeDirectionBtn').classList.toggle('hidden', !isAtTerminal);
            }

            // Update stops list and table
            renderStopsList();
            updateStopsTable();
        }

        // Calculate distance between two coordinates
        function calculateDistance(lat1, lng1, lat2, lng2) {
            const R = 6371; // Earth's radius in km
            const dLat = deg2rad(lat2 - lat1);
            const dLng = deg2rad(lng2 - lng1);
            const a =
                Math.sin(dLat/2) * Math.sin(dLat/2) +
                Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) *
                Math.sin(dLng/2) * Math.sin(dLng/2);
            const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
            return R * c; // Distance in km
        }

        function deg2rad(deg) {
            return deg * (Math.PI/180);
        }

        // Show status message
        function showStatus(message, isError = false) {
            const statusDiv = document.getElementById('statusMessage');
            statusDiv.className = isError ?
                'bg-red-100 border border-red-400 text-red-700 p-4 rounded-lg mb-6' :
                'bg-green-100 border border-green-400 text-green-700 p-4 rounded-lg mb-6';
            statusDiv.innerHTML = `<p class="flex items-center"><i class="fas ${isError ? 'fa-exclamation-triangle' : 'fa-check-circle'} mr-2"></i> ${message}</p>`;
            statusDiv.classList.remove('hidden');

            // Auto-hide after 5 seconds
            setTimeout(() => {
                statusDiv.classList.add('hidden');
            }, 5000);
        }

        // Send location to server
        function sendLocationToServer(lat, lng, speed = null, accuracy = null) {
            if (!currentTrip) {
                console.log('No active trip - location not saved');
                return;
            }

            const data = {
                trip_id: currentTrip.trip_id,
                latitude: lat,
                longitude: lng,
                speed: speed,
                accuracy: accuracy
            };

            fetch('../api/update_location.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
                },
                body: JSON.stringify(data)
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Add to recent locations display
                    addRecentLocation(lat, lng, speed);
                } else {
                    console.error('Failed to update location:', data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
            });
        }

        // Add recent location to display
        function addRecentLocation(lat, lng, speed) {
            const recentLocations = document.getElementById('recentLocations');
            const now = new Date();
            const timeString = now.toLocaleTimeString();
            
            const locationElement = document.createElement('div');
            locationElement.className = 'location-update';
            locationElement.innerHTML = `
                <strong>${lat.toFixed(6)}, ${lng.toFixed(6)}</strong><br>
                Speed: ${speed ? (speed * 3.6).toFixed(1) + ' km/h' : 'N/A'} | ${timeString}
            `;
            
            recentLocations.insertBefore(locationElement, recentLocations.firstChild);
            
            // Keep only last 5 locations
            if (recentLocations.children.length > 5) {
                recentLocations.removeChild(recentLocations.lastChild);
            }
        }

        // Start GPS tracking
        function startTracking() {
            if (navigator.geolocation) {
                watchId = navigator.geolocation.watchPosition(
                    position => {
                        const lat = position.coords.latitude;
                        const lng = position.coords.longitude;
                        const speed = position.coords.speed;
                        const accuracy = position.coords.accuracy;
                        
                        updateMap(lat, lng);
                        sendLocationToServer(lat, lng, speed, accuracy);
                    },
                    error => {
                        console.error('Geolocation error:', error);
                        showStatus('Error getting location: ' + error.message, true);
                    },
                    {
                        enableHighAccuracy: true,
                        timeout: 10000,
                        maximumAge: 0
                    }
                );
                isTracking = true;
                showStatus('GPS tracking started');
            } else {
                showStatus('Geolocation is not supported by this browser', true);
            }
        }

        // Stop GPS tracking
        function stopTracking() {
            if (watchId !== null) {
                navigator.geolocation.clearWatch(watchId);
                isTracking = false;
                showStatus('GPS tracking stopped');
            }
        }

        // Start a new trip
        function startTrip() {
            showStatus('Starting trip...');
            
            fetch('../api/start_trip.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: JSON.stringify({ 
                    driver_id: <?php echo $driver_id; ?>,
                    assignment_id: <?php echo $assignment ? $assignment['assignment_id'] : 0; ?>
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    currentTrip = { trip_id: data.trip_id, status: 'in_progress' };

                    // Toggle buttons
                    document.getElementById('startTripBtn').classList.add('hidden');
                    document.getElementById('endTripBtn').classList.remove('hidden');
                    document.getElementById('forceStopTripBtn').classList.add('hidden');

                    // Update trip status
                    document.getElementById('tripStatus').textContent = 'In Progress';
                    document.getElementById('tripStatus').className = 'bg-green-100 text-green-800 text-xs font-medium px-2.5 py-0.5 rounded-full';

                    // Start GPS tracking
                    startTracking();
                    showStatus('Trip started successfully. Tracking is now active.');
                } else {
                    if (data.message.includes('already an active trip')) {
                        document.getElementById('forceStopTripBtn').classList.remove('hidden');
                        showStatus('There is already an active trip. Use "Force Stop Trip" to end it first.', true);
                    } else {
                        showStatus('Failed to start trip: ' + data.message, true);
                    }
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showStatus('Error starting trip', true);
            });
        }

        // Force stop any active trip
        function forceStopTrip() {
            showStatus('Force stopping active trip...');
            
            fetch('../api/force_stop_trip.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    document.getElementById('forceStopTripBtn').classList.add('hidden');
                    showStatus('Active trip force stopped. You can now start a new trip.');

                    document.getElementById('tripStatus').textContent = 'Not Started';
                    document.getElementById('tripStatus').className = 'bg-yellow-100 text-yellow-800 text-xs font-medium px-2.5 py-0.5 rounded-full';
                } else {
                    showStatus('Failed to force stop trip: ' + data.message, true);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showStatus('Error force stopping trip', true);
            });
        }

        // End current trip
        function endTrip() {
            showStatus('Ending trip...');
            
            fetch('../api/end_trip.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: JSON.stringify({ 
                    trip_id: currentTrip.trip_id
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    currentTrip = null;

                    // Toggle buttons
                    document.getElementById('startTripBtn').classList.remove('hidden');
                    document.getElementById('endTripBtn').classList.add('hidden');
                    document.getElementById('changeDirectionBtn').classList.add('hidden');

                    // Update trip status
                    document.getElementById('tripStatus').textContent = 'Completed';
                    document.getElementById('tripStatus').className = 'bg-gray-100 text-gray-800 text-xs font-medium px-2.5 py-0.5 rounded-full';

                    // Stop GPS tracking
                    stopTracking();
                    showStatus('Trip ended successfully. Tracking stopped.');
                } else {
                    showStatus('Failed to end trip: ' + data.message, true);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showStatus('Error ending trip', true);
            });
        }

        // Change trip direction
        function changeDirection() {
            currentDirection = currentDirection === 'outbound' ? 'return' : 'outbound';

            // Update UI
            document.getElementById('routeInfo').textContent =
                currentDirection === 'outbound'
                    ? '<?php echo $assignment ? $assignment['start_location'] . ' to ' . $assignment['end_location'] : ''; ?>'
                    : '<?php echo $assignment ? $assignment['end_location'] . ' to ' . $assignment['start_location'] : ''; ?>';

            // Reset trip state
            currentStopIndex = currentDirection === 'outbound' ? 0 : busStops.length - 1;
            renderStopsList();
            updateStopsTable();

            // Reinitialize map with new direction
            initMap();

            showStatus(`Direction changed to ${currentDirection}.`);

            // Send direction change to server
            fetch('../api/change_direction.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: JSON.stringify({ 
                    trip_id: currentTrip.trip_id,
                    direction: currentDirection 
                })
            })
            .then(response => response.json())
            .then(data => {
                if (!data.success) {
                    showStatus('Failed to change direction: ' + data.message, true);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showStatus('Error changing direction', true);
            });
        }

        // Update location manually
        function updateLocation() {
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(
                    position => {
                        const lat = position.coords.latitude;
                        const lng = position.coords.longitude;
                        const speed = position.coords.speed;
                        const accuracy = position.coords.accuracy;
                        
                        updateMap(lat, lng);
                        sendLocationToServer(lat, lng, speed, accuracy);
                        showStatus('Location updated manually');
                    },
                    error => {
                        console.error('Geolocation error:', error);
                        showStatus('Error getting location: ' + error.message, true);
                    }
                );
            }
        }

        // Render the list of bus stops
        function renderStopsList() {
            const stopsList = document.getElementById('stopsList');
            stopsList.innerHTML = '';
            const stopsToRender = currentDirection === 'outbound' ? busStops : [...busStops].reverse();

            stopsToRender.forEach((stop, index) => {
                const stopElement = document.createElement('div');
                stopElement.className = 'p-3 border-b border-gray-200';
                
                if (index < currentStopIndex) {
                    stopElement.classList.add('passed-stop');
                } else if (index === currentStopIndex) {
                    stopElement.classList.add('current-stop');
                } else if (index === currentStopIndex + 1) {
                    stopElement.classList.add('next-stop');
                }
                
                stopElement.innerHTML = `
                    <div class="flex justify-between items-center">
                        <div>
                            <p class="font-medium">${stop.stop_name}</p>
                            <p class="text-sm text-gray-600">${stop.landmark}</p>
                        </div>
                        <div class="text-right">
                            <span class="text-xs bg-gray-100 text-gray-800 px-2 py-1 rounded">${stop.stop_order}</span>
                            ${index === currentStopIndex ?
                                '<span class="ml-2 text-xs bg-green-100 text-green-800 px-2 py-1 rounded">Current</span>' : ''}
                            ${index === currentStopIndex + 1 ?
                                '<span class="ml-2 text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded">Next</span>' : ''}
                        </div>
                    </div>
                `;
                stopsList.appendChild(stopElement);
            });
        }

        // Update stops table
        function updateStopsTable() {
            const tbody = document.getElementById('stopsTableBody');
            const stopsToRender = currentDirection === 'outbound' ? busStops : [...busStops].reverse();
            
            tbody.innerHTML = '';
            
            stopsToRender.forEach((stop, index) => {
                let status = 'Pending';
                let statusClass = 'bg-gray-100 text-gray-800';
                
                if (index < currentStopIndex) {
                    status = 'Passed';
                    statusClass = 'bg-green-100 text-green-800';
                } else if (index === currentStopIndex) {
                    status = 'Current';
                    statusClass = 'bg-blue-100 text-blue-800';
                } else if (index === currentStopIndex + 1) {
                    status = 'Next';
                    statusClass = 'bg-yellow-100 text-yellow-800';
                }
                
                const row = document.createElement('tr');
                row.className = 'bg-white border-b hover:bg-gray-50';
                row.innerHTML = `
                    <td class="px-4 py-2 font-medium text-gray-900">${stop.stop_name}</td>
                    <td class="px-4 py-2">${stop.stop_order}</td>
                    <td class="px-4 py-2">${stop.landmark || '-'}</td>
                    <td class="px-4 py-2">${stop.estimated_time_from_start} min</td>
                    <td class="px-4 py-2">
                        <span class="text-xs font-medium px-2 py-0.5 rounded ${statusClass}">${status}</span>
                    </td>
                `;
                tbody.appendChild(row);
            });
        }

        // Toggle sidebar on mobile
        function toggleSidebar() {
            document.querySelector('.sidebar').classList.toggle('active');
        }

        // Initialize the app
        document.addEventListener('DOMContentLoaded', function() {
            // Initialize map
            if (busStops.length > 0) {
                initMap(busStops[0].latitude, busStops[0].longitude);
            } else {
                initMap();
            }

            // Event listeners
            document.getElementById('startTripBtn').addEventListener('click', startTrip);
            document.getElementById('endTripBtn').addEventListener('click', endTrip);
            document.getElementById('forceStopTripBtn').addEventListener('click', forceStopTrip);
            document.getElementById('updateLocationBtn').addEventListener('click', updateLocation);
            document.getElementById('changeDirectionBtn').addEventListener('click', changeDirection);

            // Render stops list and table
            renderStopsList();
            updateStopsTable();

            // Start tracking if there's an active trip
            <?php if ($active_trip): ?>
            startTracking();
            <?php else: ?>
            // Simulate initial location update
            setTimeout(() => {
                updateLocation();
            }, 1000);
            <?php endif; ?>

            // Auto-update location every 10 seconds when trip is active
            setInterval(() => {
                if (currentTrip && isTracking) {
                    updateLocation();
                }
            }, 10000);
        });

        // Handle page visibility changes
        document.addEventListener('visibilitychange', function() {
            if (document.hidden) {
                console.log('Page hidden - consider reducing update frequency');
            }
        });

        // Handle beforeunload - stop tracking when leaving page
        window.addEventListener('beforeunload', function() {
            if (isTracking) {
                // Send one final location update
                navigator.geolocation.getCurrentPosition(position => {
                    const lat = position.coords.latitude;
                    const lng = position.coords.longitude;
                    const speed = position.coords.speed;
                    const accuracy = position.coords.accuracy;
                    sendLocationToServer(lat, lng, speed, accuracy);
                });
            }
        });
    </script>
</body>
</html>
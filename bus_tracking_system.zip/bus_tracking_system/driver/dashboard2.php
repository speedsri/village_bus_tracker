<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Start session at the very beginning
session_start();

require_once '../includes/config.php';
require_once '../includes/auth.php';

if (!is_driver_logged_in()) {
    header('Location: index.php');
    exit;
}

$driver_id = $_SESSION['driver_id'];
$driver_name = $_SESSION['driver_name'];
$session_token = $_SESSION['session_token'];

// Verify session
$session = verify_session($pdo, $driver_id, $session_token);
if (!$session) {
    session_destroy();
    header('Location: index.php?session=expired');
    exit;
}

// Get driver's current assignment
$stmt = $pdo->prepare("
    SELECT da.*, b.bus_id, b.bus_number, b.registration_number, b.model, b.capacity,
           r.route_id, r.route_name, r.route_code, r.start_location, r.end_location,
           r.total_distance_km, r.estimated_duration_minutes
    FROM driver_assignments da
    JOIN buses b ON da.bus_id = b.bus_id
    JOIN routes r ON da.route_id = r.route_id
    WHERE da.driver_id = ? AND da.assigned_date = CURDATE() AND da.status IN ('scheduled', 'active')
    ORDER BY da.assignment_id DESC LIMIT 1
");
$stmt->execute([$driver_id]);
$assignment = $stmt->fetch();

// Get current active trip
$stmt = $pdo->prepare("
    SELECT t.*, r.route_name, b.bus_number,
           bs_current.stop_name as current_stop_name
    FROM bus_trips t
    JOIN routes r ON t.route_id = r.route_id
    JOIN buses b ON t.bus_id = b.bus_id
    LEFT JOIN bus_stops bs_current ON t.current_stop_id = bs_current.stop_id
    WHERE t.driver_id = ? AND t.trip_status = 'in_progress'
    ORDER BY t.trip_id DESC LIMIT 1
");
$stmt->execute([$driver_id]);
$active_trip = $stmt->fetch();

// Get route stops
$route_id = $assignment ? $assignment['route_id'] : null;
$bus_stops = [];
if ($route_id) {
    $stmt = $pdo->prepare("
        SELECT stop_id, stop_name, stop_order, latitude, longitude, landmark, estimated_time_from_start
        FROM bus_stops 
        WHERE route_id = ? AND is_active = 1 
        ORDER BY stop_order
    ");
    $stmt->execute([$route_id]);
    $bus_stops = $stmt->fetchAll();
}

// Get recent location updates
$recent_locations = [];
if ($active_trip) {
    $stmt = $pdo->prepare("
        SELECT latitude, longitude, speed_kmh, timestamp, accuracy_meters
        FROM bus_locations 
        WHERE trip_id = ? 
        ORDER BY timestamp DESC 
        LIMIT 5
    ");
    $stmt->execute([$active_trip['trip_id']]);
    $recent_locations = $stmt->fetchAll();
}

// Convert bus stops to JSON for JavaScript
$bus_stops_json = json_encode($bus_stops);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BusLK Driver - Live Tracking</title>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" />
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"></script>
    <style>
        :root {
            --primary: #00D9FF;
            --secondary: #7C3AED;
            --accent: #F59E0B;
            --success: #10B981;
            --danger: #EF4444;
            --dark-bg: #0F172A;
            --card-bg: #1E293B;
            --border: #334155;
        }
        
        body {
            background: linear-gradient(135deg, #0F172A 0%, #1E293B 50%, #334155 100%);
            min-height: 100vh;
        }
        
        #map {
            height: 350px;
            width: 100%;
            border-radius: 20px;
            z-index: 1;
            border: 2px solid var(--border);
        }
        
        .neon-border {
            box-shadow: 0 0 20px rgba(0, 217, 255, 0.3),
                        0 0 40px rgba(0, 217, 255, 0.1);
            border: 1px solid rgba(0, 217, 255, 0.3);
        }
        
        .dark-card {
            background: linear-gradient(145deg, #1E293B 0%, #0F172A 100%);
            border: 1px solid var(--border);
            border-radius: 20px;
            transition: all 0.3s ease;
        }
        
        .dark-card:hover {
            border-color: var(--primary);
            box-shadow: 0 10px 30px rgba(0, 217, 255, 0.2);
        }
        
        .glow-text {
            text-shadow: 0 0 10px rgba(0, 217, 255, 0.5);
        }
        
        .btn-primary {
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            box-shadow: 0 0 20px rgba(0, 217, 255, 0.4);
            transition: all 0.3s ease;
        }
        
        .btn-primary:hover:not(:disabled) {
            box-shadow: 0 0 30px rgba(0, 217, 255, 0.6);
            transform: translateY(-2px);
        }
        
        .btn-success {
            background: linear-gradient(135deg, var(--success) 0%, #059669 100%);
            box-shadow: 0 0 20px rgba(16, 185, 129, 0.4);
        }
        
        .btn-success:hover:not(:disabled) {
            box-shadow: 0 0 30px rgba(16, 185, 129, 0.6);
            transform: translateY(-2px);
        }
        
        .btn-danger {
            background: linear-gradient(135deg, var(--danger) 0%, #DC2626 100%);
            box-shadow: 0 0 20px rgba(239, 68, 68, 0.4);
        }
        
        .btn-danger:hover:not(:disabled) {
            box-shadow: 0 0 30px rgba(239, 68, 68, 0.6);
            transform: translateY(-2px);
        }
        
        .btn-warning {
            background: linear-gradient(135deg, var(--accent) 0%, #D97706 100%);
            box-shadow: 0 0 20px rgba(245, 158, 11, 0.4);
        }
        
        .btn-warning:hover:not(:disabled) {
            box-shadow: 0 0 30px rgba(245, 158, 11, 0.6);
            transform: translateY(-2px);
        }
        
        button:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }
        
        .status-dot {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            display: inline-block;
        }
        
        .status-online {
            background: var(--success);
            box-shadow: 0 0 10px var(--success);
            animation: pulse-dot 2s infinite;
        }
        
        @keyframes pulse-dot {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
        }
        
        .spinner {
            border: 3px solid rgba(255, 255, 255, 0.1);
            border-top: 3px solid var(--primary);
            border-radius: 50%;
            width: 24px;
            height: 24px;
            animation: spin 1s linear infinite;
            display: inline-block;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .stop-list {
            max-height: 300px;
            overflow-y: auto;
            scrollbar-width: thin;
            scrollbar-color: var(--primary) var(--card-bg);
        }
        
        .stop-list::-webkit-scrollbar {
            width: 6px;
        }
        
        .stop-list::-webkit-scrollbar-track {
            background: var(--card-bg);
            border-radius: 10px;
        }
        
        .stop-list::-webkit-scrollbar-thumb {
            background: linear-gradient(180deg, var(--primary) 0%, var(--secondary) 100%);
            border-radius: 10px;
        }
        
        .current-stop {
            background: linear-gradient(90deg, rgba(0, 217, 255, 0.15) 0%, rgba(124, 58, 237, 0.15) 100%);
            border-left: 4px solid var(--primary);
        }
        
        .passed-stop {
            opacity: 0.5;
        }
        
        .next-stop {
            background: linear-gradient(90deg, rgba(245, 158, 11, 0.15) 0%, rgba(16, 185, 129, 0.15) 100%);
            border-left: 4px solid var(--accent);
        }
        
        .metric-card {
            background: linear-gradient(135deg, rgba(0, 217, 255, 0.1) 0%, rgba(124, 58, 237, 0.1) 100%);
            border: 1px solid rgba(0, 217, 255, 0.2);
            border-radius: 16px;
            padding: 20px;
        }
        
        .fade-in {
            animation: fadeIn 0.6s ease-in;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .location-update {
            background: rgba(0, 217, 255, 0.1);
            border-left: 4px solid var(--primary);
            padding: 12px;
            margin-bottom: 8px;
            border-radius: 8px;
            font-size: 0.875rem;
        }
        
        .badge {
            font-size: 0.75rem;
            padding: 4px 12px;
            border-radius: 20px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .badge-active {
            background: linear-gradient(135deg, var(--success) 0%, #059669 100%);
            box-shadow: 0 0 15px rgba(16, 185, 129, 0.5);
        }
        
        .badge-inactive {
            background: linear-gradient(135deg, #64748B 0%, #475569 100%);
        }
        
        .hidden {
            display: none !important;
        }
    </style>
</head>
<body class="text-gray-100">
    <div class="min-h-screen">
        <!-- Header -->
        <header class="dark-card p-4 mb-6 neon-border fade-in">
            <div class="flex justify-between items-center">
                <div>
                    <h1 class="text-2xl font-bold glow-text flex items-center">
                        <i class="fas fa-bus mr-2 text-cyan-400"></i> BusLK Driver
                    </h1>
                    <p class="text-sm text-cyan-300 mt-1">Live Tracking System</p>
                </div>
                <div class="flex items-center space-x-3">
                    <div class="flex items-center bg-gray-800 bg-opacity-50 px-3 py-2 rounded-full border border-gray-700">
                        <span class="status-dot status-online mr-2"></span>
                        <span class="text-xs font-semibold">ONLINE</span>
                    </div>
                    <a href="logout.php" class="bg-red-900 bg-opacity-50 hover:bg-opacity-70 text-red-400 px-4 py-2 rounded-xl font-semibold transition-all border border-red-800">
                        <i class="fas fa-sign-out-alt mr-2"></i> Logout
                    </a>
                </div>
            </div>
        </header>

        <div class="container mx-auto px-4 pb-6">
            <!-- Driver Info -->
            <div class="dark-card p-5 mb-6 fade-in">
                <div class="flex items-center">
                    <div class="w-16 h-16 rounded-full bg-gradient-to-br from-cyan-400 to-purple-600 flex items-center justify-center mr-4">
                        <i class="fas fa-user text-white text-2xl"></i>
                    </div>
                    <div>
                        <p class="font-bold text-xl text-white"><?php echo htmlspecialchars($driver_name); ?></p>
                        <p class="text-sm text-cyan-400">Driver ID: DRV-<?php echo str_pad($driver_id, 3, '0', STR_PAD_LEFT); ?></p>
                    </div>
                </div>
            </div>

            <!-- Quick Stats -->
            <div class="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6 fade-in">
                <div class="metric-card">
                    <p class="text-xs text-cyan-400 font-bold mb-2 uppercase">Bus Number</p>
                    <p class="font-bold text-white text-lg" id="busNumber">
                        <?php echo $assignment ? htmlspecialchars($assignment['bus_number']) : 'Not Assigned'; ?>
                    </p>
                </div>
                <div class="metric-card">
                    <p class="text-xs text-green-400 font-bold mb-2 uppercase">Route</p>
                    <p class="font-bold text-white text-lg" id="routeInfo">
                        <?php echo $assignment ? htmlspecialchars($assignment['route_name']) : 'No Route'; ?>
                    </p>
                </div>
                <div class="metric-card">
                    <p class="text-xs text-purple-400 font-bold mb-2 uppercase">Passengers</p>
                    <p class="font-bold text-white text-lg" id="passengerCount">
                        <?php echo $assignment ? '0/' . $assignment['capacity'] : '0/0'; ?>
                    </p>
                </div>
                <div class="metric-card">
                    <p class="text-xs text-orange-400 font-bold mb-2 uppercase">Trip Status</p>
                    <p class="font-bold text-white text-sm">
                        <span class="badge <?php echo $active_trip ? 'badge-active' : 'badge-inactive'; ?>" id="tripStatus">
                            <?php echo $active_trip ? 'ACTIVE' : 'NOT STARTED'; ?>
                        </span>
                    </p>
                </div>
            </div>

            <!-- Trip Controls - PRIMARY SECTION -->
            <div class="dark-card p-6 mb-6 neon-border fade-in">
                <h3 class="text-xl font-bold text-cyan-400 mb-4 flex items-center">
                    <i class="fas fa-play-circle mr-2"></i> Trip Controls
                </h3>
                
                <div class="space-y-4">
                    <!-- Start Trip Button -->
                    <button id="startTripBtn" class="w-full btn-success text-white py-4 rounded-xl flex items-center justify-center font-bold text-lg transition-all duration-300 transform <?php echo $active_trip ? 'hidden' : ''; ?>">
                        <i class="fas fa-play mr-3"></i> START TRIP
                    </button>

                    <!-- End Trip Button -->
                    <button id="endTripBtn" class="w-full btn-danger text-white py-4 rounded-xl flex items-center justify-center font-bold text-lg transition-all duration-300 transform <?php echo $active_trip ? '' : 'hidden'; ?>">
                        <i class="fas fa-stop mr-3"></i> END TRIP
                    </button>

                    <!-- Force Stop Button -->
                    <button id="forceStopTripBtn" class="w-full btn-warning text-white py-3 rounded-xl flex items-center justify-center font-semibold transition-all duration-300 hidden">
                        <i class="fas fa-exclamation-triangle mr-2"></i> Force Stop Active Trip
                    </button>

                    <!-- Update Location Button -->
                    <button id="updateLocationBtn" class="w-full btn-primary text-white py-3 rounded-xl flex items-center justify-center font-semibold transition-all duration-300">
                        <i class="fas fa-location-arrow mr-2"></i> Update Location
                    </button>
                </div>

                <!-- Next Stop Info -->
                <div class="mt-6 pt-4 border-t border-gray-700">
                    <h4 class="text-sm text-gray-400 font-semibold mb-3 uppercase">Next Stop</h4>
                    <div class="flex items-center bg-gray-800 bg-opacity-50 p-4 rounded-xl">
                        <div class="w-12 h-12 rounded-full bg-gradient-to-br from-cyan-400 to-blue-500 flex items-center justify-center mr-3">
                            <i class="fas fa-map-marker-alt text-white text-lg"></i>
                        </div>
                        <div>
                            <p class="font-bold text-white" id="nextStop">-</p>
                            <p class="text-sm text-cyan-400">ETA: <span id="eta">-</span></p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Map Section -->
            <div class="dark-card p-6 mb-6 fade-in">
                <div class="flex justify-between items-center mb-4">
                    <h3 class="text-xl font-bold text-cyan-400 flex items-center">
                        <i class="fas fa-map mr-2"></i> Live Map
                    </h3>
                    <div class="flex items-center text-sm bg-green-900 bg-opacity-30 px-3 py-2 rounded-full border border-green-500">
                        <span class="flex h-3 w-3 relative mr-2">
                            <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                            <span class="relative inline-flex rounded-full h-3 w-3 bg-green-400"></span>
                        </span>
                        <span class="font-semibold text-green-300">GPS Active</span>
                    </div>
                </div>
                
                <div id="map" class="mb-4"></div>

                <div class="grid grid-cols-2 gap-3">
                    <div class="bg-gray-800 bg-opacity-50 p-3 rounded-xl">
                        <p class="text-xs text-gray-400 mb-1">Latitude</p>
                        <p class="font-mono text-cyan-400 text-sm" id="latitude">0.000000</p>
                    </div>
                    <div class="bg-gray-800 bg-opacity-50 p-3 rounded-xl">
                        <p class="text-xs text-gray-400 mb-1">Longitude</p>
                        <p class="font-mono text-cyan-400 text-sm" id="longitude">0.000000</p>
                    </div>
                </div>
            </div>

            <!-- Two Column Layout -->
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
                <!-- Recent Locations -->
                <div class="dark-card p-6 fade-in">
                    <h3 class="text-lg font-bold text-cyan-400 mb-4 flex items-center">
                        <i class="fas fa-history mr-2"></i> Recent Updates
                    </h3>
                    <div id="recentLocations" class="space-y-2">
                        <?php if (!empty($recent_locations)): ?>
                            <?php foreach ($recent_locations as $location): ?>
                                <div class="location-update">
                                    <strong class="text-cyan-400"><?php echo $location['latitude']; ?>, <?php echo $location['longitude']; ?></strong><br>
                                    <span class="text-gray-400">Speed: <?php echo $location['speed_kmh'] ? $location['speed_kmh'] . ' km/h' : 'N/A'; ?> | 
                                    <?php echo date('H:i:s', strtotime($location['timestamp'])); ?></span>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <p class="text-gray-500 text-center py-6 text-sm">No updates yet</p>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Bus Stops -->
                <div class="dark-card p-6 fade-in">
                    <h3 class="text-lg font-bold text-cyan-400 mb-4 flex items-center">
                        <i class="fas fa-list-ul mr-2"></i> Route Stops
                    </h3>
                    <div class="stop-list" id="stopsList">
                        <p class="text-gray-500 text-center py-6 text-sm">Loading stops...</p>
                    </div>
                </div>
            </div>

            <!-- Status Message -->
            <div id="statusMessage" class="hidden"></div>
        </div>
    </div>

    <script>
        // PHP data injection
        const busStops = <?php echo $bus_stops_json ?: '[]'; ?>;
        const driverId = <?php echo $driver_id; ?>;
        const driverName = "<?php echo htmlspecialchars($driver_name); ?>";
        const assignmentData = <?php echo $assignment ? json_encode($assignment) : 'null'; ?>;
        let currentTrip = <?php echo $active_trip ? json_encode($active_trip) : 'null'; ?>;
        
        // Global variables
        let map, marker, watchId;
        let isTracking = false;
        let currentStopIndex = 0;
        let currentDirection = 'outbound';

        // Initialize map
        function initMap(lat = 7.48813300, lng = 80.36424000) {
            map = L.map('map').setView([lat, lng], 14);
            
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '&copy; OpenStreetMap',
                maxZoom: 18
            }).addTo(map);

            // Add bus stops
            busStops.forEach((stop, index) => {
                const stopIcon = L.divIcon({
                    className: 'custom-stop-marker',
                    html: `<div style="
                        background: linear-gradient(135deg, ${index === currentStopIndex ? '#00D9FF' : '#7C3AED'} 0%, ${index === currentStopIndex ? '#7C3AED' : '#1E40AF'} 100%);
                        width: 28px;
                        height: 28px;
                        border-radius: 50%;
                        border: 3px solid #0F172A;
                        box-shadow: 0 0 15px rgba(0, 217, 255, 0.6);
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        color: white;
                        font-size: 11px;
                        font-weight: bold;
                    ">${stop.stop_order}</div>`,
                    iconSize: [28, 28],
                    iconAnchor: [14, 14]
                });

                L.marker([stop.latitude, stop.longitude], {icon: stopIcon})
                 .addTo(map)
                 .bindPopup(`
                    <div class="p-2 bg-gray-900 text-white rounded">
                        <strong class="text-cyan-400">${stop.stop_name}</strong><br>
                        ${stop.landmark ? `${stop.landmark}<br>` : ''}
                        Order: ${stop.stop_order} | ETA: ${stop.estimated_time_from_start} min
                    </div>
                 `);
            });

            // Draw route
            if (busStops.length > 0) {
                const routePoints = busStops.map(stop => [stop.latitude, stop.longitude]);
                L.polyline(routePoints, {
                    color: '#00D9FF',
                    weight: 5,
                    opacity: 0.7,
                    dashArray: '10, 15'
                }).addTo(map);
            }

            // Bus marker
            const busIcon = L.divIcon({
                className: 'custom-bus-marker',
                html: `<div style="
                    background: linear-gradient(135deg, #EF4444 0%, #DC2626 100%);
                    width: 40px;
                    height: 40px;
                    border-radius: 50%;
                    border: 4px solid #0F172A;
                    box-shadow: 0 0 25px rgba(239, 68, 68, 0.8);
                    display: flex;
                    align-items: center;
                    justify-content: center;
                "><i class="fas fa-bus" style="color: white; font-size: 16px;"></i></div>`,
                iconSize: [40, 40],
                iconAnchor: [20, 40]
            });

            marker = L.marker([lat, lng], {icon: busIcon})
                .addTo(map)
                .bindPopup('Bus Location');
        }

        // Update map
        function updateMap(lat, lng) {
            if (marker) {
                marker.setLatLng([lat, lng]);
                marker.bindPopup(`<div class="p-2 bg-gray-900 text-white rounded">
                    <strong class="text-cyan-400">Bus Location</strong><br>
                    ${lat.toFixed(6)}, ${lng.toFixed(6)}
                </div>`).openPopup();
            }
            map.panTo([lat, lng]);

            document.getElementById('latitude').textContent = lat.toFixed(6);
            document.getElementById('longitude').textContent = lng.toFixed(6);

            updateNextStopInfo(lat, lng);
        }

        // Update next stop
        function updateNextStopInfo(lat, lng) {
            let closestStop = null;
            let minDistance = Infinity;

            busStops.forEach((stop, index) => {
                const distance = calculateDistance(lat, lng, stop.latitude, stop.longitude);
                if (distance < minDistance && distance < 0.5) {
                    minDistance = distance;
                    closestStop = {stop, index};
                }
            });

            if (closestStop) {
                currentStopIndex = closestStop.index;
                const nextStop = busStops[currentStopIndex + 1];
                
                if (nextStop) {
                    document.getElementById('nextStop').textContent = nextStop.stop_name;
                    const eta = Math.max(1, Math.round(minDistance * 10));
                    document.getElementById('eta').textContent = `${eta} minutes`;
                } else {
                    document.getElementById('nextStop').textContent = 'End of Route';
                    document.getElementById('eta').textContent = 'Arrived';
                }
            }

            renderStopsList();
        }

        // Calculate distance
        function calculateDistance(lat1, lng1, lat2, lng2) {
            const R = 6371;
            const dLat = (lat2 - lat1) * Math.PI / 180;
            const dLng = (lng2 - lng1) * Math.PI / 180;
            const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
                Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
                Math.sin(dLng/2) * Math.sin(dLng/2);
            const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
            return R * c;
        }

        // Show status
        function showStatus(message, type = 'info') {
            const statusDiv = document.getElementById('statusMessage');
            const colors = {
                error: 'bg-red-900 bg-opacity-90 text-white border-red-500',
                success: 'bg-green-900 bg-opacity-90 text-white border-green-500',
                info: 'bg-cyan-900 bg-opacity-90 text-white border-cyan-500'
            };
            
            statusDiv.className = `p-4 rounded-xl mb-6 border-2 ${colors[type]} fade-in`;
            statusDiv.innerHTML = `<p class="flex items-center font-semibold">
                <i class="fas ${type === 'error' ? 'fa-exclamation-triangle' : type === 'success' ? 'fa-check-circle' : 'fa-info-circle'} mr-3 text-xl"></i>
                ${message}
            </p>`;
            statusDiv.classList.remove('hidden');

            setTimeout(() => {
                statusDiv.classList.add('hidden');
            }, 5000);
        }

        // Send location to server
        function sendLocationToServer(lat, lng, speed = null, accuracy = null) {
            if (!currentTrip) {
                console.log('No active trip');
                return;
            }

            fetch('../api/update_location.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: JSON.stringify({
                    trip_id: currentTrip.trip_id,
                    latitude: lat,
                    longitude: lng,
                    speed: speed,
                    accuracy: accuracy
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    addRecentLocation(lat, lng, speed);
                } else {
                    console.error('Failed to update location:', data.message);
                }
            })
            .catch(error => console.error('Error:', error));
        }

        // Add recent location
        function addRecentLocation(lat, lng, speed) {
            const container = document.getElementById('recentLocations');
            const timeString = new Date().toLocaleTimeString();
            
            const locationEl = document.createElement('div');
            locationEl.className = 'location-update';
            locationEl.innerHTML = `
                <strong class="text-cyan-400">${lat.toFixed(6)}, ${lng.toFixed(6)}</strong><br>
                <span class="text-gray-400">Speed: ${speed ? (speed * 3.6).toFixed(1) + ' km/h' : 'N/A'} | ${timeString}</span>
            `;
            
            if (container.firstChild && container.firstChild.tagName === 'P') {
                container.innerHTML = '';
            }
            
            container.insertBefore(locationEl, container.firstChild);
            
            if (container.children.length > 5) {
                container.removeChild(container.lastChild);
            }
        }

        // Start tracking
        function startTracking() {
            if (navigator.geolocation) {
                watchId = navigator.geolocation.watchPosition(
                    position => {
                        const lat = position.coords.latitude;
                        const lng = position.coords.longitude;
                        const speed = position.coords.speed;
                        const accuracy = position.coords.accuracy;
                        
                        updateMap(lat, lng);
                        sendLocationToServer(lat, lng, speed, accuracy);
                    },
                    error => {
                        console.error('Geolocation error:', error);
                        showStatus('Error getting location: ' + error.message, 'error');
                    },
                    {
                        enableHighAccuracy: true,
                        timeout: 10000,
                        maximumAge: 0
                    }
                );
                isTracking = true;
                showStatus('GPS tracking started', 'success');
            } else {
                showStatus('Geolocation not supported', 'error');
            }
        }

        // Stop tracking
        function stopTracking() {
            if (watchId !== null) {
                navigator.geolocation.clearWatch(watchId);
                isTracking = false;
                showStatus('GPS tracking stopped', 'info');
            }
        }

        // Start trip
        function startTrip() {
            if (!assignmentData) {
                showStatus('No assignment found for today', 'error');
                return;
            }

            const startBtn = document.getElementById('startTripBtn');
            startBtn.disabled = true;
            startBtn.innerHTML = '<span class="spinner mr-2"></span> Starting...';
            
            showStatus('Starting trip...', 'info');
            
            fetch('../api/start_trip.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: JSON.stringify({ 
                    driver_id: driverId,
                    assignment_id: assignmentData.assignment_id
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    currentTrip = { trip_id: data.trip_id, status: 'in_progress' };

                    document.getElementById('startTripBtn').classList.add('hidden');
                    document.getElementById('endTripBtn').classList.remove('hidden');
                    document.getElementById('forceStopTripBtn').classList.add('hidden');

                    const statusBadge = document.getElementById('tripStatus');
                    statusBadge.textContent = 'ACTIVE';
                    statusBadge.className = 'badge badge-active';

                    startTracking();
                    showStatus('Trip started successfully!', 'success');
                } else {
                    if (data.message.includes('already an active trip')) {
                        document.getElementById('forceStopTripBtn').classList.remove('hidden');
                        showStatus('Active trip exists. Use Force Stop first.', 'error');
                    } else {
                        showStatus('Failed to start trip: ' + data.message, 'error');
                    }
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showStatus('Error starting trip', 'error');
            })
            .finally(() => {
                startBtn.disabled = false;
                startBtn.innerHTML = '<i class="fas fa-play mr-3"></i> START TRIP';
            });
        }

        // Force stop trip
        function forceStopTrip() {
            const forceBtn = document.getElementById('forceStopTripBtn');
            forceBtn.disabled = true;
            forceBtn.innerHTML = '<span class="spinner mr-2"></span> Stopping...';
            
            showStatus('Force stopping trip...', 'info');
            
            fetch('../api/force_stop_trip.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    document.getElementById('forceStopTripBtn').classList.add('hidden');
                    showStatus('Active trip stopped. You can start a new trip.', 'success');

                    const statusBadge = document.getElementById('tripStatus');
                    statusBadge.textContent = 'NOT STARTED';
                    statusBadge.className = 'badge badge-inactive';
                } else {
                    showStatus('Failed to force stop: ' + data.message, 'error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showStatus('Error force stopping trip', 'error');
            })
            .finally(() => {
                forceBtn.disabled = false;
                forceBtn.innerHTML = '<i class="fas fa-exclamation-triangle mr-2"></i> Force Stop Active Trip';
            });
        }

        // End trip
        function endTrip() {
            if (!currentTrip) {
                showStatus('No active trip to end', 'error');
                return;
            }

            const endBtn = document.getElementById('endTripBtn');
            endBtn.disabled = true;
            endBtn.innerHTML = '<span class="spinner mr-2"></span> Ending...';
            
            showStatus('Ending trip...', 'info');
            
            fetch('../api/end_trip.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: JSON.stringify({ 
                    trip_id: currentTrip.trip_id
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    currentTrip = null;

                    document.getElementById('startTripBtn').classList.remove('hidden');
                    document.getElementById('endTripBtn').classList.add('hidden');

                    const statusBadge = document.getElementById('tripStatus');
                    statusBadge.textContent = 'COMPLETED';
                    statusBadge.className = 'badge badge-inactive';

                    stopTracking();
                    showStatus('Trip ended successfully!', 'success');
                } else {
                    showStatus('Failed to end trip: ' + data.message, 'error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showStatus('Error ending trip', 'error');
            })
            .finally(() => {
                endBtn.disabled = false;
                endBtn.innerHTML = '<i class="fas fa-stop mr-3"></i> END TRIP';
            });
        }

        // Update location manually
        function updateLocation() {
            const updateBtn = document.getElementById('updateLocationBtn');
            updateBtn.disabled = true;
            updateBtn.innerHTML = '<span class="spinner mr-2"></span> Updating...';

            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(
                    position => {
                        const lat = position.coords.latitude;
                        const lng = position.coords.longitude;
                        const speed = position.coords.speed;
                        const accuracy = position.coords.accuracy;
                        
                        updateMap(lat, lng);
                        sendLocationToServer(lat, lng, speed, accuracy);
                        showStatus('Location updated', 'success');
                        
                        updateBtn.disabled = false;
                        updateBtn.innerHTML = '<i class="fas fa-location-arrow mr-2"></i> Update Location';
                    },
                    error => {
                        console.error('Geolocation error:', error);
                        showStatus('Error getting location: ' + error.message, 'error');
                        
                        updateBtn.disabled = false;
                        updateBtn.innerHTML = '<i class="fas fa-location-arrow mr-2"></i> Update Location';
                    },
                    {
                        enableHighAccuracy: true,
                        timeout: 10000,
                        maximumAge: 0
                    }
                );
            } else {
                showStatus('Geolocation not supported', 'error');
                updateBtn.disabled = false;
                updateBtn.innerHTML = '<i class="fas fa-location-arrow mr-2"></i> Update Location';
            }
        }

        // Render stops list
        function renderStopsList() {
            const stopsList = document.getElementById('stopsList');
            
            if (busStops.length === 0) {
                stopsList.innerHTML = '<p class="text-gray-500 text-center py-6 text-sm">No stops available</p>';
                return;
            }

            stopsList.innerHTML = '';

            busStops.forEach((stop, index) => {
                const stopEl = document.createElement('div');
                stopEl.className = 'p-3 border-b border-gray-700 transition-all duration-300';
                
                if (index < currentStopIndex) {
                    stopEl.classList.add('passed-stop');
                } else if (index === currentStopIndex) {
                    stopEl.classList.add('current-stop');
                } else if (index === currentStopIndex + 1) {
                    stopEl.classList.add('next-stop');
                }
                
                stopEl.innerHTML = `
                    <div class="flex justify-between items-start">
                        <div class="flex items-center">
                            <div class="w-10 h-10 rounded-full flex items-center justify-center mr-3 text-white font-bold text-sm shadow-lg
                                ${index === currentStopIndex ? 'bg-gradient-to-br from-cyan-400 to-blue-500' : 
                                  index === currentStopIndex + 1 ? 'bg-gradient-to-br from-yellow-400 to-orange-500' : 
                                  index < currentStopIndex ? 'bg-gradient-to-br from-gray-500 to-gray-600' : 
                                  'bg-gradient-to-br from-purple-500 to-indigo-600'}">
                                ${stop.stop_order}
                            </div>
                            <div>
                                <p class="font-semibold ${index < currentStopIndex ? 'text-gray-500' : 'text-white'} text-sm">
                                    ${stop.stop_name}
                                </p>
                                <p class="text-xs ${index < currentStopIndex ? 'text-gray-600' : 'text-gray-400'}">
                                    ${stop.landmark || 'No landmark'}
                                </p>
                            </div>
                        </div>
                        <div class="text-right">
                            ${index === currentStopIndex ?
                                '<span class="text-xs bg-cyan-500 bg-opacity-20 text-cyan-400 px-2 py-1 rounded-full font-bold border border-cyan-500">NOW</span>' : ''}
                            ${index === currentStopIndex + 1 ?
                                '<span class="text-xs bg-yellow-500 bg-opacity-20 text-yellow-400 px-2 py-1 rounded-full font-bold border border-yellow-500">NEXT</span>' : ''}
                            ${index < currentStopIndex ?
                                '<span class="text-xs bg-gray-500 bg-opacity-20 text-gray-500 px-2 py-1 rounded-full font-bold border border-gray-600">DONE</span>' : ''}
                        </div>
                    </div>
                `;
                stopsList.appendChild(stopEl);
            });
        }

        // Initialize
        document.addEventListener('DOMContentLoaded', function() {
            // Initialize map
            if (busStops.length > 0) {
                initMap(busStops[0].latitude, busStops[0].longitude);
            } else {
                initMap();
            }

            // Event listeners
            document.getElementById('startTripBtn').addEventListener('click', startTrip);
            document.getElementById('endTripBtn').addEventListener('click', endTrip);
            document.getElementById('forceStopTripBtn').addEventListener('click', forceStopTrip);
            document.getElementById('updateLocationBtn').addEventListener('click', updateLocation);

            // Render stops list
            renderStopsList();

            // If there's an active trip, start tracking
            if (currentTrip && currentTrip.trip_status === 'in_progress') {
                startTracking();
            } else {
                // Initial location update
                setTimeout(() => {
                    updateLocation();
                }, 1000);
            }

            // Auto-update location every 10 seconds when trip is active
            setInterval(() => {
                if (currentTrip && isTracking) {
                    // Let watchPosition handle it, but we can force an update here if needed
                    console.log('Auto-update interval - tracking active');
                }
            }, 10000);
        });

        // Handle page visibility changes
        document.addEventListener('visibilitychange', function() {
            if (document.hidden) {
                console.log('Page hidden - maintaining tracking');
            } else {
                console.log('Page visible - tracking active');
                if (currentTrip && isTracking) {
                    updateLocation();
                }
            }
        });

        // Handle page unload
        window.addEventListener('beforeunload', function() {
            if (isTracking && currentTrip) {
                // Send final location update
                navigator.geolocation.getCurrentPosition(position => {
                    const lat = position.coords.latitude;
                    const lng = position.coords.longitude;
                    const speed = position.coords.speed;
                    const accuracy = position.coords.accuracy;
                    sendLocationToServer(lat, lng, speed, accuracy);
                });
            }
        });
    </script>
</body>
</html>
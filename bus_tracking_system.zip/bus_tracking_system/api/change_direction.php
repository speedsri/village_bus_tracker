<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $trip_id = intval($input['trip_id']);
    $direction = sanitize_input($input['direction']);
    
    try {
        $stmt = $pdo->prepare("
            UPDATE bus_trips 
            SET trip_direction = ? 
            WHERE trip_id = ? AND trip_status = 'in_progress'
        ");
        
        if ($stmt->execute([$direction, $trip_id])) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to change direction']);
        }
    } catch (PDOException $e) {
        error_log("Change direction error: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}
?>
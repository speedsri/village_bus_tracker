<?php
require_once '../includes/config.php';

header('Content-Type: application/json');

$stmt = $pdo->query("
    SELECT route_id, route_name, route_code, start_location, end_location
    FROM routes 
    WHERE is_active = 1
    ORDER BY route_name
");

$routes = $stmt->fetchAll();
echo json_encode($routes);
?>
<?php
require_once '../includes/config.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    $trip_id = intval($input['trip_id']);
    
    $stmt = $pdo->prepare("
        UPDATE bus_trips 
        SET trip_status = 'completed', actual_end_time = NOW() 
        WHERE trip_id = ? AND trip_status = 'in_progress'
    ");
    
    if ($stmt->execute([$trip_id])) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Failed to end trip']);
    }
}
?>
<?php
require_once '../includes/config.php';
require_once '../includes/functions.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    
    $trip_id = intval($input['trip_id']);
    $latitude = floatval($input['latitude']);
    $longitude = floatval($input['longitude']);
    $speed = isset($input['speed']) ? floatval($input['speed']) : null;
    $accuracy = isset($input['accuracy']) ? intval($input['accuracy']) : null;
    
    try {
        // Get trip and route info
        $stmt = $pdo->prepare("
            SELECT t.*, r.route_id, b.bus_id
            FROM bus_trips t 
            JOIN routes r ON t.route_id = r.route_id 
            JOIN buses b ON t.bus_id = b.bus_id
            WHERE t.trip_id = ? AND t.trip_status = 'in_progress'
        ");
        $stmt->execute([$trip_id]);
        $trip = $stmt->fetch();
        
        if (!$trip) {
            echo json_encode(['success' => false, 'message' => 'Invalid or inactive trip']);
            exit;
        }
        
        // Find nearest stop
        $stmt = $pdo->prepare("
            SELECT stop_id, stop_name, stop_order, latitude, longitude,
                   (6371 * acos(cos(radians(?)) * cos(radians(latitude)) * 
                    cos(radians(longitude) - radians(?)) + sin(radians(?)) * 
                    sin(radians(latitude)))) AS distance
            FROM bus_stops 
            WHERE route_id = ? 
            HAVING distance < 0.1 -- Within 100 meters
            ORDER BY distance 
            LIMIT 1
        ");
        $stmt->execute([$latitude, $longitude, $latitude, $trip['route_id']]);
        $current_stop = $stmt->fetch();
        
        // Find next stop
        $next_stop_id = null;
        if ($current_stop) {
            $stmt = $pdo->prepare("
                SELECT stop_id FROM bus_stops 
                WHERE route_id = ? AND stop_order > ? 
                ORDER BY stop_order 
                LIMIT 1
            ");
            $stmt->execute([$trip['route_id'], $current_stop['stop_order']]);
            $next_stop = $stmt->fetch();
            $next_stop_id = $next_stop ? $next_stop['stop_id'] : null;
            
            // Update trip's current stop if it's different
            if ($trip['current_stop_id'] != $current_stop['stop_id']) {
                $stmt = $pdo->prepare("
                    UPDATE bus_trips 
                    SET current_stop_id = ? 
                    WHERE trip_id = ?
                ");
                $stmt->execute([$current_stop['stop_id'], $trip_id]);
            }
        }
        
        // Convert speed from m/s to km/h if needed
        $speed_kmh = $speed ? ($speed * 3.6) : null;
        
        // Mark all previous locations as not current
        $stmt = $pdo->prepare("
            UPDATE bus_locations 
            SET is_current_location = 0 
            WHERE bus_id = ? AND trip_id = ?
        ");
        $stmt->execute([$trip['bus_id'], $trip_id]);
        
        // Insert new location update
        $stmt = $pdo->prepare("
            INSERT INTO bus_locations (bus_id, trip_id, latitude, longitude, speed_kmh, 
                                     accuracy_meters, current_stop_id, next_stop_id, is_current_location)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)
        ");
        
        $success = $stmt->execute([
            $trip['bus_id'],
            $trip_id,
            $latitude,
            $longitude,
            $speed_kmh,
            $accuracy,
            $current_stop ? $current_stop['stop_id'] : null,
            $next_stop_id
        ]);
        
        // Log location update
        if ($success) {
            $stmt = $pdo->prepare("
                INSERT INTO activity_logs (user_id, action_type, table_affected, record_id, ip_address)
                VALUES (?, 'location_update', 'bus_locations', ?, ?)
            ");
            $stmt->execute([$trip['driver_id'], $pdo->lastInsertId(), get_client_ip()]);
        }
        
        echo json_encode([
            'success' => $success,
            'current_stop' => $current_stop ? $current_stop['stop_name'] : null,
            'next_stop' => $next_stop_id ? 'Next stop updated' : null
        ]);
        
    } catch (PDOException $e) {
        error_log("Location update error: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}
?>
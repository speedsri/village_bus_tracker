<?php
// Database configuration
$host = 'localhost';
$database = 'bus_tracking_system';
$username = 'root';
$password = '3f90d2f8923ba067';
$charset = 'utf8mb4';

// Create PDO connection
try {
    $dsn = "mysql:host=$host;dbname=$database;charset=$charset";
    $pdo = new PDO($dsn, $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Set timezone
date_default_timezone_set('Asia/Colombo');
?>
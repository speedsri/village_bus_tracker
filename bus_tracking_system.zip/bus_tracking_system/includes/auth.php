<?php
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function is_driver_logged_in() {
    return isset($_SESSION['driver_id']) && isset($_SESSION['session_token']);
}

function verify_session($pdo, $user_id, $session_token) {
    try {
        $stmt = $pdo->prepare("
            SELECT us.*, u.user_type, u.full_name 
            FROM user_sessions us 
            JOIN users u ON us.user_id = u.user_id 
            WHERE us.user_id = ? AND us.session_token = ? AND us.is_active = 1
            AND u.is_active = 1
        ");
        $stmt->execute([$user_id, $session_token]);
        $session = $stmt->fetch();
        
        if ($session) {
            // Update last activity (optional: you can update a last_activity field if you have one)
            return $session;
        }
        return false;
    } catch (PDOException $e) {
        error_log("Session verification error: " . $e->getMessage());
        return false;
    }
}

function logout_user($pdo, $user_id, $session_token) {
    try {
        $stmt = $pdo->prepare("
            UPDATE user_sessions 
            SET is_active = 0, logout_time = CURRENT_TIMESTAMP 
            WHERE user_id = ? AND session_token = ?
        ");
        return $stmt->execute([$user_id, $session_token]);
    } catch (PDOException $e) {
        error_log("Logout error: " . $e->getMessage());
        return false;
    }
}

// Check for session timeout (optional security feature)
function check_session_timeout($timeout_minutes = 60) {
    if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > $timeout_minutes * 60)) {
        // Session expired
        session_unset();
        session_destroy();
        return false;
    }
    $_SESSION['last_activity'] = time(); // Update last activity time
    return true;
}
?>
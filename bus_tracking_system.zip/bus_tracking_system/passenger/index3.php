<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BusLK - Real-time Bus Tracker</title>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" />
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"></script>
    <style>
        :root {
            --primary: #00D9FF;
            --secondary: #7C3AED;
            --accent: #F59E0B;
            --success: #10B981;
            --dark-bg: #0F172A;
            --card-bg: #1E293B;
            --border: #334155;
        }
        
        body {
            background: linear-gradient(135deg, #0F172A 0%, #1E293B 50%, #334155 100%);
            min-height: 100vh;
        }
        
        #map {
            height: 500px;
            width: 100%;
            border-radius: 20px;
            z-index: 1;
            border: 2px solid var(--border);
        }
        
        .neon-border {
            box-shadow: 0 0 20px rgba(0, 217, 255, 0.3),
                        0 0 40px rgba(0, 217, 255, 0.1),
                        inset 0 0 20px rgba(0, 217, 255, 0.05);
            border: 1px solid rgba(0, 217, 255, 0.3);
        }
        
        .dark-card {
            background: linear-gradient(145deg, #1E293B 0%, #0F172A 100%);
            border: 1px solid var(--border);
            border-radius: 20px;
            transition: all 0.4s cubic-bezier(0.4, 0, 0.2, 1);
        }
        
        .dark-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 25px 50px rgba(0, 217, 255, 0.2);
            border-color: var(--primary);
        }
        
        .stop-list {
            max-height: 450px;
            overflow-y: auto;
            scrollbar-width: thin;
            scrollbar-color: var(--primary) var(--card-bg);
        }
        
        .stop-list::-webkit-scrollbar {
            width: 8px;
        }
        
        .stop-list::-webkit-scrollbar-track {
            background: var(--card-bg);
            border-radius: 10px;
        }
        
        .stop-list::-webkit-scrollbar-thumb {
            background: linear-gradient(180deg, var(--primary) 0%, var(--secondary) 100%);
            border-radius: 10px;
        }
        
        .current-stop {
            background: linear-gradient(90deg, rgba(0, 217, 255, 0.1) 0%, rgba(124, 58, 237, 0.1) 100%);
            border-left: 4px solid var(--primary);
            box-shadow: 0 0 20px rgba(0, 217, 255, 0.2);
        }
        
        .passed-stop {
            opacity: 0.5;
        }
        
        .next-stop {
            background: linear-gradient(90deg, rgba(245, 158, 11, 0.1) 0%, rgba(16, 185, 129, 0.1) 100%);
            border-left: 4px solid var(--accent);
        }
        
        .glow-text {
            text-shadow: 0 0 10px rgba(0, 217, 255, 0.5),
                         0 0 20px rgba(0, 217, 255, 0.3);
        }
        
        .progress-track {
            position: relative;
            height: 16px;
            background: rgba(30, 41, 59, 0.8);
            border-radius: 12px;
            overflow: hidden;
            border: 1px solid var(--border);
        }
        
        .progress-active {
            height: 100%;
            background: linear-gradient(90deg, var(--primary) 0%, var(--secondary) 50%, var(--accent) 100%);
            border-radius: 12px;
            transition: width 1s cubic-bezier(0.4, 0, 0.2, 1);
            box-shadow: 0 0 20px rgba(0, 217, 255, 0.5);
            position: relative;
            overflow: hidden;
        }
        
        .progress-active::after {
            content: '';
            position: absolute;
            top: 0;
            left: -100%;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.4), transparent);
            animation: shimmer 2.5s infinite;
        }
        
        @keyframes shimmer {
            0% { left: -100%; }
            100% { left: 100%; }
        }
        
        .stop-dot {
            position: absolute;
            top: 50%;
            transform: translate(-50%, -50%);
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background: var(--border);
            border: 2px solid var(--dark-bg);
            cursor: pointer;
            transition: all 0.3s ease;
            z-index: 10;
        }
        
        .stop-dot:hover {
            transform: translate(-50%, -50%) scale(1.8);
            box-shadow: 0 0 15px rgba(0, 217, 255, 0.8);
        }
        
        .stop-dot.passed {
            background: var(--success);
            box-shadow: 0 0 10px rgba(16, 185, 129, 0.5);
        }
        
        .stop-dot.current {
            background: var(--primary);
            animation: pulse-glow 2s infinite;
            transform: translate(-50%, -50%) scale(1.5);
        }
        
        .stop-dot.next {
            background: var(--accent);
            box-shadow: 0 0 10px rgba(245, 158, 11, 0.5);
        }
        
        @keyframes pulse-glow {
            0%, 100% { 
                box-shadow: 0 0 15px rgba(0, 217, 255, 0.8),
                           0 0 30px rgba(0, 217, 255, 0.4);
            }
            50% { 
                box-shadow: 0 0 25px rgba(0, 217, 255, 1),
                           0 0 50px rgba(0, 217, 255, 0.6);
            }
        }
        
        .status-dot {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            display: inline-block;
            margin-right: 8px;
        }
        
        .status-online {
            background: var(--success);
            box-shadow: 0 0 10px var(--success);
            animation: pulse-dot 2s infinite;
        }
        
        .status-offline {
            background: #EF4444;
        }
        
        @keyframes pulse-dot {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
        }
        
        .trip-badge {
            font-size: 0.7rem;
            padding: 4px 12px;
            border-radius: 20px;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        .badge-active {
            background: linear-gradient(135deg, var(--success) 0%, #059669 100%);
            box-shadow: 0 0 15px rgba(16, 185, 129, 0.5);
        }
        
        .badge-inactive {
            background: linear-gradient(135deg, var(--accent) 0%, #D97706 100%);
        }
        
        .badge-not-started {
            background: linear-gradient(135deg, #64748B 0%, #475569 100%);
        }
        
        .spinner {
            border: 3px solid rgba(255, 255, 255, 0.1);
            border-top: 3px solid var(--primary);
            border-radius: 50%;
            width: 24px;
            height: 24px;
            animation: spin 1s linear infinite;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .notification-dot {
            position: absolute;
            top: -4px;
            right: -4px;
            background: #EF4444;
            color: white;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            font-size: 11px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
            box-shadow: 0 0 10px rgba(239, 68, 68, 0.8);
        }
        
        .fade-in {
            animation: fadeIn 0.8s ease-in;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .slide-in-left {
            animation: slideInLeft 0.6s ease-out;
        }
        
        @keyframes slideInLeft {
            from { transform: translateX(-100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
        
        .neo-button {
            background: linear-gradient(145deg, #1E293B, #0F172A);
            border: 1px solid var(--border);
            transition: all 0.3s ease;
        }
        
        .neo-button:hover {
            box-shadow: 0 0 20px rgba(0, 217, 255, 0.4);
            border-color: var(--primary);
            transform: translateY(-2px);
        }
        
        .info-tooltip {
            background: rgba(15, 23, 42, 0.95);
            border: 1px solid var(--primary);
            border-radius: 12px;
            padding: 16px;
            box-shadow: 0 10px 40px rgba(0, 217, 255, 0.3);
            backdrop-filter: blur(10px);
        }
        
        .metric-card {
            background: linear-gradient(135deg, rgba(0, 217, 255, 0.1) 0%, rgba(124, 58, 237, 0.1) 100%);
            border: 1px solid rgba(0, 217, 255, 0.2);
            border-radius: 16px;
            padding: 20px;
            transition: all 0.3s ease;
        }
        
        .metric-card:hover {
            border-color: var(--primary);
            box-shadow: 0 0 25px rgba(0, 217, 255, 0.3);
        }
        
        .bus-marker {
            filter: drop-shadow(0 4px 12px rgba(0, 217, 255, 0.6));
        }
    </style>
</head>
<body class="text-gray-100">
    <!-- Loading Screen -->
    <div id="loadingOverlay" class="fixed inset-0 bg-gray-900 flex items-center justify-center z-50 transition-opacity duration-500">
        <div class="text-center">
            <div class="w-20 h-20 border-4 border-gray-700 border-t-cyan-400 rounded-full animate-spin mx-auto mb-6"></div>
            <h3 class="text-2xl font-bold glow-text mb-3">BusLK Passenger</h3>
            <p class="text-gray-400">Initializing real-time tracking...</p>
        </div>
    </div>

    <div class="container mx-auto px-4 py-6 max-w-7xl">
        <!-- Header -->
        <header class="dark-card p-6 mb-8 neon-border fade-in">
            <div class="flex flex-col lg:flex-row lg:items-center lg:justify-between">
                <div class="text-center lg:text-left mb-6 lg:mb-0">
                    <h1 class="text-4xl font-bold glow-text flex items-center justify-center lg:justify-start mb-2">
                        <i class="fas fa-bus mr-3 text-cyan-400"></i> BusLK Passenger
                    </h1>
                    <p class="text-cyan-300 font-medium">Kurunagala to Alakoladeniya • Real-time Tracking</p>
                </div>
                
                <div class="flex flex-col items-center lg:items-end space-y-4">
                    <div class="flex items-center bg-gray-800 bg-opacity-50 px-5 py-3 rounded-full border border-gray-700">
                        <span class="status-dot status-offline" id="driverOnlineStatus"></span>
                        <span id="driverStatusText" class="font-semibold text-sm mr-3">Driver Offline</span>
                        <span class="trip-badge badge-not-started" id="tripStatusText">NOT STARTED</span>
                    </div>
                    
                    <div class="flex items-center space-x-3">
                        <button id="refreshBtn" class="neo-button text-cyan-400 p-3 rounded-xl hover:rotate-180 transition-all duration-500">
                            <i class="fas fa-sync-alt"></i>
                        </button>
                        <div class="relative">
                            <button id="notificationBtn" class="neo-button text-cyan-400 p-3 rounded-xl">
                                <i class="fas fa-bell"></i>
                            </button>
                            <span class="notification-dot hidden" id="notificationBadge">3</span>
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <!-- Route Progress -->
        <div class="dark-card p-6 mb-8 neon-border fade-in">
            <div class="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
                <div>
                    <h2 class="text-2xl font-bold text-cyan-400 mb-2">Journey Progress</h2>
                    <p class="text-gray-400"><span id="totalStops">28</span> stops • ~30 minutes</p>
                </div>
                <div class="mt-4 md:mt-0">
                    <div class="bg-gray-800 bg-opacity-50 px-5 py-3 rounded-full border border-cyan-500">
                        <span class="text-sm text-cyan-400 font-semibold mr-2">Next bus:</span>
                        <span class="text-white font-bold" id="nextBusIn">
                            <span class="spinner inline-block mr-2"></span> Loading...
                        </span>
                    </div>
                </div>
            </div>

            <div class="mb-6">
                <div class="flex justify-between text-sm text-gray-400 mb-4 font-semibold">
                    <span class="flex items-center">
                        <i class="fas fa-play-circle text-green-400 mr-2"></i> Main Stand
                    </span>
                    <span class="flex items-center">
                        <i class="fas fa-flag-checkered text-purple-400 mr-2"></i> Alakoladeniya
                    </span>
                </div>
                
                <div class="progress-track mb-3" id="progressContainer">
                    <div class="progress-active" id="progressFill" style="width: 0%"></div>
                </div>
                
                <div class="flex justify-between text-xs text-gray-500">
                    <span>Started: <span id="startTime" class="text-cyan-400">-</span></span>
                    <span>ETA: <span id="routeETA" class="text-cyan-400">-</span></span>
                </div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div class="metric-card">
                    <p class="text-xs text-cyan-400 font-bold mb-2 uppercase tracking-wider">Current Stop</p>
                    <p class="font-bold text-white text-lg" id="currentStop">Loading...</p>
                </div>
                <div class="metric-card">
                    <p class="text-xs text-green-400 font-bold mb-2 uppercase tracking-wider">Next Stop</p>
                    <p class="font-bold text-white text-lg" id="nextStop">Loading...</p>
                </div>
                <div class="metric-card">
                    <p class="text-xs text-purple-400 font-bold mb-2 uppercase tracking-wider">Progress</p>
                    <p class="font-bold text-white text-lg" id="routeProgress">0%</p>
                </div>
            </div>
        </div>

        <!-- Main Grid -->
        <div class="grid grid-cols-1 xl:grid-cols-4 gap-8 mb-8">
            <!-- Map Section -->
            <div class="xl:col-span-3 dark-card p-6 fade-in">
                <div class="flex justify-between items-center mb-6">
                    <h3 class="text-xl font-bold text-cyan-400 flex items-center">
                        <i class="fas fa-location-dot mr-2"></i> Live Location
                    </h3>
                    <div class="flex items-center text-sm bg-green-900 bg-opacity-30 px-4 py-2 rounded-full border border-green-500">
                        <span class="flex h-3 w-3 relative mr-2">
                            <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                            <span class="relative inline-flex rounded-full h-3 w-3 bg-green-400"></span>
                        </span>
                        <span class="font-semibold text-green-300">LIVE</span>
                    </div>
                </div>
                
                <div id="map" class="mb-6"></div>

                <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div class="bg-gray-800 bg-opacity-50 p-4 rounded-xl border border-cyan-500">
                        <p class="text-xs text-cyan-400 font-bold mb-1 uppercase">Bus Number</p>
                        <p class="font-bold text-white" id="busNumber">-</p>
                    </div>
                    <div class="bg-gray-800 bg-opacity-50 p-4 rounded-xl border border-green-500">
                        <p class="text-xs text-green-400 font-bold mb-1 uppercase">Driver</p>
                        <p class="font-bold text-white" id="driverName">-</p>
                    </div>
                    <div class="bg-gray-800 bg-opacity-50 p-4 rounded-xl border border-purple-500">
                        <p class="text-xs text-purple-400 font-bold mb-1 uppercase">Passengers</p>
                        <p class="font-bold text-white" id="passengerCount">-</p>
                    </div>
                    <div class="bg-gray-800 bg-opacity-50 p-4 rounded-xl border border-orange-500">
                        <p class="text-xs text-orange-400 font-bold mb-1 uppercase">Speed</p>
                        <p class="font-bold text-white" id="currentSpeed">0 km/h</p>
                    </div>
                </div>
            </div>

            <!-- Stops Sidebar -->
            <div class="dark-card p-6 fade-in">
                <h3 class="text-xl font-bold text-cyan-400 mb-4 flex items-center">
                    <i class="fas fa-list-ul mr-2"></i> Stops
                </h3>
                
                <div class="stop-list mb-6" id="stopsList">
                    <div class="text-center py-12 text-gray-500">
                        <div class="spinner mx-auto mb-4"></div>
                        <p>Loading stops...</p>
                    </div>
                </div>

                <div class="space-y-3">
                    <button id="notifyBtn" class="w-full bg-gradient-to-r from-yellow-600 to-orange-600 hover:from-yellow-500 hover:to-orange-500 text-white py-3 px-4 rounded-xl font-bold transition-all duration-300 transform hover:scale-105 flex items-center justify-center shadow-lg">
                        <i class="fas fa-bell-concierge mr-2"></i> Notify at Next Stop
                    </button>
                    
                    <div class="grid grid-cols-2 gap-3">
                        <button class="neo-button text-cyan-400 py-2 rounded-xl flex items-center justify-center font-semibold">
                            <i class="fas fa-share-nodes mr-2"></i> Share
                        </button>
                        <button class="neo-button text-cyan-400 py-2 rounded-xl flex items-center justify-center font-semibold">
                            <i class="fas fa-circle-info mr-2"></i> Info
                        </button>
                    </div>
                </div>

                <div class="mt-6 pt-4 border-t border-gray-700">
                    <p class="text-sm text-gray-400 flex items-center">
                        <i class="fas fa-clock mr-2 text-cyan-400"></i>
                        <span id="lastUpdate">-</span>
                    </p>
                </div>
            </div>
        </div>

        <!-- Bottom Info Cards -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div class="dark-card p-6 fade-in">
                <h3 class="text-lg font-bold text-cyan-400 mb-4 flex items-center">
                    <i class="fas fa-gauge-high mr-2"></i> Status
                </h3>
                <div class="space-y-3">
                    <div class="flex justify-between items-center p-3 bg-gray-800 bg-opacity-50 rounded-xl">
                        <span class="text-gray-300 font-medium">ETA</span>
                        <span class="font-bold text-cyan-400" id="eta">-</span>
                    </div>
                    <div class="flex justify-between items-center p-3 bg-gray-800 bg-opacity-50 rounded-xl">
                        <span class="text-gray-300 font-medium">Distance</span>
                        <span class="font-bold text-cyan-400" id="distanceCovered">-</span>
                    </div>
                    <div class="flex justify-between items-center p-3 bg-gray-800 bg-opacity-50 rounded-xl">
                        <span class="text-gray-300 font-medium">Stops</span>
                        <span class="font-bold text-cyan-400" id="stopsPassed">0/28</span>
                    </div>
                </div>
            </div>

            <div class="dark-card p-6 fade-in">
                <h3 class="text-lg font-bold text-cyan-400 mb-4 flex items-center">
                    <i class="fas fa-circle-info mr-2"></i> Service
                </h3>
                <div class="space-y-3">
                    <div class="flex items-center">
                        <i class="fas fa-clock text-cyan-400 w-6"></i>
                        <span class="ml-3 text-gray-300 text-sm">5:00 AM - 10:00 PM</span>
                    </div>
                    <div class="flex items-center">
                        <i class="fas fa-repeat text-green-400 w-6"></i>
                        <span class="ml-3 text-gray-300 text-sm">Every 15-20 minutes</span>
                    </div>
                    <div class="flex items-center">
                        <i class="fas fa-phone text-purple-400 w-6"></i>
                        <span class="ml-3 text-gray-300 text-sm">+94 77 123 4567</span>
                    </div>
                </div>
            </div>

            <div class="dark-card p-6 fade-in">
                <h3 class="text-lg font-bold text-cyan-400 mb-4 flex items-center">
                    <i class="fas fa-bolt mr-2"></i> Actions
                </h3>
                <div class="grid grid-cols-2 gap-3">
                    <button class="bg-cyan-600 hover:bg-cyan-500 text-white p-4 rounded-xl flex flex-col items-center justify-center transition-all duration-300 transform hover:scale-105">
                        <i class="fas fa-bookmark text-xl mb-2"></i>
                        <span class="text-xs font-semibold">Save</span>
                    </button>
                    <button class="bg-green-600 hover:bg-green-500 text-white p-4 rounded-xl flex flex-col items-center justify-center transition-all duration-300 transform hover:scale-105">
                        <i class="fas fa-route text-xl mb-2"></i>
                        <span class="text-xs font-semibold">Route</span>
                    </button>
                    <button class="bg-purple-600 hover:bg-purple-500 text-white p-4 rounded-xl flex flex-col items-center justify-center transition-all duration-300 transform hover:scale-105">
                        <i class="fas fa-bell text-xl mb-2"></i>
                        <span class="text-xs font-semibold">Alerts</span>
                    </button>
                    <button class="bg-orange-600 hover:bg-orange-500 text-white p-4 rounded-xl flex flex-col items-center justify-center transition-all duration-300 transform hover:scale-105">
                        <i class="fas fa-question text-xl mb-2"></i>
                        <span class="text-xs font-semibold">Help</span>
                    </button>
                </div>
            </div>
        </div>

        <!-- Footer -->
        <footer class="text-center text-gray-400 text-sm p-6 mt-8">
            <div class="flex flex-col md:flex-row justify-between items-center">
                <p>BusLK Village Passenger App © 2025</p>
                <div class="flex space-x-6 mt-3 md:mt-0">
                    <span class="flex items-center">
                        <span class="status-dot status-online mr-2"></span> System Online
                    </span>
                    <span id="connectionStatus" class="flex items-center text-cyan-400">
                        <i class="fas fa-wifi mr-2"></i> Connected
                    </span>
                </div>
            </div>
        </footer>
    </div>

    <script>
        let map, busMarker, routePolyline, busStopsLayer;
        let busStops = [];
        let currentStopIndex = 0;
        let lastUpdateTime = new Date();
        let updateInterval;
        let connectionRetries = 0;
        const MAX_RETRIES = 5;

        function initMap(lat = 7.48813300, lng = 80.36424000) {
            map = L.map('map', {
                zoomControl: true,
                scrollWheelZoom: true
            }).setView([lat, lng], 14);

            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '&copy; OpenStreetMap contributors',
                maxZoom: 18
            }).addTo(map);

            const busIcon = L.divIcon({
                className: 'bus-marker',
                html: `
                    <div class="relative">
                        <div class="w-14 h-14 bg-gradient-to-br from-cyan-400 to-blue-600 rounded-full flex items-center justify-center shadow-2xl border-4 border-white" style="box-shadow: 0 0 30px rgba(0, 217, 255, 0.8);">
                            <i class="fas fa-bus text-white text-xl"></i>
                        </div>
                    </div>
                `,
                iconSize: [56, 56],
                iconAnchor: [28, 56]
            });

            busMarker = L.marker([lat, lng], { 
                icon: busIcon,
                zIndexOffset: 1000
            }).addTo(map).bindPopup(`
                <div class="text-center p-3 min-w-48 bg-gray-900 text-white rounded-lg">
                    <h4 class="font-bold text-cyan-400 mb-2">Bus Location</h4>
                    <div class="space-y-1 text-sm">
                        <div class="flex justify-between">
                            <span class="text-gray-400">Latitude:</span>
                            <span class="font-mono text-cyan-300">${lat.toFixed(6)}</span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-gray-400">Longitude:</span>
                            <span class="font-mono text-cyan-300">${lng.toFixed(6)}</span>
                        </div>
                        <div class="flex justify-between">
                            <span class="text-gray-400">Status:</span>
                            <span class="text-green-400">Active</span>
                        </div>
                    </div>
                </div>
            `).openPopup();
        }

        function updateMapWithStops(stops) {
            busStops = stops;
            
            if (busStopsLayer) {
                map.removeLayer(busStopsLayer);
            }
            if (routePolyline) {
                map.removeLayer(routePolyline);
            }

            busStopsLayer = L.layerGroup().addTo(map);

            stops.forEach((stop, index) => {
                const isCurrent = stop.stop_id === currentStopId;
                const isNext = stop.stop_id === nextStopId;
                const isPassed = currentStopId && 
                    busStops.findIndex(s => s.stop_id === currentStopId) > index;
                
                const stopIcon = L.divIcon({
                    className: 'custom-stop-marker',
                    html: `
                        <div class="w-11 h-11 rounded-full flex items-center justify-center text-white font-bold text-xs shadow-xl border-3 border-gray-900
                            ${isCurrent ? 'bg-gradient-to-br from-cyan-400 to-blue-500' : 
                              isNext ? 'bg-gradient-to-br from-yellow-400 to-orange-500' : 
                              isPassed ? 'bg-gradient-to-br from-gray-500 to-gray-600' : 
                              'bg-gradient-to-br from-purple-500 to-indigo-600'}"
                            style="box-shadow: 0 0 ${isCurrent ? '20px rgba(0, 217, 255, 0.8)' : isNext ? '15px rgba(245, 158, 11, 0.6)' : '10px rgba(0, 0, 0, 0.3)'};">
                            ${stop.stop_order}
                        </div>
                    `,
                    iconSize: [44, 44],
                    iconAnchor: [22, 22]
                });

                const marker = L.marker([stop.latitude, stop.longitude], {icon: stopIcon})
                    .addTo(busStopsLayer)
                    .bindPopup(`
                        <div class="p-3 min-w-56 bg-gray-900 text-white rounded-lg">
                            <h4 class="font-bold text-cyan-400 mb-2">${stop.stop_name}</h4>
                            <div class="space-y-1 text-sm">
                                ${stop.landmark ? `<p class="text-gray-400"><i class="fas fa-landmark mr-2 text-purple-400"></i>${stop.landmark}</p>` : ''}
                                <p class="text-gray-400"><i class="fas fa-hashtag mr-2 text-cyan-400"></i>Order: ${stop.stop_order}</p>
                                <p class="text-gray-400"><i class="fas fa-clock mr-2 text-green-400"></i>ETA: ${stop.estimated_time_from_start} min</p>
                                ${isCurrent ? '<p class="text-cyan-400 font-bold"><i class="fas fa-location-dot mr-2"></i>Current Stop</p>' : ''}
                                ${isNext ? '<p class="text-yellow-400 font-bold"><i class="fas fa-arrow-right mr-2"></i>Next Stop</p>' : ''}
                            </div>
                        </div>
                    `);

                if (isCurrent) {
                    marker.openPopup();
                }
            });

            const routePoints = stops.map(stop => [stop.latitude, stop.longitude]);
            routePolyline = L.polyline(routePoints, {
                color: '#00D9FF',
                weight: 6,
                opacity: 0.7,
                dashArray: '10, 15',
                lineJoin: 'round'
            }).addTo(map);

            updateProgressBarWithMarkers();
            document.getElementById('totalStops').textContent = stops.length;
        }

        function updateProgressBarWithMarkers() {
            const progressContainer = document.getElementById('progressContainer');
            const existingMarkers = progressContainer.querySelectorAll('.stop-dot');
            existingMarkers.forEach(marker => marker.remove());
            
            busStops.forEach((stop, index) => {
                const percentage = (index / (busStops.length - 1)) * 100;
                const marker = document.createElement('div');
                marker.className = 'stop-dot';
                
                if (stop.stop_id === currentStopId) {
                    marker.classList.add('current');
                } else if (currentStopId && busStops.findIndex(s => s.stop_id === currentStopId) > index) {
                    marker.classList.add('passed');
                } else if (stop.stop_id === nextStopId) {
                    marker.classList.add('next');
                }
                
                marker.style.left = `${percentage}%`;
                marker.title = `${stop.stop_name} (Order: ${stop.stop_order})`;
                
                marker.addEventListener('click', () => {
                    showStopInfo(stop);
                });
                
                progressContainer.appendChild(marker);
            });
        }

        function showStopInfo(stop) {
            const tooltip = document.createElement('div');
            tooltip.className = 'info-tooltip fixed z-50';
            tooltip.innerHTML = `
                <h4 class="font-bold text-cyan-400 mb-1">${stop.stop_name}</h4>
                <p class="text-sm text-gray-300">Order: ${stop.stop_order}</p>
                <p class="text-sm text-gray-300">ETA: ${stop.estimated_time_from_start} min</p>
                ${stop.landmark ? `<p class="text-sm text-gray-400">${stop.landmark}</p>` : ''}
            `;
            
            document.body.appendChild(tooltip);
            
            const progressContainer = document.getElementById('progressContainer');
            const rect = progressContainer.getBoundingClientRect();
            tooltip.style.top = `${rect.top - tooltip.offsetHeight - 10}px`;
            tooltip.style.left = `${rect.left + (rect.width * (stop.stop_order - 1) / (busStops.length - 1))}px`;
            
            setTimeout(() => {
                tooltip.remove();
            }, 3000);
        }

        function updateBusPosition(lat, lng) {
            if (busMarker) {
                busMarker.setLatLng([lat, lng]);
                map.panTo([lat, lng], {
                    animate: true,
                    duration: 1.5
                });
                
                busMarker.bindPopup(`
                    <div class="text-center p-3 min-w-48 bg-gray-900 text-white rounded-lg">
                        <h4 class="font-bold text-cyan-400 mb-2">Bus Location</h4>
                        <div class="space-y-1 text-sm">
                            <div class="flex justify-between">
                                <span class="text-gray-400">Latitude:</span>
                                <span class="font-mono text-cyan-300">${lat.toFixed(6)}</span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-gray-400">Longitude:</span>
                                <span class="font-mono text-cyan-300">${lng.toFixed(6)}</span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-gray-400">Status:</span>
                                <span class="text-green-400">Active</span>
                            </div>
                        </div>
                    </div>
                `);
            }
        }

        function renderStopsList(currentStopId, nextStopId) {
            const stopsList = document.getElementById('stopsList');
            
            if (busStops.length === 0) {
                stopsList.innerHTML = `
                    <div class="text-center py-12 text-gray-500">
                        <i class="fas fa-map-marker-alt text-4xl mb-4 opacity-30"></i>
                        <p>No stops available</p>
                    </div>
                `;
                return;
            }

            let stopsHTML = '';
            
            busStops.forEach((stop, index) => {
                const isCurrent = stop.stop_id === currentStopId;
                const isNext = stop.stop_id === nextStopId;
                const isPassed = currentStopId && 
                    busStops.findIndex(s => s.stop_id === currentStopId) > index;

                let stopClass = 'p-4 border-b border-gray-700 transition-all duration-300 cursor-pointer hover:bg-gray-800 hover:bg-opacity-30';
                if (isPassed) stopClass += ' passed-stop';
                if (isCurrent) stopClass += ' current-stop';
                if (isNext) stopClass += ' next-stop';

                stopsHTML += `
                    <div class="${stopClass}" onclick="focusOnStop(${stop.stop_id})">
                        <div class="flex justify-between items-start">
                            <div class="flex items-center">
                                <div class="w-12 h-12 rounded-full flex items-center justify-center mr-3 text-white font-bold text-sm shadow-lg
                                    ${isCurrent ? 'bg-gradient-to-br from-cyan-400 to-blue-500' : 
                                      isNext ? 'bg-gradient-to-br from-yellow-400 to-orange-500' : 
                                      isPassed ? 'bg-gradient-to-br from-gray-500 to-gray-600' : 
                                      'bg-gradient-to-br from-purple-500 to-indigo-600'}">
                                    ${stop.stop_order}
                                </div>
                                <div>
                                    <p class="font-semibold ${isPassed ? 'text-gray-500' : 'text-white'}">${stop.stop_name}</p>
                                    <p class="text-sm ${isPassed ? 'text-gray-600' : 'text-gray-400'}">
                                        ${stop.landmark || 'No landmark'}
                                    </p>
                                    <p class="text-xs ${isPassed ? 'text-gray-600' : 'text-gray-500'}">
                                        ETA: ${stop.estimated_time_from_start} min
                                    </p>
                                </div>
                            </div>
                            <div class="text-right">
                                ${isCurrent ?
                                    '<span class="text-xs bg-cyan-500 bg-opacity-20 text-cyan-400 px-2 py-1 rounded-full font-bold border border-cyan-500">NOW</span>' : ''}
                                ${isNext ?
                                    '<span class="text-xs bg-yellow-500 bg-opacity-20 text-yellow-400 px-2 py-1 rounded-full font-bold border border-yellow-500">NEXT</span>' : ''}
                                ${isPassed ?
                                    '<span class="text-xs bg-gray-500 bg-opacity-20 text-gray-500 px-2 py-1 rounded-full font-bold border border-gray-600">DONE</span>' : ''}
                            </div>
                        </div>
                    </div>
                `;
            });

            stopsList.innerHTML = stopsHTML;
        }

        function focusOnStop(stopId) {
            const stop = busStops.find(s => s.stop_id === stopId);
            if (stop) {
                map.setView([stop.latitude, stop.longitude], 16);
                busStopsLayer.eachLayer(layer => {
                    if (layer.stopData && layer.stopData.stop_id === stopId) {
                        layer.openPopup();
                    }
                });
            }
        }

        function updateBusInfo(busData) {
            fadeUpdate('currentStop', busData.current_stop_name || 'Not available');
            fadeUpdate('nextStop', busData.next_stop_name || 'Not available');
            fadeUpdate('busNumber', busData.bus_number);
            fadeUpdate('driverName', busData.driver_name);
            fadeUpdate('passengerCount', `${busData.passenger_count}/${busData.capacity}`);
            fadeUpdate('currentSpeed', busData.speed_kmh ? `${busData.speed_kmh.toFixed(1)} km/h` : '0 km/h');
            fadeUpdate('eta', `${busData.eta_minutes} minutes`);
            fadeUpdate('routeProgress', `${Math.round(busData.progress_percentage)}%`);
            
            const stopsPassed = busData.current_stop_order ? busData.current_stop_order - 1 : 0;
            const totalStops = busData.total_stops || busStops.length;
            document.getElementById('stopsPassed').textContent = `${stopsPassed}/${totalStops}`;
            
            const distanceCovered = ((busData.progress_percentage / 100) * 85.5).toFixed(1);
            document.getElementById('distanceCovered').textContent = `${distanceCovered} km`;

            const progressFill = document.getElementById('progressFill');
            progressFill.style.width = `${busData.progress_percentage}%`;

            const driverStatusIndicator = document.getElementById('driverOnlineStatus');
            const driverStatusText = document.getElementById('driverStatusText');
            const tripStatusText = document.getElementById('tripStatusText');

            if (busData.driver_online) {
                driverStatusIndicator.className = 'status-dot status-online';
                driverStatusText.textContent = 'Driver Online';
            } else {
                driverStatusIndicator.className = 'status-dot status-offline';
                driverStatusText.textContent = 'Driver Offline';
            }

            if (busData.trip_status === 'in_progress') {
                tripStatusText.className = 'trip-badge badge-active';
                tripStatusText.textContent = 'ACTIVE';
                document.getElementById('nextBusIn').innerHTML = '<span class="text-green-400 font-bold">NOW</span>';
            } else if (busData.trip_status === 'scheduled') {
                tripStatusText.className = 'trip-badge badge-inactive';
                tripStatusText.textContent = 'SCHEDULED';
                document.getElementById('nextBusIn').textContent = '15 minutes';
            } else {
                tripStatusText.className = 'trip-badge badge-not-started';
                tripStatusText.textContent = 'NOT STARTED';
                document.getElementById('nextBusIn').textContent = 'No active trip';
            }

            updateLastUpdateTime();
            
            const now = new Date();
            const etaTime = new Date(now.getTime() + busData.eta_minutes * 60000);
            document.getElementById('routeETA').textContent = `${etaTime.getHours()}:${etaTime.getMinutes().toString().padStart(2, '0')}`;
            
            if (busData.trip_status === 'in_progress') {
                document.getElementById('startTime').textContent = '7:00 AM';
            } else {
                document.getElementById('startTime').textContent = '-';
            }
        }

        function fadeUpdate(elementId, newText) {
            const element = document.getElementById(elementId);
            if (element.textContent !== newText) {
                element.style.opacity = '0.5';
                setTimeout(() => {
                    element.textContent = newText;
                    element.style.opacity = '1';
                }, 150);
            }
        }

        function updateLastUpdateTime() {
            const timeDiff = Math.floor((new Date() - lastUpdateTime) / 1000);
            let timeText = '';
            
            if (timeDiff < 10) {
                timeText = 'Just now';
            } else if (timeDiff < 60) {
                timeText = `${timeDiff} seconds ago`;
            } else if (timeDiff < 3600) {
                timeText = `${Math.floor(timeDiff / 60)} minutes ago`;
            } else {
                timeText = `${Math.floor(timeDiff / 3600)} hours ago`;
            }
            
            document.getElementById('lastUpdate').textContent = timeText;
        }

        function updateConnectionStatus(connected, message = '') {
            const statusElement = document.getElementById('connectionStatus');
            
            if (connected) {
                statusElement.className = 'flex items-center text-cyan-400';
                statusElement.innerHTML = '<i class="fas fa-wifi mr-2"></i> Connected';
                connectionRetries = 0;
            } else {
                statusElement.className = 'flex items-center text-red-400';
                statusElement.innerHTML = `<i class="fas fa-exclamation-triangle mr-2"></i> ${message}`;
            }
        }

        function showNotification(message, type = 'info') {
            const notification = document.createElement('div');
            notification.className = `fixed top-4 right-4 p-4 rounded-xl shadow-2xl z-50 transform transition-all duration-300 translate-x-full border ${
                type === 'error' ? 'bg-red-900 bg-opacity-90 text-white border-red-500' : 
                type === 'success' ? 'bg-green-900 bg-opacity-90 text-white border-green-500' : 
                'bg-cyan-900 bg-opacity-90 text-white border-cyan-500'
            }`;
            notification.style.boxShadow = '0 0 30px rgba(0, 217, 255, 0.3)';
            notification.innerHTML = `
                <div class="flex items-center">
                    <i class="fas ${
                        type === 'error' ? 'fa-exclamation-triangle' : 
                        type === 'success' ? 'fa-check-circle' : 'fa-info-circle'
                    } mr-3 text-xl"></i>
                    <span class="font-semibold">${message}</span>
                </div>
            `;
            
            document.body.appendChild(notification);
            
            setTimeout(() => {
                notification.style.transform = 'translateX(0)';
            }, 10);
            
            setTimeout(() => {
                notification.style.transform = 'translateX(100%)';
                setTimeout(() => {
                    if (notification.parentNode) {
                        notification.parentNode.removeChild(notification);
                    }
                }, 300);
            }, 5000);
        }

        function fetchBusData() {
            fetch('../api/get_passenger_bus_data.php')
                .then(response => {
                    if (!response.ok) {
                        throw new Error(`HTTP error! status: ${response.status}`);
                    }
                    return response.json();
                })
                .then(data => {
                    if (data.success) {
                        lastUpdateTime = new Date();
                        
                        const busData = data.bus_data;
                        const stops = data.bus_stops;

                        if (stops && stops.length > 0) {
                            updateMapWithStops(stops);
                        }

                        updateBusPosition(busData.latitude, busData.longitude);
                        renderStopsList(busData.current_stop_id, busData.next_stop_id);
                        updateBusInfo(busData);
                        updateConnectionStatus(true);
                        
                        const loadingOverlay = document.getElementById('loadingOverlay');
                        if (loadingOverlay) {
                            setTimeout(() => {
                                loadingOverlay.style.opacity = '0';
                                setTimeout(() => {
                                    loadingOverlay.style.display = 'none';
                                }, 500);
                            }, 1000);
                        }

                    } else {
                        throw new Error(data.message || 'Unknown error occurred');
                    }
                })
                .catch(error => {
                    console.error('Error fetching bus data:', error);
                    
                    connectionRetries++;
                    if (connectionRetries <= MAX_RETRIES) {
                        updateConnectionStatus(false, `Retrying... (${connectionRetries}/${MAX_RETRIES})`);
                        showNotification('Connection issue. Retrying...', 'error');
                    } else {
                        updateConnectionStatus(false, 'Connection failed');
                        showNotification('Unable to connect to tracking service', 'error');
                    }
                });
        }

        document.addEventListener('DOMContentLoaded', function() {
            initMap();
            fetchBusData();
            updateInterval = setInterval(fetchBusData, 5000);

            document.getElementById('refreshBtn').addEventListener('click', function() {
                const icon = this.querySelector('i');
                icon.classList.add('fa-spin');
                fetchBusData();
                setTimeout(() => {
                    icon.classList.remove('fa-spin');
                    showNotification('Data refreshed successfully', 'success');
                }, 1000);
            });

            document.getElementById('notifyBtn').addEventListener('click', function() {
                const nextStop = document.getElementById('nextStop').textContent;
                
                const originalText = this.innerHTML;
                this.innerHTML = '<i class="fas fa-spinner fa-spin mr-2"></i> Setting...';
                this.disabled = true;
                
                setTimeout(() => {
                    this.innerHTML = originalText;
                    this.disabled = false;
                    showNotification(`Notification set for ${nextStop}!`, 'success');
                    
                    const badge = document.getElementById('notificationBadge');
                    badge.classList.remove('hidden');
                }, 1500);
            });

            document.getElementById('notificationBtn').addEventListener('click', function() {
                showNotification('Notification settings', 'info');
                const badge = document.getElementById('notificationBadge');
                badge.classList.add('hidden');
            });

            document.addEventListener('visibilitychange', function() {
                if (document.hidden) {
                    clearInterval(updateInterval);
                    updateInterval = setInterval(fetchBusData, 30000);
                } else {
                    clearInterval(updateInterval);
                    updateInterval = setInterval(fetchBusData, 5000);
                    fetchBusData();
                }
            });

            window.addEventListener('online', function() {
                showNotification('Connection restored', 'success');
                fetchBusData();
            });

            window.addEventListener('offline', function() {
                showNotification('You are currently offline', 'error');
            });
        });

        window.addEventListener('beforeunload', function() {
            if (updateInterval) {
                clearInterval(updateInterval);
            }
        });

        let currentStopId = null;
        let nextStopId = null;
    </script>
</body>
</html>
<?php
require_once '../includes/config.php';

// Get all active routes
$stmt = $pdo->query("
    SELECT r.*, COUNT(bs.stop_id) as stop_count 
    FROM routes r 
    LEFT JOIN bus_stops bs ON r.route_id = bs.route_id AND bs.is_active = 1
    WHERE r.is_active = 1 
    GROUP BY r.route_id
");
$routes = $stmt->fetchAll();

// Get stops for each route
foreach ($routes as &$route) {
    $stmt = $pdo->prepare("
        SELECT stop_name, stop_order, latitude, longitude, landmark, estimated_time_from_start
        FROM bus_stops 
        WHERE route_id = ? AND is_active = 1 
        ORDER BY stop_order
    ");
    $stmt->execute([$route['route_id']]);
    $route['stops'] = $stmt->fetchAll();
}
unset($route); // Break reference
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Routes & Schedules - Bus Tracker</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="#">Bus Tracker</a>
            <div class="navbar-nav ms-auto">
                <a href="index.php" class="nav-link">Live Map</a>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <h2 class="mb-4">Bus Routes & Schedules</h2>
        
        <?php foreach ($routes as $route): ?>
            <div class="card mb-4">
                <div class="card-header">
                    <h4 class="card-title mb-0"><?php echo $route['route_name']; ?></h4>
                    <small class="text-muted">Code: <?php echo $route['route_code']; ?></small>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <p><strong>From:</strong> <?php echo $route['start_location']; ?></p>
                            <p><strong>To:</strong> <?php echo $route['end_location']; ?></p>
                        </div>
                        <div class="col-md-6">
                            <p><strong>Distance:</strong> <?php echo $route['total_distance_km']; ?> km</p>
                            <p><strong>Duration:</strong> <?php echo $route['estimated_duration_minutes']; ?> minutes</p>
                        </div>
                    </div>
                    
                    <h5 class="mt-4">Bus Stops</h5>
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Stop Name</th>
                                    <th>Landmark</th>
                                    <th>Estimated Time</th>
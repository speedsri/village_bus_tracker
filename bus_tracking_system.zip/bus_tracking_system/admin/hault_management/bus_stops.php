<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Start session at the very beginning
session_start();

require_once '../../includes/config.php';
require_once '../../includes/auth.php';

// Check admin auth
if (!isset($_SESSION['admin_id']) || !isset($_SESSION['admin_session_token'])) {
    header('Location: index.php');
    exit;
}

$admin_id = $_SESSION['admin_id'];
$admin_name = isset($_SESSION['admin_name']) ? $_SESSION['admin_name'] : 'Administrator';

// Verify admin session
try {
    $stmt = $pdo->prepare("
        SELECT us.*, u.user_type, u.full_name 
        FROM user_sessions us 
        JOIN users u ON us.user_id = u.user_id 
        WHERE us.user_id = ? AND us.session_token = ? AND us.is_active = 1
        AND u.user_type = 'admin' AND u.is_active = 1
    ");
    $stmt->execute([$admin_id, $_SESSION['admin_session_token']]);
    $session = $stmt->fetch();

    if (!$session) {
        session_destroy();
        header('Location: index.php?session=expired');
        exit;
    }
} catch (PDOException $e) {
    error_log("Session verification error: " . $e->getMessage());
}

// Handle form submissions
$message = '';
$message_type = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (isset($_POST['add_stop'])) {
            // Add new bus stop
            $stmt = $pdo->prepare("
                INSERT INTO bus_stops (route_id, stop_name, stop_order, latitude, longitude, landmark, estimated_time_from_start, is_active)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([
                $_POST['route_id'],
                $_POST['stop_name'],
                $_POST['stop_order'],
                $_POST['latitude'],
                $_POST['longitude'],
                $_POST['landmark'],
                $_POST['estimated_time'],
                1
            ]);
            
            // Log the activity
            $stmt = $pdo->prepare("
                INSERT INTO activity_logs (user_id, action_type, table_affected, record_id, ip_address)
                VALUES (?, 'create', 'bus_stops', ?, ?)
            ");
            $stmt->execute([$admin_id, $pdo->lastInsertId(), get_client_ip()]);
            
            $message = "Bus stop added successfully!";
            $message_type = "success";
            
        } elseif (isset($_POST['update_stop'])) {
            // Update existing bus stop
            $stmt = $pdo->prepare("
                UPDATE bus_stops 
                SET route_id = ?, stop_name = ?, stop_order = ?, latitude = ?, longitude = ?, 
                    landmark = ?, estimated_time_from_start = ?, is_active = ?
                WHERE stop_id = ?
            ");
            $stmt->execute([
                $_POST['route_id'],
                $_POST['stop_name'],
                $_POST['stop_order'],
                $_POST['latitude'],
                $_POST['longitude'],
                $_POST['landmark'],
                $_POST['estimated_time'],
                $_POST['is_active'],
                $_POST['stop_id']
            ]);
            
            // Log the activity
            $stmt = $pdo->prepare("
                INSERT INTO activity_logs (user_id, action_type, table_affected, record_id, ip_address)
                VALUES (?, 'update', 'bus_stops', ?, ?)
            ");
            $stmt->execute([$admin_id, $_POST['stop_id'], get_client_ip()]);
            
            $message = "Bus stop updated successfully!";
            $message_type = "success";
            
        } elseif (isset($_POST['delete_stop'])) {
            // Soft delete bus stop
            $stmt = $pdo->prepare("UPDATE bus_stops SET is_active = 0 WHERE stop_id = ?");
            $stmt->execute([$_POST['stop_id']]);
            
            // Log the activity
            $stmt = $pdo->prepare("
                INSERT INTO activity_logs (user_id, action_type, table_affected, record_id, ip_address)
                VALUES (?, 'delete', 'bus_stops', ?, ?)
            ");
            $stmt->execute([$admin_id, $_POST['stop_id'], get_client_ip()]);
            
            $message = "Bus stop deleted successfully!";
            $message_type = "success";
        }
    } catch (PDOException $e) {
        $message = "Error: " . $e->getMessage();
        $message_type = "danger";
    }
}

// Get all bus stops with route information
try {
    $stmt = $pdo->prepare("
        SELECT bs.*, r.route_name, r.route_code
        FROM bus_stops bs
        JOIN routes r ON bs.route_id = r.route_id
        ORDER BY bs.route_id, bs.stop_order
    ");
    $stmt->execute();
    $bus_stops = $stmt->fetchAll();
    
    // Get routes for dropdown
    $stmt = $pdo->prepare("SELECT route_id, route_name FROM routes WHERE is_active = 1 ORDER BY route_name");
    $stmt->execute();
    $routes = $stmt->fetchAll();
    
} catch (PDOException $e) {
    error_log("Database error: " . $e->getMessage());
    $bus_stops = [];
    $routes = [];
}

// Get stop for editing if ID is provided
$edit_stop = null;
if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM bus_stops WHERE stop_id = ?");
    $stmt->execute([$_GET['edit']]);
    $edit_stop = $stmt->fetch();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bus Stops Management - Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .stat-card {
            border-radius: 10px;
            border: none;
            transition: transform 0.2s;
            border-left: 4px solid #007bff;
        }
        .stat-card:hover {
            transform: translateY(-5px);
        }
        .sidebar {
            background: #2c3e50;
            color: white;
            min-height: 100vh;
        }
        .sidebar .nav-link {
            color: #bdc3c7;
            padding: 12px 20px;
            border-radius: 5px;
            margin: 2px 0;
        }
        .sidebar .nav-link:hover, .sidebar .nav-link.active {
            background: #34495e;
            color: white;
        }
        .main-content {
            background: #f8f9fa;
            min-height: 100vh;
        }
        .table-responsive {
            max-height: 600px;
        }
        .coordinates-input {
            font-family: monospace;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 sidebar p-0">
                <div class="p-3 border-bottom">
                    <h4 class="text-white mb-0">
                        <i class="fas fa-bus me-2"></i>Bus Tracker
                    </h4>
                    <small class="text-muted">Admin Panel</small>
                </div>
                <nav class="nav flex-column p-3">
                    <a class="nav-link" href="dashboard.php">
                        <i class="fas fa-tachometer-alt me-2"></i>Dashboard
                    </a>
                    <a class="nav-link" href="buses.php">
                        <i class="fas fa-bus me-2"></i>Buses
                    </a>
                    <a class="nav-link" href="assign_drivers.php">
                        <i class="fas fa-users me-2"></i>Drivers
                    </a>
                    <a class="nav-link" href="routes.php">
                        <i class="fas fa-route me-2"></i>Routes
                    </a>
                    <a class="nav-link active" href="bus_stops.php">
                        <i class="fas fa-map-marker-alt me-2"></i>Bus Stops
                    </a>
                    <a class="nav-link" href="trips.php">
                        <i class="fas fa-shipping-fast me-2"></i>Trips
                    </a>
                    <a class="nav-link" href="passengers.php">
                        <i class="fas fa-user-friends me-2"></i>Passengers
                    </a>
                    <a class="nav-link" href="trip_details.php">
                        <i class="fas fa-chart-bar me-2"></i>Trip_Details
                    </a>
                    <a class="nav-link" href="system_alerts.php">
                        <i class="fas fa-bell me-2"></i>Alerts
                    </a>
                    <div class="mt-4 pt-3 border-top">
                        <a class="nav-link" href="logout.php">
                            <i class="fas fa-sign-out-alt me-2"></i>Logout
                        </a>
                    </div>
                </nav>
            </div>

            <!-- Main Content -->
            <div class="col-md-9 col-lg-10 main-content p-0">
                <!-- Top Bar -->
                <nav class="navbar navbar-light bg-white border-bottom">
                    <div class="container-fluid">
                        <span class="navbar-text">
                            <i class="fas fa-user-shield me-2"></i>Welcome, <strong><?php echo htmlspecialchars($admin_name); ?></strong>
                        </span>
                        <div class="d-flex">
                            <span class="navbar-text me-3">
                                <i class="fas fa-clock me-1"></i><?php echo date('l, F j, Y'); ?>
                            </span>
                        </div>
                    </div>
                </nav>

                <div class="container-fluid p-4">
                    <!-- Page Header -->
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <div>
                            <h2 class="h4 mb-1">
                                <i class="fas fa-map-marker-alt me-2 text-primary"></i>Bus Stops Management
                            </h2>
                            <p class="text-muted mb-0">Manage all bus stops and their locations</p>
                        </div>
                        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addStopModal">
                            <i class="fas fa-plus me-2"></i>Add New Stop
                        </button>
                    </div>

                    <!-- Alert Messages -->
                    <?php if ($message): ?>
                        <div class="alert alert-<?php echo $message_type; ?> alert-dismissible fade show" role="alert">
                            <i class="fas fa-<?php echo $message_type === 'success' ? 'check-circle' : 'exclamation-triangle'; ?> me-2"></i>
                            <?php echo htmlspecialchars($message); ?>
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>

                    <!-- Statistics Cards -->
                    <div class="row mb-4">
                        <div class="col-xl-3 col-md-6 mb-3">
                            <div class="card stat-card border-left-primary">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between">
                                        <div>
                                            <h4 class="card-title text-primary"><?php echo count($bus_stops); ?></h4>
                                            <p class="card-text text-muted">Total Stops</p>
                                        </div>
                                        <div class="stat-icon text-primary">
                                            <i class="fas fa-map-marker-alt"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-3 col-md-6 mb-3">
                            <div class="card stat-card border-left-success">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between">
                                        <div>
                                            <h4 class="card-title text-success">
                                                <?php echo count(array_filter($bus_stops, function($stop) { return $stop['is_active']; })); ?>
                                            </h4>
                                            <p class="card-text text-muted">Active Stops</p>
                                        </div>
                                        <div class="stat-icon text-success">
                                            <i class="fas fa-check-circle"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-3 col-md-6 mb-3">
                            <div class="card stat-card border-left-info">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between">
                                        <div>
                                            <h4 class="card-title text-info">
                                                <?php echo count(array_unique(array_column($bus_stops, 'route_id'))); ?>
                                            </h4>
                                            <p class="card-text text-muted">Routes Covered</p>
                                        </div>
                                        <div class="stat-icon text-info">
                                            <i class="fas fa-route"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-3 col-md-6 mb-3">
                            <div class="card stat-card border-left-warning">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between">
                                        <div>
                                            <h4 class="card-title text-warning">
                                                <?php echo count($routes); ?>
                                            </h4>
                                            <p class="card-text text-muted">Available Routes</p>
                                        </div>
                                        <div class="stat-icon text-warning">
                                            <i class="fas fa-bus"></i>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Bus Stops Table -->
                    <div class="card">
                        <div class="card-header bg-white d-flex justify-content-between align-items-center">
                            <h5 class="card-title mb-0">
                                <i class="fas fa-list me-2"></i>All Bus Stops
                            </h5>
                            <div class="d-flex">
                                <input type="text" id="searchInput" class="form-control form-control-sm me-2" placeholder="Search stops..." style="width: 200px;">
                                <button class="btn btn-sm btn-outline-secondary" onclick="clearSearch()">
                                    <i class="fas fa-times"></i>
                                </button>
                            </div>
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-sm table-hover mb-0" id="stopsTable">
                                    <thead class="table-light">
                                        <tr>
                                            <th>Stop ID</th>
                                            <th>Stop Name</th>
                                            <th>Route</th>
                                            <th>Order</th>
                                            <th>Coordinates</th>
                                            <th>Landmark</th>
                                            <th>Est. Time</th>
                                            <th>Status</th>
                                            <th>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if (!empty($bus_stops)): ?>
                                            <?php foreach ($bus_stops as $stop): ?>
                                                <tr>
                                                    <td><strong>#<?php echo $stop['stop_id']; ?></strong></td>
                                                    <td>
                                                        <i class="fas fa-map-marker-alt text-danger me-1"></i>
                                                        <strong><?php echo htmlspecialchars($stop['stop_name']); ?></strong>
                                                    </td>
                                                    <td>
                                                        <span class="badge bg-info">
                                                            <?php echo htmlspecialchars($stop['route_name']); ?>
                                                        </span>
                                                    </td>
                                                    <td>
                                                        <span class="badge bg-secondary"><?php echo $stop['stop_order']; ?></span>
                                                    </td>
                                                    <td>
                                                        <small class="text-muted coordinates-input">
                                                            <?php echo number_format($stop['latitude'], 6); ?>,<br>
                                                            <?php echo number_format($stop['longitude'], 6); ?>
                                                        </small>
                                                    </td>
                                                    <td>
                                                        <?php echo !empty($stop['landmark']) ? htmlspecialchars($stop['landmark']) : '<span class="text-muted">-</span>'; ?>
                                                    </td>
                                                    <td>
                                                        <span class="badge bg-warning text-dark">
                                                            <?php echo $stop['estimated_time_from_start']; ?> min
                                                        </span>
                                                    </td>
                                                    <td>
                                                        <span class="badge bg-<?php echo $stop['is_active'] ? 'success' : 'secondary'; ?>">
                                                            <?php echo $stop['is_active'] ? 'Active' : 'Inactive'; ?>
                                                        </span>
                                                    </td>
                                                    <td>
                                                        <div class="btn-group btn-group-sm">
                                                            <a href="?edit=<?php echo $stop['stop_id']; ?>" class="btn btn-outline-primary" data-bs-toggle="tooltip" title="Edit Stop">
                                                                <i class="fas fa-edit"></i>
                                                            </a>
                                                            <button type="button" class="btn btn-outline-danger" 
                                                                    onclick="confirmDelete(<?php echo $stop['stop_id']; ?>, '<?php echo htmlspecialchars($stop['stop_name']); ?>')"
                                                                    data-bs-toggle="tooltip" title="Delete Stop">
                                                                <i class="fas fa-trash"></i>
                                                            </button>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        <?php else: ?>
                                            <tr>
                                                <td colspan="9" class="text-center py-4 text-muted">
                                                    <i class="fas fa-map-marker-alt fa-3x mb-3"></i>
                                                    <p>No bus stops found. Add your first bus stop to get started.</p>
                                                </td>
                                            </tr>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Add/Edit Stop Modal -->
    <div class="modal fade" id="addStopModal" tabindex="-1" aria-labelledby="addStopModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addStopModalLabel">
                        <i class="fas fa-<?php echo $edit_stop ? 'edit' : 'plus'; ?> me-2"></i>
                        <?php echo $edit_stop ? 'Edit Bus Stop' : 'Add New Bus Stop'; ?>
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form method="POST" id="stopForm">
                    <div class="modal-body">
                        <?php if ($edit_stop): ?>
                            <input type="hidden" name="stop_id" value="<?php echo $edit_stop['stop_id']; ?>">
                            <input type="hidden" name="update_stop" value="1">
                        <?php else: ?>
                            <input type="hidden" name="add_stop" value="1">
                        <?php endif; ?>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="route_id" class="form-label">Route *</label>
                                <select class="form-select" id="route_id" name="route_id" required>
                                    <option value="">Select Route</option>
                                    <?php foreach ($routes as $route): ?>
                                        <option value="<?php echo $route['route_id']; ?>" 
                                            <?php echo ($edit_stop && $edit_stop['route_id'] == $route['route_id']) ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($route['route_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="stop_order" class="form-label">Stop Order *</label>
                                <input type="number" class="form-control" id="stop_order" name="stop_order" 
                                       value="<?php echo $edit_stop ? $edit_stop['stop_order'] : ''; ?>" 
                                       min="1" required>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="stop_name" class="form-label">Stop Name *</label>
                            <input type="text" class="form-control" id="stop_name" name="stop_name" 
                                   value="<?php echo $edit_stop ? htmlspecialchars($edit_stop['stop_name']) : ''; ?>" 
                                   required>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="latitude" class="form-label">Latitude *</label>
                                <input type="number" step="any" class="form-control coordinates-input" id="latitude" name="latitude" 
                                       value="<?php echo $edit_stop ? $edit_stop['latitude'] : ''; ?>" 
                                       required placeholder="e.g., 7.488133">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="longitude" class="form-label">Longitude *</label>
                                <input type="number" step="any" class="form-control coordinates-input" id="longitude" name="longitude" 
                                       value="<?php echo $edit_stop ? $edit_stop['longitude'] : ''; ?>" 
                                       required placeholder="e.g., 80.364240">
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="landmark" class="form-label">Landmark</label>
                                <input type="text" class="form-control" id="landmark" name="landmark" 
                                       value="<?php echo $edit_stop ? htmlspecialchars($edit_stop['landmark']) : ''; ?>" 
                                       placeholder="Nearby landmark">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="estimated_time" class="form-label">Estimated Time (minutes) *</label>
                                <input type="number" class="form-control" id="estimated_time" name="estimated_time" 
                                       value="<?php echo $edit_stop ? $edit_stop['estimated_time_from_start'] : ''; ?>" 
                                       min="0" required>
                            </div>
                        </div>
                        
                        <?php if ($edit_stop): ?>
                            <div class="mb-3">
                                <label for="is_active" class="form-label">Status</label>
                                <select class="form-select" id="is_active" name="is_active">
                                    <option value="1" <?php echo $edit_stop['is_active'] ? 'selected' : ''; ?>>Active</option>
                                    <option value="0" <?php echo !$edit_stop['is_active'] ? 'selected' : ''; ?>>Inactive</option>
                                </select>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-<?php echo $edit_stop ? 'save' : 'plus'; ?> me-2"></i>
                            <?php echo $edit_stop ? 'Update Stop' : 'Add Stop'; ?>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Delete Confirmation Modal -->
    <div class="modal fade" id="deleteModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title text-danger">
                        <i class="fas fa-exclamation-triangle me-2"></i>Confirm Deletion
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>Are you sure you want to delete the bus stop: <strong id="deleteStopName"></strong>?</p>
                    <p class="text-danger"><small>This action cannot be undone. The stop will be marked as inactive.</small></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <form method="POST" id="deleteForm">
                        <input type="hidden" name="stop_id" id="deleteStopId">
                        <input type="hidden" name="delete_stop" value="1">
                        <button type="submit" class="btn btn-danger">
                            <i class="fas fa-trash me-2"></i>Delete Stop
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Initialize tooltips
        var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'))
        var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl)
        });

        // Show modal if editing or if there's an error
        <?php if ($edit_stop): ?>
            var modal = new bootstrap.Modal(document.getElementById('addStopModal'));
            modal.show();
        <?php endif; ?>

        // Search functionality
        document.getElementById('searchInput').addEventListener('keyup', function() {
            const searchText = this.value.toLowerCase();
            const rows = document.querySelectorAll('#stopsTable tbody tr');
            
            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(searchText) ? '' : 'none';
            });
        });

        function clearSearch() {
            document.getElementById('searchInput').value = '';
            const rows = document.querySelectorAll('#stopsTable tbody tr');
            rows.forEach(row => row.style.display = '');
        }

        function confirmDelete(stopId, stopName) {
            document.getElementById('deleteStopId').value = stopId;
            document.getElementById('deleteStopName').textContent = stopName;
            var deleteModal = new bootstrap.Modal(document.getElementById('deleteModal'));
            deleteModal.show();
        }

        // Auto-open modal if there's an error in form submission
        <?php if ($_SERVER['REQUEST_METHOD'] === 'POST' && $message_type === 'danger'): ?>
            var modal = new bootstrap.Modal(document.getElementById('addStopModal'));
            modal.show();
        <?php endif; ?>
    </script>
</body>
</html>
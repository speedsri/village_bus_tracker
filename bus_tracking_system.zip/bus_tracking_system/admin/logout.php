<?php
require_once '../includes/config.php';

session_start();

if (isset($_SESSION['admin_id']) && isset($_SESSION['admin_session_token'])) {
    $admin_id = $_SESSION['admin_id'];
    $session_token = $_SESSION['admin_session_token'];
    
    // Logout from database
    $stmt = $pdo->prepare("
        UPDATE user_sessions 
        SET is_active = 0, logout_time = CURRENT_TIMESTAMP 
        WHERE user_id = ? AND session_token = ?
    ");
    $stmt->execute([$admin_id, $session_token]);
}

// Clear session
session_unset();
session_destroy();

// Redirect to login page
header('Location: index.php?logout=success');
exit;
?>
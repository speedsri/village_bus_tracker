<?php
// get_bus_stops.php
require_once 'db_connection.php';

// Get route_id from query parameter, default to 1 if not provided
$route_id = isset($_GET['route_id']) ? (int)$_GET['route_id'] : 1;

try {
    $stmt = $pdo->prepare("
        SELECT * FROM bus_stops 
        WHERE route_id = :route_id 
        ORDER BY stop_order ASC
    ");
    $stmt->execute(['route_id' => $route_id]);
    $stops = $stmt->fetchAll();
    
    echo json_encode([
        'success' => true,
        'data' => $stops
    ]);
} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Error fetching bus stops: ' . $e->getMessage()
    ]);
}
?>
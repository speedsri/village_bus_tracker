<?php
// update_bus_stop.php
require_once 'db_connection.php';

// Get JSON input
$input = json_decode(file_get_contents('php://input'), true);

// Validate required fields
if (!isset($input['stop_id']) || empty($input['stop_id'])) {
    echo json_encode([
        'success' => false,
        'message' => 'Missing required field: stop_id'
    ]);
    exit;
}

try {
    // Build dynamic update query based on provided fields
    $update_fields = [];
    $params = ['stop_id' => $input['stop_id']];
    
    $allowed_fields = [
        'stop_name', 'stop_order', 'latitude', 'longitude', 
        'landmark', 'estimated_time_from_start', 'is_active'
    ];
    
    foreach ($allowed_fields as $field) {
        if (isset($input[$field])) {
            $update_fields[] = "$field = :$field";
            $params[$field] = $input[$field];
        }
    }
    
    if (empty($update_fields)) {
        echo json_encode([
            'success' => false,
            'message' => 'No fields to update'
        ]);
        exit;
    }
    
    $sql = "UPDATE bus_stops SET " . implode(', ', $update_fields) . " WHERE stop_id = :stop_id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    
    echo json_encode([
        'success' => true,
        'message' => 'Bus stop updated successfully'
    ]);
} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'message' => 'Error updating bus stop: ' . $e->getMessage()
    ]);
}
?>